(() => {
  'use strict';
  const $=id=>document.getElementById(id), n=id=>Math.max(0,Number($('i-'+id).value)||0);
  function option(rotated=false){
    const sw=n('sw'), sh=n('sh'), side=n('side'), top=n('top'), grip=n('grip'), gap=n('gap'), bleed=n('bleed');
    const trimW=n('pw'), trimH=n('ph'), pw=(rotated?trimH:trimW)+2*bleed, ph=(rotated?trimW:trimH)+2*bleed;
    const uw=Math.max(0,sw-2*side), uh=Math.max(0,sh-top-grip);
    const cols=pw>0?Math.floor((uw+gap)/(pw+gap)):0, rows=ph>0?Math.floor((uh+gap)/(ph+gap)):0, nup=cols*rows;
    const occupied=nup?cols*pw+Math.max(0,cols-1)*gap:0, occupiedH=nup?rows*ph+Math.max(0,rows-1)*gap:0;
    const usedArea=nup*pw*ph, usableArea=uw*uh, util=usableArea?usedArea/usableArea*100:0;
    return {rotated,pw,ph,uw,uh,cols,rows,nup,util,unused:Math.max(0,usableArea-usedArea),occupied,occupiedH};
  }
  function calc(){
    const a=option(false),b=option(true),best=[a,b].sort((x,y)=>y.nup-x.nup||y.util-x.util)[0],qty=Math.max(1,Math.round(n('qty'))), sheets=best.nup?Math.ceil(qty/best.nup):Infinity;
    $('i-nup').textContent=best.nup||'0'; $('i-grid').textContent=`${best.cols} × ${best.rows}`; $('i-sheets').textContent=Number.isFinite(sheets)?sheets.toLocaleString():'—'; $('i-util').textContent=`${best.util.toFixed(1)}%`; $('i-vcuts').textContent=Math.max(0,best.cols-1); $('i-hcuts').textContent=Math.max(0,best.rows-1); $('i-unused').textContent=`${(best.unused/1000000).toFixed(3)} m²`;
    const ok=best.nup>0; $('i-status').className=`status ${ok?'good':'bad'}`; $('i-status').textContent=ok?'GRID FOUND':'NO FIT'; $('i-headline').textContent=ok?`${best.rotated?'Rotated':'Normal'} piece orientation gives ${best.nup}-up.`:'The imposed piece does not fit the usable parent sheet.'; $('i-decision').textContent=ok?`Use a ${best.cols} × ${best.rows} grid on a ${best.uw.toFixed(1)} × ${best.uh.toFixed(1)} mm usable area. ${qty.toLocaleString()} sellable pieces require ${sheets.toLocaleString()} sheets before any additional production spoilage.`:'Increase the parent sheet, reduce reserves, or reduce the imposed piece footprint.';
    $('i-options').innerHTML=[a,b].map(o=>`<article class="result-card"><h3>${o.rotated?'Rotated piece':'Normal piece'}</h3><div class="result-row"><span>Imposed footprint</span><b>${o.pw.toFixed(1)} × ${o.ph.toFixed(1)} mm</b></div><div class="result-row"><span>Grid / N-up</span><b>${o.cols} × ${o.rows} · ${o.nup}-up</b></div><div class="result-row"><span>Utilization</span><b>${o.util.toFixed(1)}%</b></div></article>`).join('');
    return {schema:'print-prep-lab-imposition-signal',version:1,nup:best.nup,cols:best.cols,rows:best.rows,rotated:best.rotated,sheets:Number.isFinite(sheets)?sheets:null,utilizationPct:best.util,parent:[n('sw'),n('sh')],usable:[best.uw,best.uh],trim:[n('pw'),n('ph')],bleed:n('bleed'),gap:n('gap'),updatedAt:new Date().toISOString()};
  }
  document.querySelectorAll('input,select').forEach(x=>x.addEventListener('input',calc));
  $('i-save').addEventListener('click',()=>{try{localStorage.setItem('print-prep-lab-imposition-last-v1',JSON.stringify(calc()));$('i-save-status').textContent='Imposition signal saved locally for the Job Command Center.'}catch{$('i-save-status').textContent='Browser storage blocked the save.'}});
  $('i-swap').addEventListener('click',()=>{const a=$('i-sw').value;$('i-sw').value=$('i-sh').value;$('i-sh').value=a;calc()});
  window.__PPL_IMPOSITION_CALC__=calc; calc();
})();
