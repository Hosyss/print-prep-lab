(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const num = (id, fallback = 0) => { const v = Number($(id)?.value); return Number.isFinite(v) ? v : fallback; };
  const fmt = (v, d = 2) => Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
  const rad = d => d * Math.PI / 180;
  const deg = r => r * 180 / Math.PI;
  const hp = (b,a) => { if (a === 0 && b === 0) return 0; const h = deg(Math.atan2(b,a)); return h >= 0 ? h : h + 360; };
  const dh = (h2,h1,C1,C2) => { if (C1*C2 === 0) return 0; let d=h2-h1; if (d>180)d-=360; if(d<-180)d+=360; return d; };
  const avgHue = (h1,h2,C1,C2) => { if (C1*C2===0) return h1+h2; const d=Math.abs(h1-h2); if(d<=180)return (h1+h2)/2; return h1+h2<360 ? (h1+h2+360)/2 : (h1+h2-360)/2; };

  function deltaE76(l1,a1,b1,l2,a2,b2){ return Math.hypot(l2-l1,a2-a1,b2-b1); }
  function deltaE2000(L1,a1,b1,L2,a2,b2,kL=1,kC=1,kH=1){
    const C1=Math.hypot(a1,b1), C2=Math.hypot(a2,b2), Cbar=(C1+C2)/2;
    const G=0.5*(1-Math.sqrt((Cbar**7)/(Cbar**7+25**7)));
    const ap1=(1+G)*a1, ap2=(1+G)*a2;
    const Cp1=Math.hypot(ap1,b1), Cp2=Math.hypot(ap2,b2);
    const hp1=hp(b1,ap1), hp2=hp(b2,ap2);
    const dLp=L2-L1, dCp=Cp2-Cp1;
    const dhp=dh(hp2,hp1,Cp1,Cp2);
    const dHp=2*Math.sqrt(Cp1*Cp2)*Math.sin(rad(dhp/2));
    const Lbar=(L1+L2)/2, Cbarp=(Cp1+Cp2)/2, hbar=avgHue(hp1,hp2,Cp1,Cp2);
    const T=1-0.17*Math.cos(rad(hbar-30))+0.24*Math.cos(rad(2*hbar))+0.32*Math.cos(rad(3*hbar+6))-0.20*Math.cos(rad(4*hbar-63));
    const dTheta=30*Math.exp(-(((hbar-275)/25)**2));
    const Rc=2*Math.sqrt((Cbarp**7)/(Cbarp**7+25**7));
    const Sl=1+(0.015*((Lbar-50)**2))/Math.sqrt(20+((Lbar-50)**2));
    const Sc=1+0.045*Cbarp;
    const Sh=1+0.015*Cbarp*T;
    const Rt=-Math.sin(rad(2*dTheta))*Rc;
    const l=dLp/(kL*Sl), c=dCp/(kC*Sc), h=dHp/(kH*Sh);
    return Math.sqrt(l*l+c*c+h*h+Rt*c*h);
  }
  function renderDelta(){
    const v=['de-l1','de-a1','de-b1','de-l2','de-a2','de-b2'].map(id=>num(id));
    $('de00').textContent=fmt(deltaE2000(...v),4); $('de76').textContent=fmt(deltaE76(...v),4);
  }
  function renderViewing(){
    const distanceRaw=Math.max(.1,num('vd-distance',24)), distanceIn=$('vd-unit').value==='cm'?distanceRaw/2.54:distanceRaw;
    const arcmin=Math.max(.1,num('vd-arcmin',1)), theta=rad(arcmin/60);
    const ppi=1/(distanceIn*Math.tan(theta));
    const wRaw=Math.max(.1,num('vd-width',24)), hRaw=Math.max(.1,num('vd-height',36)), u=$('vd-print-unit').value;
    const wIn=u==='cm'?wRaw/2.54:wRaw, hIn=u==='cm'?hRaw/2.54:hRaw;
    $('vd-ppi').textContent=fmt(ppi,0); $('vd-pixels').textContent=`${Math.ceil(wIn*ppi).toLocaleString()} × ${Math.ceil(hIn*ppi).toLocaleString()}`;
  }
  function renderPaper(){
    const w=Math.max(1,num('pw',450))/1000,h=Math.max(1,num('ph',640))/1000,gsm=Math.max(1,num('pgsm',150)),cal=Math.max(1,num('pcal',120)),count=Math.max(1,Math.round(num('pcount',1000)));
    const per=w*h*gsm,totalKg=per*count/1000,stack=count*cal/1000;
    $('pweight').textContent=`${fmt(totalKg,2)} kg`; $('pstack').textContent=`${fmt(stack,1)} mm`; $('pper').textContent=`${fmt(per,2)} g`;
  }
  function renderCreep(){
    let pages=Math.max(4,Math.round(num('cr-pages',64)/4)*4); $('cr-pages').value=pages;
    const cal=Math.max(.001,num('cr-cal',.1)), sheets=pages/4, max=Math.max(0,(sheets-1)*cal);
    $('cr-sheets').textContent=sheets; $('cr-max').textContent=`${fmt(max,2)} mm`;
    const cells=[]; const show=sheets<=20?[...Array(sheets)].map((_,i)=>i+1):[1,2,3,Math.ceil(sheets/2),sheets-2,sheets-1,sheets].filter((v,i,a)=>v>=1&&v<=sheets&&a.indexOf(v)===i);
    show.forEach(pos=>{const creep=(pos-1)*cal;cells.push(`<div class="creep-cell"><b>Sheet ${pos}${pos===1?' · outermost':pos===sheets?' · innermost':''}</b><span>${fmt(creep,2)} mm planning offset</span></div>`)});
    $('cr-table').innerHTML=cells.join('');
  }
  document.querySelectorAll('#delta-e input').forEach(x=>x.addEventListener('input',renderDelta));
  document.querySelectorAll('#viewing input,#viewing select').forEach(x=>x.addEventListener('input',renderViewing));
  document.querySelectorAll('#paper input').forEach(x=>x.addEventListener('input',renderPaper));
  document.querySelectorAll('#creep input').forEach(x=>x.addEventListener('input',renderCreep));
  renderDelta();renderViewing();renderPaper();renderCreep();
  window.PPL_PREPRESS_TEST={deltaE76,deltaE2000};
})();
