(()=>{
'use strict';
const $=id=>document.getElementById(id);
const dims={};
function lang(){try{return localStorage.getItem('print-prep-lab-language')==='ar'?'ar':'en'}catch(e){return 'en'}}
function pct(n){return Math.max(0,Math.min(100,n));}
function calculate(){
 const sw=Math.max(1,Number($('pr-width')?.value)||1), sh=Math.max(1,Number($('pr-height')?.value)||1);
 const parts=($('pr-size')?.value||'6,4').split(',').map(Number); let pw=parts[0],ph=parts[1];
 const landscape=sw>=sh; if(landscape && pw<ph)[pw,ph]=[ph,pw]; if(!landscape && pw>ph)[pw,ph]=[ph,pw];
 const target=Number(document.querySelector('input[name="q"]:checked')?.value)||300;
 const imageRatio=sw/sh, printRatio=pw/ph;
 let crop=0, usedW=sw,usedH=sh;
 if(imageRatio>printRatio){usedW=sh*printRatio;crop=(1-usedW/sw)*100}else if(imageRatio<printRatio){usedH=sw/printRatio;crop=(1-usedH/sh)*100}
 const ppi=Math.min(usedW/pw,usedH/ph);
 const reqW=Math.ceil(pw*target),reqH=Math.ceil(ph*target);
 let state='good'; if(ppi<target*.72)state='low'; else if(ppi<target)state='review';
 const ar=lang()==='ar';
 const title=state==='good'?(ar?'مناسب للهدف':'Meets target'):state==='review'?(ar?'يحتاج مراجعة':'Review recommended'):(ar?'الدقة غير كافية':'Resolution too low');
 const detail=ar?`${Math.round(ppi)} PPI فعلي`:`${Math.round(ppi)} effective PPI`;
 const box=$('pr-result'); if(box){box.dataset.state=state;$('pr-result-title').textContent=title;$('pr-result-detail').textContent=detail;$('pr-result-icon').textContent=state==='good'?'✓':state==='review'?'!':'×'}
 if($('pr-ppi')) $('pr-ppi').textContent=Math.round(ppi); if($('pr-crop')) $('pr-crop').textContent=`${crop.toFixed(crop<1?1:0)}%`; if($('pr-required')) $('pr-required').textContent=`${reqW} × ${reqH}`;
 $('pr-metrics')?.classList.toggle('crop-watch',crop>8);
}
function loadFile(file){if(!file||!file.type.startsWith('image/'))return;const img=new Image();const url=URL.createObjectURL(file);img.onload=()=>{$('pr-width').value=img.naturalWidth;$('pr-height').value=img.naturalHeight;document.querySelector('.upload-box')?.classList.add('loaded');URL.revokeObjectURL(url);calculate()};img.onerror=()=>URL.revokeObjectURL(url);img.src=url}
document.addEventListener('DOMContentLoaded',()=>{
 ['pr-width','pr-height','pr-size'].forEach(id=>$(id)?.addEventListener('input',calculate));document.querySelectorAll('input[name="q"]').forEach(x=>x.addEventListener('change',calculate));
 $('pr-file')?.addEventListener('change',e=>loadFile(e.target.files?.[0]));
 document.addEventListener('change',e=>{if(e.target.matches('[data-lang]'))setTimeout(calculate,0)});
 const box=document.querySelector('.upload-box');box?.addEventListener('dragover',e=>{e.preventDefault();box.classList.add('drag')});box?.addEventListener('dragleave',()=>box.classList.remove('drag'));box?.addEventListener('drop',e=>{e.preventDefault();box.classList.remove('drag');loadFile(e.dataTransfer.files?.[0])});
 calculate();
});})();