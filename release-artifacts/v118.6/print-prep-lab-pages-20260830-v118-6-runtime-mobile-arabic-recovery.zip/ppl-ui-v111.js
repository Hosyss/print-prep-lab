(() => {
'use strict';
const STORAGE='print-prep-lab-language';
const LEGACY_STORAGE='ppl-interface-language';
const ADVANCED_STORAGE='print-prep-lab-workspace-advanced-v1';
const $=(s,r=document)=>r.querySelector(s); const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const normalized=v=>v==='ar'?'ar':'en';
function hasAppLanguageRuntime(){return !!document.querySelector('script[src*="ppl-app-v111.js"]')}
function setTranslateCookie(lang){
  const value=lang==='ar'?'/en/ar':'/en/en';
  try{document.cookie=`googtrans=${value};path=/;SameSite=Lax`;document.cookie=`googtrans=${value};path=/;domain=${location.hostname};SameSite=Lax`}catch(e){}
}
function loadWholePageTranslation(lang){
  document.querySelectorAll('[data-en][data-ar]').forEach(el=>el.classList.add('notranslate'));
  setTranslateCookie(lang);
  if(lang!=='ar'||hasAppLanguageRuntime())return;
  if(document.getElementById('google_translate_element'))return;
  const host=document.createElement('div');host.id='google_translate_element';host.hidden=true;document.body.appendChild(host);
  window.googleTranslateElementInit=()=>{try{new google.translate.TranslateElement({pageLanguage:'en',includedLanguages:'ar,en',autoDisplay:false},'google_translate_element')}catch(e){}};
  if(!document.querySelector('script[data-ppl-google-translate]')){const sc=document.createElement('script');sc.dataset.pplGoogleTranslate='1';sc.src='https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';sc.async=true;sc.onerror=()=>{};document.head.appendChild(sc)}
}
function safeGet(k){try{return localStorage.getItem(k)}catch(e){return null}}
function safeSet(k,v){try{localStorage.setItem(k,v)}catch(e){}}
function initialLanguage(){
  const q=new URLSearchParams(location.search).get('lang');
  if(q==='en'||q==='ar'){safeSet(STORAGE,q);safeSet(LEGACY_STORAGE,q);return q}
  const current=safeGet(STORAGE); if(current==='en'||current==='ar') return current;
  const legacy=safeGet(LEGACY_STORAGE); if(legacy==='en'||legacy==='ar'){safeSet(STORAGE,legacy);return legacy}
  return 'en';
}
function applyBilingual(lang){
  lang=normalized(lang); safeSet(STORAGE,lang); safeSet(LEGACY_STORAGE,lang);
  document.documentElement.lang=lang; document.documentElement.dir=lang==='ar'?'rtl':'ltr';
  document.body.classList.toggle('ppl-ar-shell',lang==='ar');
  $$('[data-en][data-ar]').forEach(el=>{el.textContent=lang==='ar'?el.dataset.ar:el.dataset.en;el.classList.add('notranslate')});
  $$('[data-en-placeholder][data-ar-placeholder]').forEach(el=>{el.placeholder=lang==='ar'?el.dataset.arPlaceholder:el.dataset.enPlaceholder});
  $$('.ppl-lang-select,.v103-lang,[data-lang]').forEach(s=>{if(s.tagName==='SELECT')s.value=lang});
  const dict={
    'Tools':'الأدوات','Print sizes':'مقاسات الطباعة','Guides':'الأدلة','Professional':'مساحة المحترفين','Check an image':'فحص صورة',
    'Command Center':'مركز التحكم','Workspace':'مساحة العمل','Jobs':'المشاريع','File checks':'فحص الملفات','Preflight':'فحص ما قبل الطباعة',
    'Cost & quotes':'التكلفة والعروض','Production planning':'تخطيط الإنتاج','Suppliers':'الموردون','Release Center':'مركز الإصدار',
    'Analytics':'التحليلات','Readiness audit':'فحص الجاهزية','Home':'الرئيسية','Professional workspace':'مساحة المحترفين',
    'Interface language':'لغة الواجهة','Open professional navigation':'فتح تنقل مساحة المحترفين'
  };
  $$('.site-header a,.ppl-side-nav a').forEach(el=>{
    const node=el.matches('.ppl-side-nav a')?(el.querySelector('span:last-child')||el):el;
    const base=el.dataset.pplBase||el.dataset.pplEn||node.textContent.trim();
    if(!el.dataset.pplBase) el.dataset.pplBase=base;
    node.textContent=lang==='ar'?(dict[base]||base):base;
  });
  loadWholePageTranslation(lang);
  document.dispatchEvent(new CustomEvent('ppl:language-applied',{detail:{lang}}));
}
function bindLanguageControl(root=document){
  $$('.ppl-lang-select,.v103-lang',root).forEach(sel=>{
    if(sel.dataset.pplBound)return; sel.dataset.pplBound='1'; sel.value=initialLanguage();
    sel.setAttribute('data-lang','');
    sel.addEventListener('change',e=>{const lang=normalized(e.target.value);applyBilingual(lang);if(!hasAppLanguageRuntime()){setTranslateCookie(lang);setTimeout(()=>location.reload(),120)}});
  });
}
function initHome(){
  bindLanguageControl();
  const menu=$('.v103-menu'),nav=$('.v103-nav');
  if(menu&&nav&&!menu.dataset.pplBound){menu.dataset.pplBound='1';menu.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});nav.addEventListener('click',e=>{if(e.target.closest('a')){nav.classList.remove('open');menu.setAttribute('aria-expanded','false')}})}
  applyBilingual(initialLanguage());
}
function initLegacyShell(){
  const path=location.pathname.replace(/\/$/,'')||'/';
  const proPaths=new Set(['/workspace','/command-center','/enterprise-dashboard','/jobs','/job-core','/digital-twin','/inspector','/file-manifest','/preflight','/job-costing','/quote-compare','/capacity-planner','/imposition-planner','/sheet-planner','/roll-media','/packaging','/provider-matrix','/supplier-intelligence','/release-center','/release-packet','/readiness-audit','/production-analytics','/schedule-optimizer','/material-intelligence','/finishing-intelligence','/fulfillment-center','/customer-handoff','/vendor-handoff','/production-archive','/compliance-center','/knowledge-base','/automation-lab','/qa-history','/risk-register','/timeline','/queue-planner','/stock-coverage','/waste-ledger','/approval-matrix','/audit-log','/capa','/procurement','/revision-diff','/calibration-registry','/fold-planner','/spine-planner','/roll-diameter','/pallet-planner','/signature-planner','/color-control','/prepress-lab','/proof-sheet','/scenarios','/job-brief']);
  const header=$('.site-header .header-inner');
  if(header){
    let wrap=$('.ppl-lang-wrap',header);
    if(!wrap){wrap=document.createElement('label');wrap.className='ppl-lang-wrap';wrap.innerHTML='<span class="ppl-lang-label" data-en="Interface language" data-ar="لغة الواجهة">Interface language</span><select class="ppl-lang-select" data-lang aria-label="Interface language"><option value="en">EN</option><option value="ar">AR</option></select>';const action=$('.header-action',header);header.insertBefore(wrap,action||null)}
    bindLanguageControl(header);
  }
  if(proPaths.has(path)) buildPro(path);
  if(path==='/workspace') simplifyWorkspace();
  applyBilingual(initialLanguage());
}
function buildPro(path){
  if($('.ppl-pro-sidebar'))return; document.body.classList.add('ppl-professional');
  const links=[['/','⌂','Home'],['/command-center','⌁','Command Center'],['/workspace','▦','Workspace'],['/jobs','□','Jobs'],['/inspector','⌕','File checks'],['/preflight','✓','Preflight'],['/job-costing','$','Cost & quotes'],['/capacity-planner','◫','Production planning'],['/supplier-intelligence','◇','Suppliers'],['/release-center','⇥','Release Center'],['/production-analytics','↗','Analytics'],['/readiness-audit','◎','Readiness audit']];
  const side=document.createElement('aside');side.className='ppl-pro-sidebar';side.setAttribute('aria-label','Professional workspace navigation');side.innerHTML='<span class="ppl-side-title" data-en="Professional workspace" data-ar="مساحة المحترفين">Professional workspace</span><nav class="ppl-side-nav">'+links.map(([h,i,l])=>`<a href="${h}" class="${path===h?'active':''}" data-ppl-base="${l}"><span aria-hidden="true">${i}</span><span>${l}</span></a>`).join('')+'</nav>';
  const sh=$('.site-header'); if(sh)sh.insertAdjacentElement('afterend',side);else document.body.prepend(side);
  const head=$('.site-header .header-inner');
  if(head&&!$('.ppl-pro-toggle',head)){const t=document.createElement('button');t.className='ppl-pro-toggle';t.type='button';t.setAttribute('aria-label','Open professional navigation');t.setAttribute('aria-expanded','false');t.textContent='☰';head.insertBefore(t,head.firstChild);t.addEventListener('click',()=>{const open=document.body.classList.toggle('ppl-sidebar-open');t.setAttribute('aria-expanded',String(open))});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('ppl-sidebar-open')){document.body.classList.remove('ppl-sidebar-open');t.setAttribute('aria-expanded','false')}})}
}
function simplifyWorkspace(){
  if($('.ppl-workspace-launcher'))return; document.body.classList.add('ppl-workspace'); const hero=$('.ws-hero'); if(!hero)return;
  const launch=document.createElement('section'); launch.className='ppl-workspace-launcher shell'; launch.setAttribute('aria-labelledby','ppl-workspace-start');
  const cards=[
    ['/command-center','Lifecycle','دورة العمل','Run the whole job','إدارة المهمة كاملة','See readiness, blockers and the next action in one place.','شاهد الجاهزية والعوائق والخطوة التالية في مكان واحد.','Open Command Center','افتح مركز التحكم'],
    ['/inspector','Files','الملفات','Check print files','افحص ملفات الطباعة','Inspect file structure, dimensions, color signals and delivery evidence.','افحص بنية الملف والأبعاد وإشارات اللون وأدلة التسليم.','Check files','افحص الملفات'],
    ['/job-costing','Commercial','التكلفة','Price the job','سعر المهمة','Model cost, compare quotes and expose unit economics before release.','احسب التكلفة وقارن العروض وراجع تكلفة الوحدة قبل الإصدار.','Open costing','افتح حساب التكلفة'],
    ['/capacity-planner','Production','الإنتاج','Plan production','خطط للإنتاج','Check capacity, imposition, materials, timing and fulfilment.','راجع الطاقة والتجميع والخامات والوقت والتنفيذ.','Plan production','خطط للإنتاج']
  ];
  launch.innerHTML='<div class="ppl-launch-head"><div><small class="section-kicker" data-en="Start with the job" data-ar="ابدأ بالمهمة">Start with the job</small><h2 id="ppl-workspace-start" data-en="What do you need to do?" data-ar="ما الذي تريد إنجازه؟">What do you need to do?</h2></div><p data-en="Four common entry points. Advanced production modules stay available without overwhelming a new user." data-ar="أربع نقاط بداية شائعة. تظل وحدات الإنتاج المتقدمة متاحة من دون إرباك المستخدم الجديد.">Four common entry points. Advanced production modules stay available without overwhelming a new user.</p></div><div class="ppl-launch-grid">'+cards.map(([h,k,ka,t,ta,p,pa,c,ca])=>`<a class="ppl-launch-card" href="${h}"><small data-en="${k}" data-ar="${ka}">${k}</small><strong data-en="${t}" data-ar="${ta}">${t}</strong><span data-en="${p}" data-ar="${pa}">${p}</span><b data-en="${c} →" data-ar="${ca} ←">${c} →</b></a>`).join('')+'</div>';
  hero.insertAdjacentElement('afterend',launch);

  const core=$('#workspace-tools');
  const recent=$('.recent');
  const sections=$$('main > section');
  const advanced=sections.filter(sec=>sec!==hero&&sec!==launch&&sec!==core&&sec!==recent&&!sec.classList.contains('ws-paths'));
  advanced.forEach(sec=>sec.classList.add('ppl-advanced-module'));
  const controls=document.createElement('section');controls.className='ppl-advanced-controls shell';controls.innerHTML='<div><small data-en="Professional depth" data-ar="المستوى الاحترافي">Professional depth</small><strong data-en="Advanced production modules" data-ar="وحدات الإنتاج المتقدمة">Advanced production modules</strong><span data-en="Supplier, operations, quality, finishing and enterprise controls." data-ar="الموردون والعمليات والجودة والتشطيب وضوابط المؤسسة.">Supplier, operations, quality, finishing and enterprise controls.</span></div><button type="button" class="ppl-advanced-toggle" aria-expanded="false"><span data-en="Show advanced modules" data-ar="عرض الوحدات المتقدمة">Show advanced modules</span><b aria-hidden="true">＋</b></button>';
  const anchor=$('.ws-paths')||core||launch; anchor.insertAdjacentElement('afterend',controls);
  const btn=$('.ppl-advanced-toggle',controls); const label=$('span',btn); const icon=$('b',btn);
  const stored=safeGet(ADVANCED_STORAGE)==='open'; document.body.classList.toggle('ppl-advanced-collapsed',!stored);btn.setAttribute('aria-expanded',String(stored));
  const sync=()=>{const open=btn.getAttribute('aria-expanded')==='true';label.dataset.en=open?'Hide advanced modules':'Show advanced modules';label.dataset.ar=open?'إخفاء الوحدات المتقدمة':'عرض الوحدات المتقدمة';icon.textContent=open?'−':'＋';applyBilingual(initialLanguage())};
  btn.addEventListener('click',()=>{const open=btn.getAttribute('aria-expanded')!=='true';btn.setAttribute('aria-expanded',String(open));document.body.classList.toggle('ppl-advanced-collapsed',!open);safeSet(ADVANCED_STORAGE,open?'open':'closed');sync()});
  sync();
}
function init(){if(document.body.classList.contains('ppl-v105-home'))initHome();else initLegacyShell()}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

/* v112 local Arabic layer: deterministic, browser-local translations with no runtime translation service dependency. */
(()=>{
  'use strict';
  const KEY='print-prep-lab-language';
  const MAP_URL='/ppl-ar-v112.json';
  const SELECTOR='h1,h2,h3,h4,h5,h6,p,label,button,option,legend,th,td,summary,small,strong,b,a,span,li,dt,dd';
  const norm=s=>(s||'').replace(/\s+/g,' ').trim();
  let map=null,loading=null,observer=null,scheduled=false;
  const lang=()=>{try{return localStorage.getItem(KEY)==='ar'?'ar':'en'}catch(e){return document.documentElement.lang==='ar'?'ar':'en'}};
  function leaf(el){return !el.children.length && !el.matches('[data-i18n-dynamic]')}
  function remember(el,attr,key){if(!el.dataset[key]){const v=attr?el.getAttribute(attr):norm(el.textContent);if(v)el.dataset[key]=v}return el.dataset[key]||''}
  function tr(value){return map&&map[value]||''}
  function applyEl(el,l){
    if(!map||!leaf(el)||el.closest('#google_translate_element'))return;
    if(el.hasAttribute('data-en')&&el.hasAttribute('data-ar'))return;
    const en=remember(el,null,'pplLocalEn'); if(!en)return;
    const ar=tr(en); if(!ar)return;
    el.textContent=l==='ar'?ar:en;
    el.classList.add('notranslate');
  }
  function applyAttrs(root,l){
    root.querySelectorAll?.('[placeholder]').forEach(el=>{const en=remember(el,'placeholder','pplPlaceholderEn');const ar=tr(en);if(ar)el.setAttribute('placeholder',l==='ar'?ar:en)});
    root.querySelectorAll?.('[aria-label]').forEach(el=>{const en=remember(el,'aria-label','pplAriaEn');const ar=tr(en);if(ar)el.setAttribute('aria-label',l==='ar'?ar:en)});
    root.querySelectorAll?.('[title]').forEach(el=>{const en=remember(el,'title','pplTitleEn');const ar=tr(en);if(ar)el.setAttribute('title',l==='ar'?ar:en)});
  }
  function apply(root=document){
    if(!map)return; const l=lang();
    if(root.matches?.(SELECTOR))applyEl(root,l);
    root.querySelectorAll?.(SELECTOR).forEach(el=>applyEl(el,l));
    applyAttrs(root,l);
    const base=document.documentElement.dataset.pplTitleEn||document.title;
    if(!document.documentElement.dataset.pplTitleEn)document.documentElement.dataset.pplTitleEn=base;
    const arTitle=tr(base); if(arTitle)document.title=l==='ar'?arTitle:base;
    document.documentElement.lang=l;document.documentElement.dir=l==='ar'?'rtl':'ltr';
  }
  function schedule(root=document){if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;apply(root)})}
  function load(){
    if(map)return Promise.resolve(map);if(loading)return loading;
    loading=fetch(MAP_URL,{cache:'force-cache'}).then(r=>{if(!r.ok)throw new Error('local Arabic map '+r.status);return r.json()}).then(m=>{map=m;window.PPL_AR_V112=m;apply();return m}).catch(()=>({}));
    return loading;
  }
  function init(){
    load();
    document.addEventListener('ppl:language-applied',()=>schedule());
    document.addEventListener('change',e=>{if(e.target.matches?.('[data-lang],.ppl-lang-select,.v103-lang'))setTimeout(()=>schedule(),0)},true);
    observer=new MutationObserver(ms=>{if(!map)return;for(const m of ms){if(m.type==='childList'){m.addedNodes.forEach(n=>{if(n.nodeType===1)schedule(n.parentElement||document)})}}});
    observer.observe(document.body,{childList:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
