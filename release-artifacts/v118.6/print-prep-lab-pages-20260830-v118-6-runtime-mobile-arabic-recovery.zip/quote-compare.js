(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const KEY = 'print-prep-lab-quote-comparison-v1';
  const el = {
    list: $('quote-list'), qty: $('qc-qty'), currency: $('qc-currency'), add: $('add-quote'),
    save: $('save-quotes'), clear: $('clear-quotes'), status: $('qc-status'), cards: $('qc-cards'),
    report: $('qc-report'), copy: $('qc-copy'), download: $('qc-download')
  };
  let rows = [];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const num = v => Number.isFinite(Number(v)) ? Number(v) : 0;
  const fmt = (v, d = 2) => Number(v.toFixed(d)).toLocaleString('en-US', {minimumFractionDigits:d, maximumFractionDigits:d});

  function newRow(data = {}) {
    return {
      id: data.id || crypto.randomUUID?.() || String(Date.now() + Math.random()),
      name: data.name || '', print: num(data.print), proof: num(data.proof), shipping: num(data.shipping),
      tax: num(data.tax), taxShipping: Boolean(data.taxShipping), days: num(data.days) || 7, notes: data.notes || ''
    };
  }

  function rowHtml(r, i) {
    return `<div class="quote-row" data-id="${r.id}">
      <label>Provider / quote<input data-k="name" maxlength="70" value="${esc(r.name)}" placeholder="Quote ${i + 1}"></label>
      <label>Print price<input data-k="print" type="number" min="0" step="0.01" value="${r.print}"></label>
      <label>Proof<input data-k="proof" type="number" min="0" step="0.01" value="${r.proof}"></label>
      <label>Shipping<input data-k="shipping" type="number" min="0" step="0.01" value="${r.shipping}"></label>
      <label>Tax %<input data-k="tax" type="number" min="0" step="0.01" value="${r.tax}"></label>
      <label class="tax-shipping"><span>Tax shipping?</span><input data-k="taxShipping" type="checkbox" ${r.taxShipping ? 'checked' : ''}><small>Enable only if shipping is taxable for this quote.</small></label>
      <label>Days<input data-k="days" type="number" min="0" step="1" value="${r.days}"></label>
      <button type="button" class="remove-quote" aria-label="Remove quote">Remove</button>
    </div>`;
  }

  function calc(r, qty) {
    const complete = r.print > 0;
    const subtotal = r.print + r.proof + r.shipping;
    const taxableBase = r.print + r.proof + (r.taxShipping ? r.shipping : 0);
    const taxValue = taxableBase * r.tax / 100;
    const total = subtotal + taxValue;
    const unit = qty ? total / qty : 0;
    return {...r, complete, subtotal, taxableBase, taxValue, total, unit};
  }

  function sync() {
    el.list.querySelectorAll('.quote-row').forEach(node => {
      const r = rows.find(x => x.id === node.dataset.id);
      if (!r) return;
      node.querySelectorAll('[data-k]').forEach(inp => {
        const k = inp.dataset.k;
        if (k === 'taxShipping') r[k] = inp.checked;
        else r[k] = ['name','notes'].includes(k) ? inp.value : num(inp.value);
      });
    });
  }
  function renderRows() { el.list.innerHTML = rows.map(rowHtml).join(''); }

  function render() {
    sync();
    const qty = Math.max(1, Math.ceil(num(el.qty.value) || 1));
    const cur = el.currency.value || '$';
    const data = rows.map(r => calc(r, qty));
    const eligible = data.filter(x => x.complete);
    const costSorted = [...eligible].sort((a,b) => a.total - b.total);
    const fastSorted = [...eligible].sort((a,b) => a.days - b.days);
    const minTotal = costSorted[0]?.total ?? 0;
    const maxTotal = Math.max(...eligible.map(x => x.total), 1);
    const maxDays = Math.max(...eligible.map(x => x.days), 1);
    eligible.forEach(x => { x.balance = (x.total / maxTotal) * .7 + (x.days / maxDays) * .3; });
    const balanced = [...eligible].sort((a,b) => a.balance - b.balance)[0];

    el.cards.innerHTML = data.map(x => {
      if (!x.complete) {
        return `<article class="qc-card incomplete"><div class="rank-tags"><span>INCOMPLETE</span></div><small>${esc(x.name || 'Unnamed quote')}</small><h4>${esc(x.name || 'Quote')}</h4><strong>Enter a print price to compare</strong><p class="incomplete-note">This quote is excluded from Lowest cost, Fastest and Balanced rankings until Print price is greater than zero.</p></article>`;
      }
      const cheapest = x.id === costSorted[0]?.id;
      const fast = x.id === fastSorted[0]?.id;
      const bal = x.id === balanced?.id;
      return `<article class="qc-card ${cheapest ? 'best-cost' : ''} ${fast ? 'fastest' : ''}">
        <div class="rank-tags">${cheapest ? '<span>LOWEST LANDED COST</span>' : ''}${fast ? '<span>FASTEST</span>' : ''}${bal ? '<span>BALANCED SCORE</span>' : ''}</div>
        <small>${esc(x.name || 'Unnamed quote')}</small><h4>${esc(x.name || 'Quote')}</h4><strong>${esc(cur)}${fmt(x.unit)} / piece</strong>
        <dl><dt>Landed total</dt><dd>${esc(cur)}${fmt(x.total)}</dd><dt>Print</dt><dd>${esc(cur)}${fmt(x.print)}</dd><dt>Proof</dt><dd>${esc(cur)}${fmt(x.proof)}</dd><dt>Shipping</dt><dd>${esc(cur)}${fmt(x.shipping)}</dd><dt>Taxable base</dt><dd>${esc(cur)}${fmt(x.taxableBase)}</dd><dt>Tax</dt><dd>${esc(cur)}${fmt(x.taxValue)}</dd><dt>Turnaround</dt><dd>${x.days} day${x.days === 1 ? '' : 's'}</dd><dt>Difference vs lowest</dt><dd>${esc(cur)}${fmt(x.total - minTotal)}</dd></dl>
      </article>`;
    }).join('');

    const reportLines = [
      'PRINT PREP LAB — QUOTE COMPARISON', `Generated: ${new Date().toLocaleString()}`, `Quantity: ${qty}`, `Currency: ${cur}`,
      `Eligible quotes: ${eligible.length} / ${data.length}`, '',
      ...(costSorted.length ? costSorted.map((x,i) => `${i+1}. ${x.name || 'Unnamed quote'} — total ${cur}${fmt(x.total)} — ${cur}${fmt(x.unit)}/piece — ${x.days} days (print ${cur}${fmt(x.print)}, proof ${cur}${fmt(x.proof)}, shipping ${cur}${fmt(x.shipping)}, tax ${cur}${fmt(x.taxValue)} on ${cur}${fmt(x.taxableBase)} taxable base${x.taxShipping ? ', shipping taxable' : ', shipping not taxed'})`) : ['No complete quote is eligible for ranking yet.']),
      '', ...data.filter(x => !x.complete).map(x => `INCOMPLETE: ${x.name || 'Unnamed quote'} — excluded because Print price is 0 or blank.`),
      '', 'Eligibility rule: a quote enters rankings only when Print price is greater than zero.',
      'Tax rule: tax applies to print + proof, and to shipping only when “Tax shipping?” is enabled for that quote.',
      'Lowest landed cost and fastest turnaround are factual calculations from eligible entered data. Balanced score weights normalized cost 70% and turnaround 30%; it is not a quality rating.'
    ];
    el.report.textContent = reportLines.join('\n');
  }

  function add(data) { rows.push(newRow(data)); renderRows(); render(); }
  function reset() { rows = [newRow({name:'Quote A'}),newRow({name:'Quote B'}),newRow({name:'Quote C'})]; renderRows(); render(); el.status.textContent = 'Comparison reset.'; }
  function save() { sync(); try { localStorage.setItem(KEY, JSON.stringify({qty:el.qty.value,currency:el.currency.value,rows})); el.status.textContent='Saved this comparison in the current browser.'; } catch { el.status.textContent='Browser storage is unavailable.'; } }
  function load() { try { const d=JSON.parse(localStorage.getItem(KEY)||'null'); if(d&&Array.isArray(d.rows)&&d.rows.length){rows=d.rows.map(newRow);el.qty.value=d.qty||500;el.currency.value=d.currency||'$';renderRows();render();return} } catch {} reset(); }

  el.add.addEventListener('click', () => add());
  el.list.addEventListener('click', e => { const b=e.target.closest('.remove-quote'); if(!b)return; const id=b.closest('.quote-row').dataset.id; if(rows.length<=1){el.status.textContent='Keep at least one quote.';return} rows=rows.filter(x=>x.id!==id);renderRows();render(); });
  el.list.addEventListener('input', render);
  el.list.addEventListener('change', render);
  el.qty.addEventListener('input', render); el.currency.addEventListener('input', render); el.save.addEventListener('click', save); el.clear.addEventListener('click', reset);
  el.copy.addEventListener('click', async () => { try { await navigator.clipboard.writeText(el.report.textContent); el.status.textContent='Comparison report copied.'; } catch { el.status.textContent='Clipboard access was blocked.'; } });
  el.download.addEventListener('click', () => {
    sync(); const qty=Math.max(1,Math.ceil(num(el.qty.value)||1)),cur=el.currency.value||'$',data=rows.map(r=>calc(r,qty));
    const csv=['Provider,Eligible,Quantity,Print,Proof,Shipping,Tax %,Tax shipping,Taxable base,Tax value,Landed total,Cost per piece,Turnaround days',...data.map(x=>[x.name,x.complete?'Yes':'No',qty,x.print,x.proof,x.shipping,x.tax,x.taxShipping?'Yes':'No',x.taxableBase,x.taxValue,x.total,x.unit,x.days].map(v=>`"${String(v).replace(/"/g,'""')}"`).join(','))].join('\n');
    const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='print-quote-comparison.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),0);
  });
  load();
  try { const qp=new URL(location.href).searchParams.get('quantity'); if(qp&&Number(qp)>0){el.qty.value=Math.max(1,Math.round(Number(qp)));render();el.status.textContent='Quantity loaded from the job brief.';} } catch {}
})();
