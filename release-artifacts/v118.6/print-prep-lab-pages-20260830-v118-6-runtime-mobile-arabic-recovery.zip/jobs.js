(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const KEY = 'print-prep-lab-jobs-v1';
  const SIGNAL_KEYS = {
    brief: 'print-prep-lab-job-brief-v1',
    plans: 'print-prep-lab-studio-plans-v1',
    specs: 'print-prep-lab-custom-spec-profiles-v1',
    quotes: 'print-prep-lab-quote-comparison-v1',
    files: 'print-prep-lab-file-manifest-summary-v1',
    preflight: 'print-prep-lab-preflight-last-v1',
    costing: 'print-prep-lab-costing-last-v1',
    capacity: 'print-prep-lab-capacity-last-v1',
    imposition: 'print-prep-lab-imposition-last-v1',
    qa: 'print-prep-lab-qa-summary-v1',
    change: 'print-prep-lab-change-impact-last-v1', roll: 'print-prep-lab-roll-media-last-v1', packaging: 'print-prep-lab-packaging-last-v1', risk: 'print-prep-lab-risk-summary-v1', timeline: 'print-prep-lab-timeline-last-v1', queue:'print-prep-lab-queue-summary-v1',stock:'print-prep-lab-stock-last-v1',waste:'print-prep-lab-waste-last-v1',approvals:'print-prep-lab-approval-summary-v1'
  };
  const STAGES = [
    ['brief','Brief'],['specs','Specs'],['files','Files'],['preflight','Preflight'],['quote','Quote'],['signoff','Sign-off']
  ];
  let jobs = readJobs();
  function esc(s=''){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  function safeJSON(key, fallback=null){try{const v=JSON.parse(localStorage.getItem(key)||'null');return v ?? fallback}catch{return fallback}}
  function readJobs(){const v=safeJSON(KEY,[]);return Array.isArray(v)?v.filter(Boolean):[]}
  function write(){try{localStorage.setItem(KEY,JSON.stringify(jobs));return true}catch{return false}}
  function signals(){
    const brief=safeJSON(SIGNAL_KEYS.brief,null), plans=safeJSON(SIGNAL_KEYS.plans,[]), specs=safeJSON(SIGNAL_KEYS.specs,[]), quotes=safeJSON(SIGNAL_KEYS.quotes,null), files=safeJSON(SIGNAL_KEYS.files,null), preflight=safeJSON(SIGNAL_KEYS.preflight,null), costing=safeJSON(SIGNAL_KEYS.costing,null), capacity=safeJSON(SIGNAL_KEYS.capacity,null), imposition=safeJSON(SIGNAL_KEYS.imposition,null), qa=safeJSON(SIGNAL_KEYS.qa,null), change=safeJSON(SIGNAL_KEYS.change,null), roll=safeJSON(SIGNAL_KEYS.roll,null), packaging=safeJSON(SIGNAL_KEYS.packaging,null), risk=safeJSON(SIGNAL_KEYS.risk,null), timeline=safeJSON(SIGNAL_KEYS.timeline,null), queue=safeJSON(SIGNAL_KEYS.queue,null), stock=safeJSON(SIGNAL_KEYS.stock,null), waste=safeJSON(SIGNAL_KEYS.waste,null), approvals=safeJSON(SIGNAL_KEYS.approvals,null);
    return {
      brief: !!(brief && typeof brief==='object'),
      plans: Array.isArray(plans)?plans.length:0,
      specs: Array.isArray(specs)?specs.length:0,
      quotes: !!(quotes && typeof quotes==='object'),
      files: files && typeof files==='object' ? files : null,
      preflight: preflight && typeof preflight==='object' ? preflight : null,
      briefData: brief && typeof brief==='object'?brief:null,
      costing: costing && typeof costing==='object'?costing:null,
      capacity: capacity && typeof capacity==='object'?capacity:null,
      imposition: imposition && typeof imposition==='object'?imposition:null,
      qa: qa && typeof qa==='object'?qa:null, change:change&&typeof change==='object'?change:null, roll:roll&&typeof roll==='object'?roll:null, packaging:packaging&&typeof packaging==='object'?packaging:null, risk:risk&&typeof risk==='object'?risk:null, timeline:timeline&&typeof timeline==='object'?timeline:null,queue:queue&&typeof queue==='object'?queue:null,stock:stock&&typeof stock==='object'?stock:null,waste:waste&&typeof waste==='object'?waste:null,approvals:approvals&&typeof approvals==='object'?approvals:null
    };
  }
  function renderSignals(){
    const s=signals();
    const rows=[
      [s.brief,'Job brief',s.brief?'saved locally':'not saved'],
      [s.specs>0,'Custom specifications',s.specs?`${s.specs} profile(s)`:'none'],
      [s.plans>0,'Studio plans',s.plans?`${s.plans} saved plan(s)`:'none'],
      [s.quotes,'Quote comparison',s.quotes?'saved locally':'none'],
      [!!s.files,'Delivery manifest',s.files?`${s.files.fileCount||0} file(s) · ${s.files.duplicateCount||0} duplicate(s)`:'none'],
      [!!s.preflight,'Last preflight',s.preflight?`${s.preflight.state} · ${s.preflight.score}/10`:'not run'],
      [!!s.costing,'Cost model',s.costing?`${s.costing.currency||'$'}${Number(s.costing.unit||0).toFixed(2)} / unit`:'not saved'],
      [!!s.capacity,'Capacity model',s.capacity?`${s.capacity.feasible?'feasible':'short'} · ${Number(s.capacity.totalHours||0).toFixed(2)} h`:'not saved'],
      [!!s.imposition,'Imposition model',s.imposition?`${s.imposition.nup||0}-up · ${Number(s.imposition.utilizationPct||0).toFixed(1)}%`:'not saved'],
      [!!s.qa,'QA history',s.qa?`${s.qa.total||0} checkpoints · ${s.qa.blocker||0} blocker(s)`:'none'],
      [!!s.change,'Change impact',s.change?`${s.change.changedCount||0} change(s) · ${s.change.invalidatedCount||0} rerun`:'none'],
      [!!s.roll,'Roll media',s.roll?`${s.roll.across||0} across · ${Number(s.roll.lengthM||0).toFixed(2)} m`:'none'],
      [!!s.packaging,'Packaging',s.packaging?`${s.packaging.cartons||0} carton(s)`:'none'],
      [!!s.risk,'Risk register',s.risk?`${s.risk.high||0} high · ${s.risk.open||0} open`:'none'],
      [!!s.timeline,'Timeline',s.timeline?`${s.timeline.feasible?'open':'late'} · ${Number(s.timeline.totalHours||0).toFixed(1)} h`:'none'],
      [!!s.queue,'Production queue',s.queue?`${s.queue.total||0} job(s) · ${s.queue.late||0} late`:'none'],
      [!!s.stock,'Stock coverage',s.stock?`${s.stock.state} · ${Number(s.stock.after||0).toFixed(2)} after job`:'none'],
      [!!s.waste,'Waste / yield',s.waste?`${Number(s.waste.yieldPct||0).toFixed(1)}% yield`:'none'],
      [!!s.approvals,'Approvals',s.approvals?`${s.approvals.approved||0}/${s.approvals.required||0} approved`:'none']
    ];
    $('jc-signals').innerHTML=rows.map(([ok,name,val])=>`<div class="signal ${ok?'ok':'warn'}"><i></i><span>${name}</span><b>${val}</b></div>`).join('');
  }
  function completeness(j){return STAGES.filter(([k])=>j.stages?.[k]).length}
  function linkFor(stage,j){
    const q=new URLSearchParams({job:j.name||'',provider:j.provider||'',product:j.product||'',quantity:String(j.quantity||1)}).toString();
    return ({brief:`/job-brief?${q}`,specs:'/specs',files:'/file-manifest',preflight:'/preflight',quote:`/quote-compare?quantity=${encodeURIComponent(j.quantity||1)}`,signoff:'/proof-sheet'})[stage];
  }
  function renderJobs(){
    if(!jobs.length){$('jc-jobs').innerHTML='<div class="empty" style="grid-column:1/-1">No job records yet. Create one from the current workspace signals.</div>';return}
    const ordered=[...jobs].sort((a,b)=>(a.due||'9999').localeCompare(b.due||'9999')||(b.updatedAt||'').localeCompare(a.updatedAt||''));
    $('jc-jobs').innerHTML=ordered.map(j=>{
      const done=completeness(j), pct=Math.round(done/STAGES.length*100), next=STAGES.find(([k])=>!j.stages?.[k]);
      return `<article class="card" data-id="${esc(j.id)}"><div class="job-top"><div><span class="kicker">${esc(j.priority||'Normal')} priority</span><h3>${esc(j.name||'Untitled job')}</h3></div><span class="badge">${done}/${STAGES.length} stages</span></div><p>${esc(j.product||'Product not set')}${j.provider?` · ${esc(j.provider)}`:''}</p><div class="job-meta"><div><small>Quantity</small><b>${Number(j.quantity||1).toLocaleString()}</b></div><div><small>Due</small><b>${j.due?esc(j.due):'Not set'}</b></div><div><small>Readiness</small><b>${pct}%</b></div></div><div class="pipeline">${STAGES.map(([k,l])=>`<button type="button" class="step ${j.stages?.[k]?'done':(next?.[0]===k?'current':'')}" data-stage="${k}" title="Toggle ${l}">${l}</button>`).join('')}</div>${j.notes?`<p>${esc(j.notes)}</p>`:''}<div class="job-actions">${next?`<a class="btn primary" href="${linkFor(next[0],j)}">Next: ${next[1]}</a>`:'<span class="btn primary" aria-label="All stages marked complete">Ready for sign-off</span>'}<a class="btn" href="/studio?job=${encodeURIComponent(j.name||'')}&provider=${encodeURIComponent(j.provider||'')}">Studio</a><button class="btn" type="button" data-snapshot>Refresh snapshot</button><button class="btn danger" type="button" data-delete>Delete</button></div></article>`;
    }).join('');
  }
  function makeJob(){
    const s=signals(), brief=s.briefData||{};
    const name=$('jc-name').value.trim(); if(!name)return;
    const stages={brief:s.brief,specs:s.specs>0,files:!!(s.files&&s.files.fileCount>0),preflight:s.preflight?.state==='ready',quote:s.quotes,signoff:false};
    jobs.push({schema:'print-prep-lab-job',version:1,id:crypto.randomUUID?.()||String(Date.now()),name,provider:$('jc-provider').value.trim()||brief.provider||'',product:$('jc-product').value.trim()||brief.product||'',quantity:Math.max(1,Math.round(Number($('jc-qty').value)||1)),due:$('jc-due').value,priority:$('jc-priority').value,notes:$('jc-notes').value.trim(),stages,snapshot:{plans:s.plans,specs:s.specs,hasBrief:s.brief,hasQuotes:s.quotes,fileManifest:s.files?{fileCount:s.files.fileCount,duplicateCount:s.files.duplicateCount}:null,preflight:s.preflight?{state:s.preflight.state,score:s.preflight.score}:null,costing:s.costing?{unit:s.costing.unit,total:s.costing.total,currency:s.costing.currency}:null,capacity:s.capacity?{feasible:s.capacity.feasible,totalHours:s.capacity.totalHours}:null,imposition:s.imposition?{nup:s.imposition.nup,utilizationPct:s.imposition.utilizationPct}:null,qa:s.qa?{total:s.qa.total,blocker:s.qa.blocker}:null,change:s.change?{changedCount:s.change.changedCount,invalidatedCount:s.change.invalidatedCount}:null,roll:s.roll?{fit:s.roll.fit,lengthM:s.roll.lengthM}:null,packaging:s.packaging?{cartons:s.packaging.cartons,chargeableKg:s.packaging.chargeableKg}:null,risk:s.risk?{open:s.risk.open,high:s.risk.high}:null,timeline:s.timeline?{feasible:s.timeline.feasible,totalHours:s.timeline.totalHours}:null,queue:s.queue?{total:s.queue.total,late:s.queue.late}:null,stock:s.stock?{state:s.stock.state,after:s.stock.after}:null,waste:s.waste?{state:s.waste.state,yieldPct:s.waste.yieldPct}:null,approvals:s.approvals?{required:s.approvals.required,approved:s.approvals.approved,blocking:s.approvals.blocking}:null,at:new Date().toISOString()},createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()});
    write(); $('job-create').reset(); $('jc-qty').value=1; renderJobs();
  }
  $('job-create').addEventListener('submit',e=>{e.preventDefault();makeJob()});
  $('jc-refresh').addEventListener('click',renderSignals);
  $('jc-jobs').addEventListener('click',e=>{
    const card=e.target.closest('[data-id]'); if(!card)return; const j=jobs.find(x=>x.id===card.dataset.id); if(!j)return;
    const stage=e.target.closest('[data-stage]');
    if(stage){j.stages=j.stages||{};j.stages[stage.dataset.stage]=!j.stages[stage.dataset.stage];j.updatedAt=new Date().toISOString();write();renderJobs();return}
    if(e.target.closest('[data-snapshot]')){const s=signals();j.snapshot={plans:s.plans,specs:s.specs,hasBrief:s.brief,hasQuotes:s.quotes,fileManifest:s.files?{fileCount:s.files.fileCount,duplicateCount:s.files.duplicateCount}:null,preflight:s.preflight?{state:s.preflight.state,score:s.preflight.score}:null,costing:s.costing?{unit:s.costing.unit,total:s.costing.total,currency:s.costing.currency}:null,capacity:s.capacity?{feasible:s.capacity.feasible,totalHours:s.capacity.totalHours}:null,imposition:s.imposition?{nup:s.imposition.nup,utilizationPct:s.imposition.utilizationPct}:null,qa:s.qa?{total:s.qa.total,blocker:s.qa.blocker}:null,change:s.change?{changedCount:s.change.changedCount,invalidatedCount:s.change.invalidatedCount}:null,roll:s.roll?{fit:s.roll.fit,lengthM:s.roll.lengthM}:null,packaging:s.packaging?{cartons:s.packaging.cartons,chargeableKg:s.packaging.chargeableKg}:null,risk:s.risk?{open:s.risk.open,high:s.risk.high}:null,timeline:s.timeline?{feasible:s.timeline.feasible,totalHours:s.timeline.totalHours}:null,queue:s.queue?{total:s.queue.total,late:s.queue.late}:null,stock:s.stock?{state:s.stock.state,after:s.stock.after}:null,waste:s.waste?{state:s.waste.state,yieldPct:s.waste.yieldPct}:null,approvals:s.approvals?{required:s.approvals.required,approved:s.approvals.approved,blocking:s.approvals.blocking}:null,at:new Date().toISOString()};j.stages.brief=j.stages.brief||s.brief;j.stages.specs=j.stages.specs||s.specs>0;j.stages.quote=j.stages.quote||s.quotes;j.stages.files=j.stages.files||!!(s.files&&s.files.fileCount>0);j.stages.preflight=j.stages.preflight||s.preflight?.state==='ready';j.updatedAt=new Date().toISOString();write();renderJobs();return}
    if(e.target.closest('[data-delete]')){jobs=jobs.filter(x=>x.id!==j.id);write();renderJobs()}
  });
  function download(name,content){const b=new Blob([content],{type:'application/json;charset=utf-8'}),u=URL.createObjectURL(b),a=document.createElement('a');a.href=u;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),0)}
  $('jc-export').addEventListener('click',()=>download('print-prep-lab-jobs.json',JSON.stringify({schema:'print-prep-lab-jobs-export',version:1,exportedAt:new Date().toISOString(),jobs},null,2)+'\n'));
  $('jc-import').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{const x=JSON.parse(await f.text());if(x?.schema!=='print-prep-lab-jobs-export'||!Array.isArray(x.jobs))throw 0;const map=new Map(jobs.map(j=>[j.id,j]));x.jobs.filter(Boolean).forEach(j=>map.set(j.id||crypto.randomUUID(),j));jobs=[...map.values()];write();renderJobs()}catch{alert('That file is not a valid Print Prep Lab jobs export.')}e.target.value=''});
  const b=signals().briefData;if(b){$('jc-name').value=b.project||'';$('jc-provider').value=b.provider||'';$('jc-product').value=b.product||'';$('jc-qty').value=b.quantity||1;$('jc-due').value=b.deadline||''}
  renderSignals();renderJobs();
})();
