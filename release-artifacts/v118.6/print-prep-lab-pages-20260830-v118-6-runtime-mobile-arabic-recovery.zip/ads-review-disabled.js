/* AdSense intentionally disabled during site review. Ownership remains verified via meta tag/ads.txt. */
