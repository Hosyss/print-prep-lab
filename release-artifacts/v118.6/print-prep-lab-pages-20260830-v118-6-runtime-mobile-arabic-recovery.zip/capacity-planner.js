(() => {
  'use strict';
  const $=id=>document.getElementById(id), n=id=>Math.max(0,Number($('p-'+id).value)||0);
  function calc(){
    const qty=Math.max(1,Math.round(n('qty'))), speed=Math.max(.0001,n('speed')), yieldPer=Math.max(.0001,n('yield')), util=Math.min(100,Math.max(.01,n('util')))/100;
    const setup=(n('setup')+n('changes')*n('change-min'))/60, shift=Math.max(.01,n('shift')), shifts=Math.max(1,n('shifts')), days=Math.max(.01,n('days'));
    const effective=speed*yieldPer*util, run=qty/effective, total=run+setup, hoursPerDay=shift*shifts, calendar=total/hoursPerDay, windowHours=days*hoursPerDay, productiveWindow=Math.max(0,windowHours-setup), windowCap=Math.floor(productiveWindow*effective);
    const rawHoursNeededAtFull=qty/(speed*yieldPer), requiredUtil=productiveWindow>0?rawHoursNeededAtFull/productiveWindow*100:Infinity, buffer=windowHours-total;
    $('p-effective').textContent=Math.round(effective).toLocaleString(); $('p-run-hours').textContent=`${run.toFixed(2)} h`; $('p-total-hours').textContent=`${total.toFixed(2)} h`; $('p-calendar').textContent=`${calendar.toFixed(2)} d`; $('p-window-cap').textContent=windowCap.toLocaleString(); $('p-required-util').textContent=Number.isFinite(requiredUtil)?`${requiredUtil.toFixed(1)}%`:'—'; $('p-buffer').textContent=`${buffer>=0?'+':''}${buffer.toFixed(2)} h`;
    const meets=buffer>=0; $('p-status').className=`status ${meets?'good':'bad'}`; $('p-status').textContent=meets?'WINDOW FEASIBLE':'WINDOW SHORT'; $('p-headline').textContent=meets?'The modeled stage fits inside the entered window.':'The modeled stage needs more time or throughput.'; $('p-decision').textContent=meets?`The schedule uses ${total.toFixed(2)} of ${windowHours.toFixed(2)} available hours, leaving ${buffer.toFixed(2)} hours of modeled buffer.`:`The schedule exceeds the window by ${Math.abs(buffer).toFixed(2)} hours. At the same rated speed, utilization would need to be ${requiredUtil.toFixed(1)}% after setup.`;
    $('p-bar').style.width=`${Math.min(100,total/windowHours*100).toFixed(1)}%`;
    return {schema:'print-prep-lab-capacity-signal',version:1,qty,effectiveThroughput:effective,runHours:run,totalHours:total,calendarDays:calendar,windowHours,bufferHours:buffer,requiredUtilPct:requiredUtil,feasible:meets,updatedAt:new Date().toISOString()};
  }
  document.querySelectorAll('input,select').forEach(x=>x.addEventListener('input',calc));
  $('p-save').addEventListener('click',()=>{try{localStorage.setItem('print-prep-lab-capacity-last-v1',JSON.stringify(calc()));$('p-save-status').textContent='Capacity signal saved locally for the Job Command Center.'}catch{$('p-save-status').textContent='Browser storage blocked the save.'}});
  $('p-reset').addEventListener('click',()=>{const v={qty:10000,speed:5000,yield:1,util:75,setup:45,changes:1,'change-min':20,shift:8,shifts:1,days:1};Object.entries(v).forEach(([k,x])=>$('p-'+k).value=x);calc()});
  window.__PPL_CAPACITY_CALC__=calc; calc();
})();
