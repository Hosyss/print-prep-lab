(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const ids=['qty','waste','setup','material','machine','finish','hours','labor-rate','overhead','ship','markup'];
  const n=id=>Math.max(id==='markup'?-99:0,Number($('c-'+id).value)||0);
  const money=(v,c=$('c-currency').value||'$')=>`${c}${Number(v).toFixed(2)}`;
  function calc(){
    const qty=Math.max(1,Math.round(n('qty'))), waste=n('waste')/100, produced=Math.max(qty,Math.ceil(qty*(1+waste)));
    const setup=n('setup'), material=produced*n('material'), machine=produced*n('machine'), finishing=qty*n('finish'), labor=n('hours')*n('labor-rate'), overhead=n('overhead'), shipping=n('ship');
    const parts=[['Setup',setup,'fixed'],['Material',material,`${produced.toLocaleString()} produced pieces`],['Machine / production',machine,`${produced.toLocaleString()} produced pieces`],['Finishing',finishing,`${qty.toLocaleString()} sellable pieces`],['Labor',labor,`${n('hours').toFixed(2)} h × ${money(n('labor-rate'))}`],['Overhead',overhead,'allocated to run'],['Shipping',shipping,'job-level delivery']];
    const total=parts.reduce((s,x)=>s+x[1],0), unit=total/qty, price=unit*(1+n('markup')/100);
    const variablePerProduced=n('material')+n('machine');
    const variablePerSellable=n('finish')+variablePerProduced*(produced/qty);
    const fixed=setup+labor+overhead+shipping;
    const contribution=price-variablePerSellable;
    const breakeven=contribution>0?Math.ceil(fixed/contribution):null;
    $('c-produced').textContent=produced.toLocaleString(); $('c-total').textContent=money(total); $('c-unit').textContent=money(unit); $('c-price').textContent=money(price);
    $('c-gross').textContent=money(price-unit); $('c-contribution').textContent=money(contribution); $('c-breakeven').textContent=breakeven==null?'No break-even':breakeven.toLocaleString();
    $('c-breakdown').innerHTML=parts.map(([name,val,basis])=>`<tr><td><b>${name}</b></td><td>${money(val)}</td><td>${total?((val/total)*100).toFixed(1):'0.0'}%</td><td>${basis}</td></tr>`).join('');
    const dominant=[...parts].sort((a,b)=>b[1]-a[1])[0]; $('c-headline').textContent=dominant?`${dominant[0]} is the largest modeled cost component.`:'Enter job costs.';
    $('c-decision').textContent=`The run delivers ${qty.toLocaleString()} pieces after planning ${produced.toLocaleString()} produced pieces. At ${n('markup').toFixed(1)}% markup, the modeled selling price is ${money(price)} per piece.`;
    return {schema:'print-prep-lab-costing-signal',version:1,qty,produced,wastePct:n('waste'),total,unit,price,markupPct:n('markup'),contribution,breakeven,dominant:dominant?.[0]||null,currency:$('c-currency').value||'$',updatedAt:new Date().toISOString()};
  }
  document.querySelectorAll('input,select').forEach(el=>el.addEventListener('input',calc));
  $('c-save').addEventListener('click',()=>{try{localStorage.setItem('print-prep-lab-costing-last-v1',JSON.stringify(calc()));$('c-save-status').textContent='Costing signal saved locally for the Job Command Center.'}catch{$('c-save-status').textContent='Browser storage blocked the save.'}});
  $('c-reset').addEventListener('click',()=>{const v={qty:500,waste:5,setup:45,material:.18,machine:.08,finish:.05,hours:1.5,'labor-rate':24,overhead:25,ship:18,markup:35};Object.entries(v).forEach(([k,x])=>$('c-'+k).value=x);$('c-currency').value='$';calc()});
  window.__PPL_COSTING_CALC__=calc; calc();
})();
