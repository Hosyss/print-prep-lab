(() => {
  'use strict';
  const profiles = [
    {
      id: 'photo-lab', name: 'Photo lab raster print', category: 'Photo', ppi: 300, bleed: 0, safe: 3,
      jobType: 'photo-art', color: 'Provider-requested RGB profile (often sRGB)', format: 'High-quality JPEG or TIFF when requested',
      proof: 'Inspect crop, focus and color; use a lab proof for critical work.',
      note: 'Use for photographic prints where the lab supplies the exact accepted color space and file type.',
      checks: ['Confirm whether borders or full bleed are expected', 'Check the provider minimum/recommended PPI', 'Do not add bleed unless the lab asks for it']
    },
    {
      id: 'fine-art', name: 'Fine-art / giclée print', category: 'Photo & art', ppi: 300, bleed: 0, safe: 5,
      jobType: 'photo-art', color: 'Provider ICC profile or documented RGB workflow', format: 'TIFF, JPEG or PDF exactly as requested',
      proof: 'Soft-proof with the supplied profile when available; order a physical proof for color-critical editions.',
      note: 'A conservative planning profile for artwork and photography where tonal detail and color consistency matter.',
      checks: ['Confirm paper and printable area', 'Keep an untouched master before output sharpening', 'Ask whether the provider wants embedded profiles']
    },
    {
      id: 'commercial-sheet', name: 'Commercial sheet / flyer', category: 'Commercial print', ppi: 300, bleed: 3, safe: 5,
      jobType: 'document-text', color: 'Printer-supplied CMYK/RGB workflow; do not guess a profile', format: 'Print-ready PDF using the provider preset when supplied',
      proof: 'Reopen the exported PDF and inspect page boxes, fonts, overprint-sensitive elements and trim.',
      note: 'A common starting point for flyers, cards and sheet-fed layouts. Replace 3 mm bleed with the written specification.',
      checks: ['Keep text and logos inside the safe area', 'Confirm whether crop marks are wanted', 'Verify fonts and transparency requirements']
    },
    {
      id: 'business-card', name: 'Business card / small collateral', category: 'Commercial print', ppi: 300, bleed: 3, safe: 4,
      jobType: 'document-text', color: 'Provider-specified print profile', format: 'PDF preferred when vector text/logos are supported',
      proof: 'Inspect small text at final size and order a proof when fine lines or color matching matter.',
      note: 'Small finished pieces are unforgiving: protect critical content and keep vector elements vector when possible.',
      checks: ['Confirm rounded-corner or finishing clearance', 'Check minimum text/line recommendations', 'Verify final trim dimensions before export']
    },
    {
      id: 'large-format', name: 'Large-format poster / display', category: 'Large format', ppi: 150, bleed: 5, safe: 10,
      jobType: 'poster-wall', color: 'Provider-defined large-format workflow', format: 'High-quality raster or PDF according to the RIP workflow',
      proof: 'Judge source quality at final scale and normal viewing distance; request a reduced or physical proof for important jobs.',
      note: 'Lower PPI can be appropriate at longer viewing distances, but the provider minimum and content detail still decide.',
      checks: ['Record final viewing distance', 'Confirm finishing/hemming/grommet clearance', 'Do not infer image PPI from hardware DPI']
    },
    {
      id: 'book-cover', name: 'Book cover / wrap', category: 'Books', ppi: 300, bleed: 3.175, safe: 6.35,
      jobType: 'book-layout', color: 'Platform/provider color specification', format: 'PDF built from the exact cover template',
      proof: 'Validate trim, spine width, bleed, barcode zone and safe areas against the current template.',
      note: 'Use only after generating the exact cover template for the final trim, page count, paper and binding.',
      checks: ['Treat spine width as product-specific', 'Keep critical text away from folds and trim', 'Regenerate the template if page count or paper changes']
    },
    {
      id: 'book-interior', name: 'Book / booklet interior', category: 'Books', ppi: 300, bleed: 3.175, safe: 6.35,
      jobType: 'book-layout', color: 'Platform/provider interior color specification', format: 'Multipage PDF with correct page size and embedding',
      proof: 'Check pagination, inside/outside margins, page boxes, fonts and blank pages before upload.',
      note: 'A planning profile for raster content inside books or booklets. Binding and inside margins remain product-specific.',
      checks: ['Confirm whether interior pages are full bleed', 'Verify inside/gutter clearance', 'Check page count and imposed output rules']
    },
    {
      id: 'sticker-label', name: 'Sticker / label artwork', category: 'Labels', ppi: 300, bleed: 3, safe: 3,
      jobType: 'other', color: 'Provider-specified profile and spot-color workflow if applicable', format: 'PDF/vector artwork when contour cut paths are required',
      proof: 'Inspect cut path, white ink/spot layers and edge clearance using the provider template.',
      note: 'Cutting, kiss-cut paths, white ink and material rules vary widely; use this only as a geometry starting point.',
      checks: ['Confirm cut-line naming and stroke rules', 'Keep important details away from the cut', 'Ask how white/metallic/clear layers must be supplied']
    }
  ];
  const STORAGE_KEY = 'print-prep-lab-custom-spec-profiles-v1';
  const ACTIVE_KEY = 'print-prep-lab-active-spec-profile-v1';
  function readCustom() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(parsed) ? parsed.filter(Boolean) : [];
    } catch { return []; }
  }
  function writeCustom(list) { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); }
  function all() { return [...profiles, ...readCustom()]; }
  function get(id) { return all().find((p) => p.id === id) || null; }
  function setActive(profile) {
    try { sessionStorage.setItem(ACTIVE_KEY, JSON.stringify(profile)); } catch {}
  }
  function getActive(clear = false) {
    try {
      const raw = sessionStorage.getItem(ACTIVE_KEY);
      const value = raw ? JSON.parse(raw) : null;
      if (clear) sessionStorage.removeItem(ACTIVE_KEY);
      return value;
    } catch { return null; }
  }
  window.PPL_SPEC_PROFILES = { builtIn: profiles, all, get, readCustom, writeCustom, setActive, getActive, STORAGE_KEY, ACTIVE_KEY };
})();
