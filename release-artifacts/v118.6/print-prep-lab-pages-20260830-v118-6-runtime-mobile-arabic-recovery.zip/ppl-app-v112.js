(()=>{
  'use strict';
  const KEY='print-prep-lab-language';
  const T={
    'Home':'الرئيسية','Dashboard':'لوحة التحكم','Projects':'المشاريع','All tools':'جميع الأدوات','Tools':'الأدوات','Guides':'الأدلة','Print sizes':'مقاسات الطباعة','Professional':'مساحة المحترفين','Resources':'الموارد','Pricing':'المقاسات','Help center':'مركز المساعدة','File check':'فحص الملفات','Costing':'حساب التكاليف','Production planning':'تخطيط الإنتاج','Suppliers':'الموردون','Release center':'مركز الإصدار','Reports & analytics':'التقارير والتحليلات','Workspace data':'بيانات مساحة العمل','Settings':'الإعدادات','Appearance':'الوضع','Workspace':'مساحة العمل','Operations':'العمليات','Command Center':'مركز التحكم','Digital Twin':'التوأم الرقمي','Readiness Audit':'تدقيق الجاهزية','Release Center':'مركز الإصدار','Search':'البحث','Glossary':'المصطلحات','Privacy':'الخصوصية','Contact':'اتصل بنا','Sources':'المصادر','Trust':'الثقة','Learn':'تعلم',
    'What is Print Prep Lab?':'ما هو Print Prep Lab؟','Why do people use it?':'لماذا يستخدمه الناس؟','Who is it for?':'من يمكنه استخدامه؟','Who searches for it?':'من يبحث عنه؟','Accuracy':'الدقة','Fewer errors':'أخطاء أقل','Save time':'توفير الوقت','One workflow':'مسار عمل واحد','Clear print decisions':'قرارات طباعة واضحة','Check before printing':'افحص قبل الطباعة','Fast, practical tools':'أدوات سريعة وعملية','From file to release':'من الملف حتى الإصدار','Commercial and digital printers':'المطابع التجارية والرقمية','Graphic designers':'مصممو الجرافيك','Packaging teams':'فرق التعبئة والتغليف','Print sellers and small brands':'بائعو المطبوعات والعلامات الصغيرة','Students and print labs':'الطلاب ومعامل الطباعة','People preparing files for print':'أشخاص يجهزون ملفات للطباعة','Print-size and costing calculators':'حاسبات المقاسات والتكاليف','Preflight and file checks':'فحص ما قبل الطباعة والملفات','Production planning workflows':'مسارات تخطيط الإنتاج',
    'Welcome back':'مرحبًا بك','Everything you need before print, in one organized workspace. Professional tools, clear results, fewer surprises.':'كل ما تحتاجه قبل الطباعة في مساحة عمل منظمة واحدة. أدوات احترافية ونتائج واضحة ومفاجآت أقل.','Start a new job':'ابدأ مهمة جديدة','Explore tools':'استكشف الأدوات','Popular tools':'أدوات شائعة','View all tools →':'عرض كل الأدوات ←','Print costing':'حساب تكلفة الطباعة','Packaging planner':'مخطط التغليف','Check now →':'افحص الآن ←','Calculate →':'احسب ←','Plan now →':'خطط الآن ←','Start →':'ابدأ ←','Tip of the day':'نصيحة اليوم','professional tools':'أداة احترافية','file processing':'معالجة الملفات','sign-ups required':'تسجيل مطلوب','visible formulas':'معادلات واضحة','formulas & assumptions':'المعادلات والافتراضات',
    'Print Job Studio':'استوديو مهمة الطباعة','Batch Print Checker':'فاحص الطباعة المتعدد','Specification profiles':'ملفات المواصفات','Preflight Engine':'محرك فحص ما قبل الطباعة','Print Preflight Checker':'فاحص ما قبل الطباعة','Print Quote Comparator':'مقارن عروض الطباعة','Print Preparation Workspace':'مساحة تجهيز الطباعة','Job brief':'ملخص المهمة','Job Brief':'ملخص المهمة','File Manifest':'بيان الملفات','File Delivery Manifest':'بيان تسليم الملفات','Sheet Yield / N-up Planner':'مخطط إنتاجية الورق والتجميع','Wall / Gallery Layout':'تخطيط الجدار والمعرض','Troubleshooting Center':'مركز استكشاف المشكلات','Unified Search':'البحث الموحد','Proof Sheet Builder':'منشئ ورقة الإثبات','Scenario Matrix':'مصفوفة السيناريوهات','Prepress Lab':'مختبر ما قبل الطباعة','Job Costing':'تكلفة المهمة','Production Capacity Planner':'مخطط الطاقة الإنتاجية','Imposition & Cut Planner':'مخطط التجميع والقص','Print QA History':'سجل جودة الطباعة','Change Impact Engine':'محرك أثر التغيير','Roll Media Planner':'مخطط خامات الرول','Packaging & Shipping Intelligence':'ذكاء التغليف والشحن','Production Risk Register':'سجل مخاطر الإنتاج','Job Timeline':'الخط الزمني للمهمة','Multi-job Queue':'طابور المهام','Stock Coverage':'تغطية المخزون','Waste/Yield Ledger':'سجل الهدر والإنتاجية','Approval Matrix':'مصفوفة الموافقات','Release Packet Builder':'منشئ حزمة الإصدار','Manifest Revision Diff':'مقارنة مراجعات البيان','Calibration/Device Registry':'سجل المعايرة والأجهزة','CAPA':'الإجراءات التصحيحية والوقائية','Procurement Lead-time':'مهلة التوريد','Audit Snapshots':'لقطات التدقيق','Fold Panel Planner':'مخطط ألواح الطي','Spine & Book-block Planner':'مخطط كعب الكتاب وكتلته','Roll Diameter Calculator':'حاسبة قطر الرول','Pallet Load Planner':'مخطط حمولة البالتة','Provider Capability Matrix':'مصفوفة قدرات المورد','Job Core & Revision Engine':'نواة المهمة ومحرك المراجعات','Vendor Handoff':'تسليم المورد','Compliance & Evidence Center':'مركز الامتثال والأدلة','Production Archive':'أرشيف الإنتاج','Print Prep Command Center':'مركز تحكم Print Prep','Enterprise Dashboard':'لوحة المؤسسة','Digital Production Twin':'التوأم الرقمي للإنتاج','Release Readiness Audit':'تدقيق جاهزية الإصدار','Release Center 2.0':'مركز الإصدار 2.0','Fulfilment Intelligence':'ذكاء التنفيذ والتسليم','Production Analytics':'تحليلات الإنتاج','Multi-job Schedule Optimizer':'محسن جدولة المهام','Material & Procurement Intelligence':'ذكاء الخامات والتوريد','Supplier Intelligence':'ذكاء الموردين','Local Automation & Next Action':'الأتمتة المحلية والخطوة التالية','Advanced Signature Planner':'مخطط الملازم المتقدم','Color Control Board':'لوحة التحكم اللوني','Finishing Intelligence':'ذكاء التشطيب','Customer Handoff':'تسليم العميل','Production Knowledge Base':'قاعدة معرفة الإنتاج',
    'Quantity':'الكمية','Material':'الخامة','Deadline':'الموعد النهائي','Owner':'المسؤول','Width':'العرض','Height':'الارتفاع','Unit':'الوحدة','Target':'الهدف','Target PPI':'PPI المستهدف','Effective PPI':'PPI الفعلي','Resolution':'الدقة','Geometry':'الهندسة','Specs':'المواصفات','Specification':'المواصفة','Preflight':'فحص ما قبل الطباعة','Manifest':'بيان الملفات','Finishing':'التشطيب','Color':'اللون','Yield':'الإنتاجية','Release':'الإصدار','Revision':'المراجعة','Quality':'الجودة','Supply':'التوريد','Capacity':'الطاقة الإنتاجية','Approvals':'الموافقات','Queue':'الطابور','Stock':'المخزون','Provider':'المورد','Filename':'اسم الملف','Pixel dimensions':'أبعاد البكسل','Viewing distance':'مسافة المشاهدة','Trim size':'مقاس القص','Trim width':'عرض القص','Trim height':'ارتفاع القص','Safe margin mm':'هامش الأمان مم','Bleed each edge (mm)':'النزف لكل حافة (مم)','Bleed / edge mm':'النزف لكل حافة مم','Page count':'عدد الصفحات','Sheet count':'عدد الأوراق','Columns':'الأعمدة','Critical':'حرج','High':'مرتفع','Normal':'عادي','Required':'مطلوب','Blocked':'محظور','Pass':'ناجح','Review':'مراجعة','Clear':'مسح','Open':'فتح','Reset':'إعادة ضبط','Copy':'نسخ','Download':'تنزيل','Print':'طباعة','Export CSV':'تصدير CSV','Export JSON':'تصدير JSON','Download JSON':'تنزيل JSON','Copy summary':'نسخ الملخص','Copy report':'نسخ التقرير','Save locally':'حفظ محليًا','Save revision':'حفظ المراجعة','Add requirement':'إضافة متطلب','Run audit':'تشغيل التدقيق','Refresh dashboard':'تحديث اللوحة','Refresh twin':'تحديث التوأم','Refresh analytics':'تحديث التحليلات','Refresh command view':'تحديث مركز التحكم','Rebuild packet':'إعادة بناء الحزمة','Download packet':'تنزيل الحزمة',
    'Fit · keep full image':'ملاءمة · احتفظ بالصورة كاملة','Fill · crop':'ملء · قص','Auto orientation':'اتجاه تلقائي','Use width × height as entered':'استخدم العرض × الارتفاع كما أُدخل','Manual settings':'إعدادات يدوية','Manual target':'هدف يدوي','No images loaded':'لا توجد صور محملة','All':'الكل','Meets':'مطابق','Limited':'محدود','Close':'قريب','Needs attention first':'الأكثر احتياجًا للمراجعة','Highest PPI':'أعلى PPI','Lowest PPI':'أقل PPI','Least crop':'أقل قص','Largest safe footprint':'أكبر مساحة آمنة','File name':'اسم الملف','Apply recommended size':'تطبيق المقاس المقترح',
    'Explain the decision, not just the number.':'اشرح القرار، وليس الرقم فقط.','Example':'مثال','Interpretation':'التفسير','Boundary':'الحدود','Production context around the calculation.':'سياق الإنتاج المحيط بالحساب.','Why it matters:':'لماذا يهم:','Use this concept →':'استخدم هذا المفهوم ←','Operating rule':'قاعدة التشغيل','Practical workflow':'مسار عمل عملي','Why this module exists':'لماذا توجد هذه الوحدة','Local-first print planning from file preparation through release control.':'تخطيط طباعة محلي يبدأ من تجهيز الملف وينتهي بالتحكم في الإصدار.','Open module →':'افتح الوحدة ←','Open tool →':'افتح الأداة ←','Open →':'افتح ←','✓ Browser-local':'✓ محلي داخل المتصفح','✓ Formula shown':'✓ المعادلة ظاهرة','✓ Explicit status':'✓ حالة واضحة','✓ Exportable record':'✓ سجل قابل للتصدير','✓ Editable assumptions':'✓ افتراضات قابلة للتعديل','✓ Local state':'✓ حالة محلية','✓ Exportable evidence':'✓ أدلة قابلة للتصدير','✓ Assumptions visible':'✓ الافتراضات ظاهرة','✓ Reviewable state':'✓ حالة قابلة للمراجعة','✓ Portable export':'✓ تصدير قابل للنقل',
    'inches':'بوصة','inch':'بوصة','cm':'سم','mm':'مم','pixels':'بكسل','px':'بكسل','Other':'أخرى','Photo / art print':'صورة / طباعة فنية','Document / text':'مستند / نص','Poster / wall display':'بوستر / عرض جداري','Book cover / layout':'غلاف كتاب / تخطيط','Saddle stitch':'تدبيس سرجي','PDF':'PDF','JPEG':'JPEG','TIFF':'TIFF','PNG':'PNG','A4':'A4','A3':'A3','SRA3':'SRA3','A2':'A2','Letter':'Letter','Tabloid':'Tabloid'
  };
  const normalize=s=>(s||'').replace(/\s+/g,' ').trim();
  const safeTextTags=new Set(['H1','H2','H3','H4','H5','H6','LABEL','BUTTON','OPTION','LEGEND','TH','SUMMARY','SMALL','STRONG','B']);
  const pageTitleAR={
    'studio':'استوديو مهمة الطباعة','batch':'فاحص الطباعة المتعدد','specs':'ملفات المواصفات','preflight':'فحص ما قبل الطباعة','workspace':'مساحة تجهيز الطباعة','sheet-planner':'مخطط إنتاجية الورق','quote-compare':'مقارن عروض الطباعة','vault':'خزنة مساحة العمل','wall-layout':'تخطيط الجدار والمعرض','troubleshoot':'مركز استكشاف المشكلات','glossary':'المصطلحات','search':'البحث','file-manifest':'بيان تسليم الملفات','job-brief':'ملخص المهمة','jobs':'المهام','inspector':'فاحص ملفات الطباعة','proof-sheet':'منشئ ورقة الإثبات','scenarios':'مصفوفة السيناريوهات','prepress-lab':'مختبر ما قبل الطباعة','operations':'مركز العمليات','job-costing':'تكلفة المهمة','capacity-planner':'مخطط الطاقة الإنتاجية','imposition-planner':'مخطط التجميع والقص','qa-history':'سجل جودة الطباعة','change-impact':'محرك أثر التغيير','roll-media':'مخطط خامات الرول','packaging':'التغليف والشحن','risk-register':'سجل مخاطر الإنتاج','timeline':'الخط الزمني للمهمة','queue-planner':'مخطط طابور المهام','stock-coverage':'تغطية المخزون','waste-ledger':'سجل الهدر والإنتاجية','approval-matrix':'مصفوفة الموافقات','release-packet':'حزمة الإصدار','revision-diff':'مقارنة المراجعات','calibration-registry':'سجل المعايرة والأجهزة','capa':'الإجراءات التصحيحية والوقائية','procurement':'التوريد والمهل الزمنية','audit-log':'سجل التدقيق','fold-planner':'مخطط ألواح الطي','spine-planner':'مخطط كعب الكتاب','roll-diameter':'حاسبة قطر الرول','pallet-planner':'مخطط حمولة البالتة','provider-matrix':'مصفوفة قدرات المورد','job-core':'نواة المهمة والمراجعات','vendor-handoff':'تسليم المورد','compliance-center':'مركز الامتثال والأدلة','production-archive':'أرشيف الإنتاج','command-center':'مركز التحكم','enterprise-dashboard':'لوحة المؤسسة','digital-twin':'التوأم الرقمي للإنتاج','readiness-audit':'تدقيق جاهزية الإصدار','release-center':'مركز الإصدار','fulfillment-center':'ذكاء التنفيذ والتسليم','production-analytics':'تحليلات الإنتاج','schedule-optimizer':'محسن الجدولة','material-intelligence':'ذكاء الخامات والتوريد','supplier-intelligence':'ذكاء الموردين','automation-lab':'الأتمتة المحلية','signature-planner':'مخطط الملازم المتقدم','color-control':'لوحة التحكم اللوني','finishing-intelligence':'ذكاء التشطيب','customer-handoff':'تسليم العميل','knowledge-base':'قاعدة معرفة الإنتاج'
  };
  const icon=(path)=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">${path}</svg>`;
  function shellMarkup(type='top'){
    const brand=`<a class="ppl-brand" href="/"><i class="ppl-logo"></i><span>Print Prep Lab</span></a>`;
    const top=`<header class="ppl-topbar ${type==='dynamic'?'ppl-dynamic-topbar':''}">${brand}<div class="ppl-search">${icon('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>')}<input data-placeholder-en="Search a tool or feature..." data-placeholder-ar="ابحث عن أداة أو ميزة..." placeholder="Search a tool or feature..." aria-label="Search tools and features"><span class="ppl-kbd">Ctrl K</span></div><nav class="ppl-nav"><a href="/workspace#workspace-tools" data-en="Tools" data-ar="الأدوات">Tools</a><a href="/jobs" data-en="Projects" data-ar="المشاريع">Projects</a><a href="/guides" data-en="Resources" data-ar="الموارد">Resources</a><a href="/sizes" data-en="Print sizes" data-ar="مقاسات الطباعة">Print sizes</a><a href="/troubleshoot" data-en="Help center" data-ar="مركز المساعدة">Help center</a></nav><div class="ppl-user"><select class="ppl-lang" data-lang aria-label="Language"><option value="en">EN</option><option value="ar">AR</option></select><button class="icon-btn mobile-only" data-mobile-menu aria-label="Menu">☰</button></div></header>`;
    return top;
  }
  function sidebarMarkup(dynamic=false){return `<aside class="ppl-sidebar ${dynamic?'ppl-dynamic-sidebar':''}"><nav class="ppl-side-nav">
    <a href="/">${icon('<path d="M3 11l9-8 9 8v9H3z"/>')}<span data-en="Home" data-ar="الرئيسية">Home</span></a>
    <a href="/command-center">${icon('<circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/>')}<span data-en="Dashboard" data-ar="لوحة التحكم">Dashboard</span></a>
    <a href="/jobs">${icon('<path d="M4 6h16v13H4z"/><path d="M8 6V4h8v2"/>')}<span data-en="Projects" data-ar="المشاريع">Projects</span></a>
    <a href="/workspace#workspace-tools">${icon('<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/>')}<span data-en="All tools" data-ar="جميع الأدوات">All tools</span></a>
    <a href="/tools/print-readiness-checker">${icon('<path d="M6 3h9l4 4v14H6z"/><path d="M14 3v5h5M9 13l2 2 4-5"/>')}<span data-en="File check" data-ar="فحص الملفات">File check</span></a>
    <a href="/job-costing">${icon('<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h3M13 11h3M8 15h3M13 15h3"/>')}<span data-en="Costing" data-ar="حساب التكاليف">Costing</span></a>
    <a href="/operations">${icon('<path d="M4 20V9h6v11M14 20V4h6v16"/>')}<span data-en="Production planning" data-ar="تخطيط الإنتاج">Production planning</span></a>
    <a href="/supplier-intelligence">${icon('<circle cx="8" cy="8" r="3"/><circle cx="16" cy="8" r="3"/><path d="M2 20c0-4 2-7 6-7s6 3 6 7M10 20c0-4 2-7 6-7s6 3 6 7"/>')}<span data-en="Suppliers" data-ar="الموردون">Suppliers</span></a>
    <a href="/release-center">${icon('<rect x="5" y="4" width="14" height="16" rx="2"/><path d="M9 4V2h6v2M9 11h6M9 15h4"/>')}<span data-en="Release center" data-ar="مركز الإصدار">Release center</span></a>
    <a href="/production-analytics">${icon('<path d="M4 20V12M9 20V4M14 20v-6M19 20V8"/>')}<span data-en="Reports & analytics" data-ar="التقارير والتحليلات">Reports & analytics</span></a>
    <a href="/vault">${icon('<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 00-.1-1l2-1.5-2-3.5-2.4 1a7 7 0 00-1.7-1L14.5 3h-5l-.4 3a7 7 0 00-1.7 1L5 6 3 9.5 5 11a7 7 0 000 2l-2 1.5L5 18l2.4-1a7 7 0 001.7 1l.4 3h5l.4-3a7 7 0 001.7-1l2.4 1 2-3.5-2-1.5a7 7 0 00.1-1z"/>')}<span data-en="Workspace data" data-ar="بيانات مساحة العمل">Workspace data</span></a></nav></aside>`}
  function injectDynamicShell(){
    if(document.querySelector('.ppl-topbar') || document.querySelector('.ppl-global-app') || location.pathname==='/') return;
    document.body.classList.add('ppl-dynamic-shell');
    document.body.insertAdjacentHTML('afterbegin',sidebarMarkup(true));
    document.body.insertAdjacentHTML('afterbegin',shellMarkup('dynamic'));
  }
  function seedTranslations(){
    document.querySelectorAll('*').forEach(el=>{
      if(!safeTextTags.has(el.tagName) || el.hasAttribute('data-i18n-dynamic')) return;
      if(el.children.length) return;
      const txt=normalize(el.textContent);
      if(!txt || !T[txt] || el.dataset.en || el.dataset.ar) return;
      el.dataset.en=txt; el.dataset.ar=T[txt];
    });
    const stem=location.pathname.split('/').filter(Boolean).pop()||'';
    const h1=document.querySelector('main h1, main h2, h1');
    if(h1 && pageTitleAR[stem] && !h1.dataset.ar){
      const en=normalize(h1.textContent); if(en){h1.dataset.en=en;h1.dataset.ar=pageTitleAR[stem]}
    }
  }
  function applyLang(lang){
    if(lang!=='ar') lang='en';
    document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';
    try{localStorage.setItem(KEY,lang)}catch(e){}
    document.querySelectorAll('[data-en][data-ar]:not([data-i18n-dynamic])').forEach(el=>{el.textContent=el.dataset[lang]||el.dataset.en});
    document.querySelectorAll('[data-placeholder-en][data-placeholder-ar]').forEach(el=>{el.placeholder=el.dataset[lang==='ar'?'placeholderAr':'placeholderEn']||''});
    document.querySelectorAll('[data-lang]').forEach(el=>{el.value=lang});
    document.body.classList.toggle('ppl-ar',lang==='ar');
  }
  function closeMenu(){document.body.classList.remove('ppl-menu-open');document.querySelector('.ppl-global-app')?.classList.remove('ppl-menu-open')}
  function bind(){
    document.addEventListener('change',e=>{if(e.target.matches('[data-lang]')) applyLang(e.target.value)});
    document.addEventListener('click',e=>{if(e.target.closest('[data-mobile-menu]')){document.body.classList.toggle('ppl-menu-open');document.querySelector('.ppl-global-app')?.classList.toggle('ppl-menu-open')} if(e.target.classList.contains('ppl-mobile-overlay')) closeMenu()});
    document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();document.querySelector('.ppl-search input')?.focus()} if(e.key==='Escape') closeMenu()});
    document.querySelectorAll('.ppl-search input').forEach(inp=>inp.addEventListener('keydown',e=>{if(e.key==='Enter'&&inp.value.trim()) location.href='/search?q='+encodeURIComponent(inp.value.trim())}));
  }
  function bindAdvancedWorkspace(){
    const btn=document.querySelector('.ppl-advanced-toggle');
    const sections=[...document.querySelectorAll('.ppl-advanced-section')];
    if(!btn||!sections.length) return;
    let open=false; try{open=localStorage.getItem('ppl-advanced-workspace')==='1'}catch(e){}
    const render=()=>{
      sections.forEach(sec=>{sec.hidden=!open;sec.classList.toggle('ppl-advanced-open',open)});
      btn.setAttribute('aria-expanded',String(open));
      const lang=document.documentElement.lang==='ar'?'ar':'en';
      btn.textContent=open?(lang==='ar'?'إخفاء الأدوات المتقدمة':'Hide advanced tools'):(btn.dataset[lang]||btn.dataset.en||'Show advanced tools');
    };
    btn.addEventListener('click',()=>{open=!open;try{localStorage.setItem('ppl-advanced-workspace',open?'1':'0')}catch(e){}render()});
    document.addEventListener('change',e=>{if(e.target.matches('[data-lang]'))setTimeout(render,0)});
    render();
  }
  function initialLanguage(){let lang='en';try{const q=new URLSearchParams(location.search).get('lang');if(q==='en'||q==='ar'){localStorage.setItem(KEY,q);localStorage.setItem('ppl-interface-language',q);return q}const current=localStorage.getItem(KEY);const legacy=localStorage.getItem('ppl-interface-language');lang=(current==='ar'||current==='en')?current:((legacy==='ar'||legacy==='en')?legacy:'en');localStorage.setItem(KEY,lang);localStorage.setItem('ppl-interface-language',lang)}catch(e){}return lang}
  function init(){injectDynamicShell();seedTranslations();bind();applyLang(initialLanguage());bindAdvancedWorkspace()}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();


/* v109 whole-page language fallback: exact UI strings use local translations; remaining long-form copy uses Google Translate when available. */
(()=>{
  const GT_KEY='ppl-google-translate-loaded';
  function setCookie(lang){
    const value=lang==='ar'?'/en/ar':'/en/en';
    document.cookie=`googtrans=${value};path=/;SameSite=Lax`;
    document.cookie=`googtrans=${value};path=/;domain=${location.hostname};SameSite=Lax`;
  }
  function loadGT(){
    if(document.getElementById('google_translate_element')) return;
    const host=document.createElement('div');host.id='google_translate_element';document.body.appendChild(host);
    window.googleTranslateElementInit=()=>{
      try{
        new google.translate.TranslateElement({pageLanguage:'en',includedLanguages:'ar,en',autoDisplay:false},'google_translate_element');
        localStorage.setItem(GT_KEY,'1');
      }catch(e){}
    };
    const s=document.createElement('script');s.src='https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';s.async=true;s.onerror=()=>{};document.head.appendChild(s);
  }
  function exactNoTranslate(){document.querySelectorAll('[data-en][data-ar]').forEach(el=>el.classList.add('notranslate'))}
  document.addEventListener('DOMContentLoaded',()=>{
    exactNoTranslate();
    const stem=location.pathname.split('/').filter(Boolean).pop()||'home';
    const localPages=new Set(['home','studio','batch','preflight','workspace','print-readiness-checker','prepress-lab','vault','wall-layout','capacity-planner','imposition-planner','glossary','scenarios','inspector','proof-sheet']);
    let lang='en';try{lang=localStorage.getItem('print-prep-lab-language')||'en'}catch(e){}
    if(!localPages.has(stem)&&lang==='ar'){setCookie('ar');loadGT()}
    document.addEventListener('change',e=>{
      if(!e.target.matches('[data-lang],.ppl-lang-select,.v103-lang')) return;
      const lang=e.target.value==='ar'?'ar':'en';try{localStorage.setItem('print-prep-lab-language',lang);localStorage.setItem('ppl-interface-language',lang)}catch(e){};
      if(localPages.has(stem)) return;
      setCookie(lang);
      if(lang==='ar'){loadGT();setTimeout(()=>location.reload(),120)}
      else {try{localStorage.setItem('print-prep-lab-language','en')}catch(e){};setTimeout(()=>location.reload(),80)}
    },true);
  });
})();

/* v112 local Arabic layer: deterministic, browser-local translations with no runtime translation service dependency. */
(()=>{
  'use strict';
  const KEY='print-prep-lab-language';
  const MAP_URL='/ppl-ar-v112.json';
  const SELECTOR='h1,h2,h3,h4,h5,h6,p,label,button,option,legend,th,td,summary,small,strong,b,a,span,em,li,dt,dd,div';
  const norm=s=>(s||'').replace(/\s+/g,' ').trim();
  let map=null,loading=null,observer=null,scheduled=false;
  const textMemory=new WeakMap();
  const lang=()=>{try{return localStorage.getItem(KEY)==='ar'?'ar':'en'}catch(e){return document.documentElement.lang==='ar'?'ar':'en'}};
  function leaf(el){return !el.children.length && !el.matches('[data-i18n-dynamic]')}
  function remember(el,attr,key){if(!el.dataset[key]){const v=attr?el.getAttribute(attr):norm(el.textContent);if(v)el.dataset[key]=v}return el.dataset[key]||''}
  function tr(value){
    if(map&&map[value]) return map[value];
    if(!map||typeof value!=='string') return '';
    let m;
    if((m=value.match(/^Sheet (\d+)( · outermost| · innermost)?$/))){
      const edge=m[2]===' · outermost'?' · الخارجية':m[2]===' · innermost'?' · الداخلية':'';
      return `ورقة ${m[1]}${edge}`;
    }
    if((m=value.match(/^([\d.,]+) mm planning offset$/))) return `${m[1]} مم إزاحة تخطيطية`;
    if((m=value.match(/^Downloaded (\d+) local categories\. No image bytes were included\.$/))) return `تم تنزيل ${m[1]} فئة محلية. لم يتم تضمين بيانات صور.`;
    if((m=value.match(/^Restore complete in (merge|replace) mode \((\d+) categories\)\.$/))) return `اكتملت الاستعادة بوضع ${m[1]==='merge'?'الدمج':'الاستبدال'} (${m[2]} فئة).`;
    if((m=value.match(/^(\d+) local categories detected\. Legacy v1 backups are migrated in memory before restore\.$/))) return `تم اكتشاف ${m[1]} فئة محلية. تُرحّل نسخ v1 القديمة في الذاكرة قبل الاستعادة.`;
    if((m=value.match(/^(\d+) frames fit with (centered|custom) placement\.$/))) return `يتسع التخطيط لـ ${m[1]} إطار مع تموضع ${m[2]==='centered'?'متمركز':'مخصص'}.`;
    if((m=value.match(/^Footprint exceeds the wall by ([\d.,]+) mm horizontally and ([\d.,]+) mm vertically\.$/))) return `تتجاوز مساحة التخطيط الجدار بمقدار ${m[1]} مم أفقيا و${m[2]} مم رأسيا.`;
    if((m=value.match(/^(\d+) × (\d+) frames$/))) return `${m[1]} × ${m[2]} إطار`;
    if((m=value.match(/^([\d.,]+) × ([\d.,]+) (mm|cm|in) gaps$/))) return `${m[1]} × ${m[2]} ${m[3]==='mm'?'مم':m[3]==='cm'?'سم':'بوصة'} مسافات`;
    if((m=value.match(/^The schedule uses ([\d.]+) of ([\d.]+) available hours, leaving ([\d.]+) hours of modeled buffer\.$/))) return `يستخدم الجدول ${m[1]} من أصل ${m[2]} ساعة متاحة، ويتبقى ${m[3]} ساعة كهامش محسوب.`;
    if((m=value.match(/^The schedule exceeds the window by ([\d.]+) hours\. At the same rated speed, utilization would need to be ([\d.]+)% after setup\.$/))) return `يتجاوز الجدول النافذة بمقدار ${m[1]} ساعة. ومع السرعة الاسمية نفسها يجب أن تصل نسبة الاستغلال إلى ${m[2]}% بعد التجهيز.`;
    if((m=value.match(/^(Rotated|Normal) piece orientation gives (\d+)-up\.$/))) return `${m[1]==='Rotated'?'اتجاه القطعة المدوّر':'اتجاه القطعة العادي'} يعطي ${m[2]}-up.`;
    if((m=value.match(/^Use a (\d+) × (\d+) grid on a ([\d.]+) × ([\d.]+) mm usable area\. ([\d,]+) sellable pieces require ([\d,]+) sheets before any additional production spoilage\.$/))) return `استخدم شبكة ${m[1]} × ${m[2]} على مساحة قابلة للاستخدام ${m[3]} × ${m[4]} مم. تحتاج ${m[5]} قطعة قابلة للبيع إلى ${m[6]} ورقة قبل أي هالك إنتاجي إضافي.`;
    if((m=value.match(/^(\d+) of (\d+) terms$/))) return `${m[1]} من ${m[2]} مصطلح`;
    if((m=value.match(/^(\d+) scenarios$/))) return `${m[1]} سيناريو`;
    if((m=value.match(/^([\d.]+)% crop$/))) return `${m[1]}% قص`;
    if((m=value.match(/^([\d.]+)% unused(?: paper)?$/))) return `${m[1]}% غير مستخدم`;
    if((m=value.match(/^(Portrait|Landscape) · ([\d.,]+) PPI · ([\d.]+)% (crop|unused paper) · score ([\d.]+)\/100\.$/))) return `${m[1]==='Portrait'?'رأسي':'أفقي'} · ${m[2]} PPI · ${m[3]}% ${m[4]==='crop'?'قص':'ورق غير مستخدم'} · الدرجة ${m[5]}/100.`;
    if((m=value.match(/^Inspecting (\d+) file\(s\)…$/))) return `جار فحص ${m[1]} ملف…`;
    if((m=value.match(/^Inspected (\d+) file\(s\) locally\.$/))) return `تم فحص ${m[1]} ملف محليا.`;
    if((m=value.match(/^Density tag: ([\d.,]+) × ([\d.,]+) (dpi|dpcm) \(([^)]+)\)\. This does not determine effective print PPI\.$/))) return `وسم كثافة: ${m[1]} × ${m[2]} ${m[3]} (${m[4]}). هذا لا يحدد PPI الفعلي للطباعة.`;
    if((m=value.match(/^(\d+) items$/))) return `${m[1]} عنصر`;
    if((m=value.match(/^(\d+) pages$/))) return `${m[1]} صفحة`;
    if((m=value.match(/^([\d.,]+) (kg|g|mm|cm|h|d)$/))){const units={kg:'كجم',g:'جم',mm:'مم',cm:'سم',h:'ساعة',d:'يوم'};return `${m[1]} ${units[m[2]]}`;}
    return '';
  }
  function applyEl(el,l){
    if(!map||!leaf(el)||el.closest('#google_translate_element'))return;
    if(el.hasAttribute('data-en')&&el.hasAttribute('data-ar'))return;
    const en=remember(el,null,'pplLocalEn'); if(!en)return;
    const ar=tr(en); if(!ar)return;
    el.textContent=l==='ar'?ar:en;
    el.classList.add('notranslate');
  }
  function applyMixed(el,l){
    if(!map||!el||!el.children?.length||el.closest?.('#google_translate_element'))return;
    [...el.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE).forEach(n=>{
      let en=textMemory.get(n); if(!en){en=norm(n.nodeValue);if(en)textMemory.set(n,en)}
      if(!en)return; const ar=tr(en); if(!ar)return;
      const raw=n.nodeValue||'',lead=(raw.match(/^\s*/)||[''])[0],trail=(raw.match(/\s*$/)||[''])[0];
      n.nodeValue=lead+(l==='ar'?ar:en)+trail;
    });
  }
  function applyAttrs(root,l){
    root.querySelectorAll?.('[placeholder]').forEach(el=>{const en=remember(el,'placeholder','pplPlaceholderEn');const ar=tr(en);if(ar)el.setAttribute('placeholder',l==='ar'?ar:en)});
    root.querySelectorAll?.('[aria-label]').forEach(el=>{const en=remember(el,'aria-label','pplAriaEn');const ar=tr(en);if(ar)el.setAttribute('aria-label',l==='ar'?ar:en)});
    root.querySelectorAll?.('[title]').forEach(el=>{const en=remember(el,'title','pplTitleEn');const ar=tr(en);if(ar)el.setAttribute('title',l==='ar'?ar:en)});
  }
  function apply(root=document){
    if(!map)return; const l=lang();
    if(root.matches?.(SELECTOR)){applyEl(root,l);applyMixed(root,l)}
    root.querySelectorAll?.(SELECTOR).forEach(el=>{applyEl(el,l);applyMixed(el,l)});
    applyAttrs(root,l);
    const base=document.documentElement.dataset.pplTitleEn||document.title;
    if(!document.documentElement.dataset.pplTitleEn)document.documentElement.dataset.pplTitleEn=base;
    const arTitle=tr(base); if(arTitle)document.title=l==='ar'?arTitle:base;
    document.documentElement.lang=l;document.documentElement.dir=l==='ar'?'rtl':'ltr';
  }
  function schedule(root=document){if(scheduled)return;scheduled=true;queueMicrotask(()=>{scheduled=false;apply(root)})}
  function load(){
    if(map)return Promise.resolve(map);if(loading)return loading;
    loading=fetch(MAP_URL,{cache:'force-cache'}).then(r=>{if(!r.ok)throw new Error('local Arabic map '+r.status);return r.json()}).then(m=>{map=m;window.PPL_AR_V112=m;apply();return m}).catch(()=>({}));
    return loading;
  }
  function init(){
    load();
    document.addEventListener('ppl:language-applied',()=>schedule());
    document.addEventListener('change',e=>{if(e.target.matches?.('[data-lang],.ppl-lang-select,.v103-lang'))setTimeout(()=>schedule(),0)},true);
    observer=new MutationObserver(ms=>{if(!map)return;for(const m of ms){if(m.type==='childList'){m.addedNodes.forEach(n=>{if(n.nodeType===1)schedule(n.parentElement||document)})}}});
    observer.observe(document.body,{childList:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
