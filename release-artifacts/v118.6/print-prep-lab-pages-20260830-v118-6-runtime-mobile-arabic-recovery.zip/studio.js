(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const isAr = () => document.documentElement.lang === 'ar';
  const tx = (en, ar) => isAr() ? ar : en;
  const esc = (s='') => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const el = {
    form: $('job-form'),
    project: $('project-name'), provider: $('provider-name'), jobType: $('job-type'), viewing: $('viewing'), jobNote: $('job-note'),
    file: $('image-file'), drop: $('drop-zone'), fileNote: $('file-note'), clearImage: $('clear-image'),
    sourceW: $('source-w'), sourceH: $('source-h'), printW: $('print-w'), printH: $('print-h'), unit: $('unit'), swap: $('swap-size'),
    focusControls: $('focus-controls'), focusX: $('focus-x'), focusY: $('focus-y'), focusXOut: $('focus-x-out'), focusYOut: $('focus-y-out'), centerFocus: $('center-focus'),
    ppi: $('ppi'), bleed: $('bleed'), safe: $('safe'),
    verdict: $('verdict'), verdictLabel: $('verdict-label'), effectivePpi: $('effective-ppi'), verdictNote: $('verdict-note'),
    decision: $('decision-engine'), decisionBadge: $('decision-badge'), decisionSummary: $('decision-summary'), decisionActions: $('decision-actions'), decisionContext: $('decision-context'),
    ratioTitle: $('ratio-title'), cropLabel: $('crop-label'), ratioStage: $('ratio-stage'), imageBox: $('image-box'), compositionNote: $('composition-note'),
    primary: $('primary-results'), ladder: $('resolution-ladder'), maxTable: $('max-size-table'), matches: $('matches'),
    report: $('report'), copy: $('copy-report'), print: $('print-report'), copyStatus: $('copy-status'),
    specProfile: $('spec-profile'), specProfileNote: $('spec-profile-note'), clearProfile: $('clear-profile'),
    planName: $('plan-name'), savePlan: $('save-plan'), savedPlans: $('saved-plans'), loadPlan: $('load-plan'), deletePlan: $('delete-plan'), copyPlanLink: $('copy-plan-link'), openPreflight: $('open-preflight'), downloadReport: $('download-report'), resetStudio: $('reset-studio'), planStatus: $('plan-status')
  };

  const STORAGE_KEY = 'print-prep-lab-studio-plans-v1';
  const defaults = {
    project: '', provider: '', jobType: 'photo-art', viewing: 'normal', jobNote: '',
    sw: 6000, sh: 4000, pw: 20, ph: 16, unit: 'in', fit: 'fill', ppi: 300, bleed: 3, safe: 5, focusX: 50, focusY: 50
  };
  let fitMode = defaults.fit;
  let fileName = '';
  let imageObjectUrl = '';
  let lastCalc = null;

  const presets = {
    a4: [210, 297, 'mm'], letter: [8.5, 11, 'in'], '4x6': [4, 6, 'in'], '8x10': [8, 10, 'in'], '11x14': [11, 14, 'in'], '16x20': [16, 20, 'in']
  };
  const standardSizes = [
    ['A2', 420, 594, 'mm'], ['A3', 297, 420, 'mm'], ['A4', 210, 297, 'mm'], ['A5', 148, 210, 'mm'],
    ['US Letter', 8.5, 11, 'in'], ['US Legal', 8.5, 14, 'in'], ['4 × 6', 4, 6, 'in'], ['5 × 7', 5, 7, 'in'],
    ['8 × 10', 8, 10, 'in'], ['11 × 14', 11, 14, 'in'], ['12 × 18', 12, 18, 'in'], ['16 × 20', 16, 20, 'in']
  ];
  const jobTypeLabels = {
    'photo-art': 'Photo / art print', 'document-text': 'Document / text', 'poster-wall': 'Poster / wall display', 'book-layout': 'Book cover / layout', other: 'Other'
  };
  const viewingLabels = { close: 'Close viewing', normal: 'Normal viewing', distance: 'Viewed from farther away' };

  const n = (input, fallback = 0) => {
    const v = Number(input?.value);
    return Number.isFinite(v) ? v : fallback;
  };
  const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
  const fmt = (v, d = 2) => Number(v.toFixed(d)).toLocaleString('en-US', { maximumFractionDigits: d });
  const gcd = (a, b) => {
    a = Math.round(a); b = Math.round(b);
    while (b) { const t = b; b = a % b; a = t; }
    return a || 1;
  };
  const ratioLabel = (w, h) => {
    if (!w || !h) return '—';
    const g = gcd(w, h);
    if (w / g <= 30 && h / g <= 30) return `${Math.round(w / g)}:${Math.round(h / g)}`;
    return `${fmt(w / h, 3)}:1`;
  };
  const toIn = (v, u) => u === 'in' ? v : u === 'cm' ? v / 2.54 : v / 25.4;
  const toMm = (v, u) => u === 'mm' ? v : u === 'cm' ? v * 10 : v * 25.4;
  const fromMm = (v, u) => u === 'mm' ? v : u === 'cm' ? v / 10 : v / 25.4;
  const cropInfo = (sw, sh, pw, ph) => {
    const sr = sw / sh, tr = pw / ph;
    if (Math.abs(sr - tr) < 1e-10) return { retained: 1, crop: 0, cw: sw, ch: sh };
    if (sr > tr) {
      const cw = sh * tr;
      return { retained: cw / sw, crop: 1 - cw / sw, cw, ch: sh };
    }
    const ch = sw / tr;
    return { retained: ch / sh, crop: 1 - ch / sh, cw: sw, ch };
  };
  const specApi = window.PPL_SPEC_PROFILES;
  let activeSpec = null;
  function populateSpecProfiles() {
    if (!el.specProfile || !specApi) return;
    const current = el.specProfile.value;
    el.specProfile.innerHTML = `<option value="">${tx('Manual settings','إعدادات يدوية')}</option>` + specApi.all().map((p) => `<option value="${esc(p.id)}">${esc((p.custom ? tx('Custom · ','مخصص · ') : '') + (p.name || ''))}</option>`).join('');
    if (specApi.get(current)) el.specProfile.value = current;
  }
  function describeSpec(p) {
    if (!p) return tx('Choose a reusable process or custom provider profile, or keep the current manual values.','اختر عملية قابلة لإعادة الاستخدام أو ملف مزود مخصصا، أو احتفظ بالقيم اليدوية الحالية.');
    return isAr()?`${p.name}: ${p.ppi} PPI · نزف ${p.bleed} مم · أمان ${p.safe} مم. ${p.format || ''}`:`${p.name}: ${p.ppi} PPI · ${p.bleed} mm bleed · ${p.safe} mm safe. ${p.format || ''}`;
  }
  function applySpecProfile(p, fromTransfer = false) {
    activeSpec = p || null;
    if (!p) {
      if (el.specProfile) el.specProfile.value = '';
      if (el.specProfileNote) el.specProfileNote.textContent = describeSpec(null);
      update();
      return;
    }
    if (el.specProfile) el.specProfile.value = p.id || '';
    el.ppi.value = Math.max(1, Number(p.ppi) || 300);
    el.bleed.value = Math.max(0, Number(p.bleed) || 0);
    el.safe.value = Math.max(0, Number(p.safe) || 0);
    if (p.jobType && jobTypeLabels[p.jobType]) el.jobType.value = p.jobType;
    if (!el.provider.value.trim() && p.custom) el.provider.value = p.name;
    if (el.specProfileNote) el.specProfileNote.textContent = describeSpec(p);
    syncPpiButtons();
    update();
    if (fromTransfer) setStatus(el.planStatus, isAr()?`تم تطبيق ملف المواصفات «${p.name}». تحقّق منه مقابل مستند المزود الحالي.`:`Applied specification profile “${p.name}”. Verify it against the current provider document.`, 'success');
  }
  const currentFitButtons = () => document.querySelectorAll('[data-fit]');
  const currentPpiButtons = () => document.querySelectorAll('[data-ppi]');

  function placementFor(sw, sh, wi, hi, mode) {
    const sourceAspect = sw / sh;
    const targetAspect = wi / hi;
    if (mode === 'fill') {
      const crop = cropInfo(sw, sh, wi, hi);
      return { ...crop, imageWIn: wi, imageHIn: hi, sourceAspect, targetAspect };
    }
    let imageWIn = wi, imageHIn = hi;
    if (sourceAspect > targetAspect) imageHIn = wi / sourceAspect;
    else imageWIn = hi * sourceAspect;
    return { retained: 1, crop: 0, cw: sw, ch: sh, imageWIn, imageHIn, sourceAspect, targetAspect };
  }

  function standardCandidate(sw, sh, w, h, unit, target, currentArea) {
    const orientations = [[w, h], [h, w]].map(([ow, oh]) => {
      const wi = toIn(ow, unit), hi = toIn(oh, unit);
      const place = placementFor(sw, sh, wi, hi, fitMode);
      const effective = Math.min(place.cw / place.imageWIn, place.ch / place.imageHIn);
      const resolutionPenalty = Math.max(0, target - effective) / target;
      const sizeDistance = Math.abs(Math.log(Math.max(0.000001, (wi * hi) / currentArea)));
      const score = place.crop * 4 + resolutionPenalty * 2 + sizeDistance * 0.28;
      return { ow, oh, unit, wi, hi, place, effective, score };
    });
    return orientations.sort((a, b) => a.score - b.score)[0];
  }

  function setStatus(target, message, kind = '') {
    target.textContent = message;
    target.dataset.kind = kind;
  }

  function clearImagePreview() {
    if (imageObjectUrl) URL.revokeObjectURL(imageObjectUrl);
    imageObjectUrl = '';
    fileName = '';
    el.file.value = '';
    el.imageBox.style.backgroundImage = '';
    el.imageBox.classList.remove('has-image');
    el.fileNote.textContent = tx('No image selected. Enter pixel dimensions manually.','لم يتم اختيار صورة. أدخل أبعاد البكسل يدويا.');
    el.clearImage.hidden = true;
    update();
  }

  function readImage(file) {
    if (!file || !file.type.startsWith('image/')) {
      el.fileNote.textContent = tx('Choose a readable JPG, PNG, WebP or GIF image.','اختر صورة JPG أو PNG أو WebP أو GIF قابلة للقراءة.');
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      if (!img.naturalWidth || !img.naturalHeight) {
        URL.revokeObjectURL(url);
        el.fileNote.textContent = tx('The browser could not read pixel dimensions.','تعذر على المتصفح قراءة أبعاد البكسل.');
        return;
      }
      if (imageObjectUrl) URL.revokeObjectURL(imageObjectUrl);
      imageObjectUrl = url;
      fileName = file.name;
      el.sourceW.value = img.naturalWidth;
      el.sourceH.value = img.naturalHeight;
      el.imageBox.style.backgroundImage = `url(${JSON.stringify(url)})`;
      el.imageBox.classList.add('has-image');
      el.fileNote.textContent = isAr()?`${file.name} · ${img.naturalWidth.toLocaleString()} × ${img.naturalHeight.toLocaleString()} بكسل · معاينة محلية`:`${file.name} · ${img.naturalWidth.toLocaleString()} × ${img.naturalHeight.toLocaleString()} px · previewed locally`;
      el.clearImage.hidden = false;
      update();
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      el.fileNote.textContent = tx('The browser could not read this image.','تعذر على المتصفح قراءة هذه الصورة.');
    };
    img.src = url;
  }

  function setFitMode(mode) {
    fitMode = mode === 'fit' ? 'fit' : 'fill';
    currentFitButtons().forEach((x) => {
      const active = x.dataset.fit === fitMode;
      x.classList.toggle('active', active);
      x.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
    el.focusControls.classList.toggle('disabled', fitMode !== 'fill');
  }

  function syncPpiButtons() {
    const value = n(el.ppi, 300);
    currentPpiButtons().forEach((x) => x.classList.toggle('active', Number(x.dataset.ppi) === value));
  }

  function collectState(includeText = true) {
    const state = {
      sw: Math.max(1, Math.round(n(el.sourceW, defaults.sw))), sh: Math.max(1, Math.round(n(el.sourceH, defaults.sh))),
      pw: Math.max(0.01, n(el.printW, defaults.pw)), ph: Math.max(0.01, n(el.printH, defaults.ph)), unit: el.unit.value,
      fit: fitMode, ppi: Math.max(1, n(el.ppi, defaults.ppi)), bleed: Math.max(0, n(el.bleed, defaults.bleed)), safe: Math.max(0, n(el.safe, defaults.safe)),
      focusX: clamp(n(el.focusX, 50), 0, 100), focusY: clamp(n(el.focusY, 50), 0, 100),
      jobType: el.jobType.value, viewing: el.viewing.value
    };
    if (includeText) {
      state.project = el.project.value.trim();
      state.provider = el.provider.value.trim();
      state.jobNote = el.jobNote.value.trim();
    }
    return state;
  }

  function applyState(state, includeText = true) {
    if (!state || typeof state !== 'object') return;
    const val = (key, fallback) => state[key] ?? fallback;
    el.sourceW.value = val('sw', defaults.sw); el.sourceH.value = val('sh', defaults.sh);
    el.printW.value = val('pw', defaults.pw); el.printH.value = val('ph', defaults.ph);
    el.unit.value = ['in', 'cm', 'mm'].includes(val('unit', defaults.unit)) ? val('unit', defaults.unit) : defaults.unit;
    setFitMode(val('fit', defaults.fit));
    el.ppi.value = val('ppi', defaults.ppi); el.bleed.value = val('bleed', defaults.bleed); el.safe.value = val('safe', defaults.safe);
    el.focusX.value = clamp(Number(val('focusX', 50)) || 50, 0, 100); el.focusY.value = clamp(Number(val('focusY', 50)) || 50, 0, 100);
    el.jobType.value = jobTypeLabels[val('jobType', defaults.jobType)] ? val('jobType', defaults.jobType) : defaults.jobType;
    el.viewing.value = viewingLabels[val('viewing', defaults.viewing)] ? val('viewing', defaults.viewing) : defaults.viewing;
    if (includeText) {
      el.project.value = String(val('project', '')); el.provider.value = String(val('provider', '')); el.jobNote.value = String(val('jobNote', ''));
    }
    syncPpiButtons();
    update();
  }

  function preflightUrl() {
    const s = collectState(false);
    const p = new URLSearchParams({sw:String(s.sw),sh:String(s.sh),pw:String(s.pw),ph:String(s.ph),u:s.unit,fit:s.fit,ppi:String(s.ppi),b:String(s.bleed),safe:String(s.safe),sp:activeSpec?.id||''});
    return `/preflight#${p.toString()}`;
  }

  function buildDecision(calc) {
    const { effective, target, crop, fitMode: mode, safeWmm, safeHmm, pwmm, phmm, usedW, usedH, viewing, jobType } = calc;
    const ratio = effective / target;
    const actions = [];
    let level = 'ready', badge = tx('Math ready','الحسابات جاهزة'), summary = tx('The current geometry and source pixels support the selected numerical target.','الهندسة الحالية وبكسلات المصدر تدعمان الهدف الرقمي المحدد.');

    if (safeWmm <= 0 || safeHmm <= 0) {
      level = 'danger'; badge = tx('Fix margins','صحح الهوامش'); summary = tx('The selected safe margin collapses the protected area and needs to be corrected before handoff.','هامش الأمان المحدد يلغي المنطقة المحمية ويجب تصحيحه قبل التسليم.');
      actions.push(tx('Reduce the safe margin or increase the trim dimensions until a real protected area remains.','قلل هامش الأمان أو زد أبعاد القص حتى تبقى منطقة محمية فعلية.'));
    } else if (ratio < 0.8) {
      level = 'danger'; badge = tx('Resolution shortfall','نقص في الدقة'); summary = isAr()?`الصورة الموضوعة أقل بنسبة ${fmt((1-ratio)*100,0)}% من هدف التخطيط ${target} PPI.`:`The placed image is ${fmt((1 - ratio) * 100, 0)}% below the selected ${target} PPI planning target.`;
      actions.push(isAr()?`عند ${target} PPI أبق مساحة الصورة عند أو دون ${fmt(usedW/target,2)} × ${fmt(usedH/target,2)} بوصة ما لم تُعد أخذ العينات عمدا.`:`At ${target} PPI, keep the placed image at or below ${fmt(usedW / target, 2)} × ${fmt(usedH / target, 2)} inches unless you deliberately resample.`);
      actions.push(tx('Try a smaller trim, a ratio-friendlier size, or a lower target only when the print provider explicitly accepts it.','جرّب قصا أصغر أو مقاسا أقرب إلى نسبة المصدر، أو هدفا أقل فقط إذا قبله مزود الطباعة صراحة.'));
    } else if (ratio < 1) {
      level = 'review'; badge = tx('Review resolution','راجع الدقة'); summary = isAr()?`النتيجة قريبة من الهدف عند ${fmt(effective,0)} PPI لكنها لا تصل بالكامل إلى ${target} PPI.`:`The result is close to the selected target at ${fmt(effective, 0)} PPI, but does not fully reach ${target} PPI.`;
      actions.push(isAr()?`تقليل أبعاد الصورة الموضوعة إلى نحو ${fmt(ratio*100,0)}% من المقاس الحالي يحقق نفس الهدف الرقمي دون إضافة بكسلات.`:`Reducing the placed dimensions to about ${fmt(ratio * 100, 0)}% of the current size would meet the same numerical target without adding pixels.`);
    } else {
      actions.push(isAr()?`لدى المصدر هامش PPI قدره ${fmt((ratio-1)*100,0)}% فوق الهدف ${target} PPI عند هذا الموضع.`:`The source has ${fmt((ratio - 1) * 100, 0)}% PPI headroom over the selected ${target} PPI target at this placement.`);
    }

    if (mode === 'fill' && crop.crop > 0.3) {
      if (level === 'ready') { level = 'review'; badge = tx('Review crop','راجع القص'); summary = tx('Resolution is sufficient, but the current fill crop removes a large part of the source.','الدقة كافية، لكن قص الملء الحالي يزيل جزءا كبيرا من المصدر.'); }
      actions.push(isAr()?`قص الملء يزيل ${fmt(crop.crop*100,1)}% من مساحة المصدر. غيّر موضع التركيز أو استخدم الملاءمة أو قارن مقاسات قياسية أقرب للنسبة.`:`The fill crop removes ${fmt(crop.crop * 100, 1)}% of source area. Reposition the focal point, switch to Fit, or compare ratio-friendly standard sizes.`);
    } else if (mode === 'fill' && crop.crop > 0.12) {
      actions.push(isAr()?`القص الحالي يزيل ${fmt(crop.crop*100,1)}% من مساحة المصدر. تأكد من بقاء المحتوى المهم داخل التكوين.`:`The current crop removes ${fmt(crop.crop * 100, 1)}% of source area. Confirm that important content remains inside the composition.`);
    } else if (mode === 'fit' && Math.abs(calc.sourceAspect - calc.targetAspect) > 1e-8) {
      actions.push(tx('Fit preserves the full image, so plan the visible border or empty space intentionally rather than leaving it to the printer.','الملاءمة تحتفظ بالصورة كاملة؛ خطط للحافة أو المساحة الفارغة عمدا بدلا من تركها للمطبعة.'));
    }

    if (calc.bleed > Math.min(pwmm, phmm) * 0.12) {
      if (level === 'ready') { level = 'review'; badge = tx('Check bleed','تحقق من النزف'); summary = tx('The entered bleed is unusually large relative to the trim and should be verified against the provider specification.','قيمة النزف المدخلة كبيرة بشكل غير معتاد مقارنة بالقص ويجب التحقق منها مقابل مواصفات المزود.'); }
      actions.push(tx('Verify the bleed value from the exact product template; the Studio never assumes a universal production margin.','تحقق من قيمة النزف في قالب المنتج الدقيق؛ الاستوديو لا يفترض هامشا إنتاجيا عاما.'));
    } else {
      actions.push(tx('Confirm trim, bleed, safe area, color profile and file format against the exact provider specification.','أكد القص والنزف ومنطقة الأمان وملف اللون وصيغة الملف مقابل مواصفات المزود الدقيقة.'));
    }

    const context = viewing === 'close'
      ? tx('Close viewing is less forgiving of blur, compression and fine-detail loss. The Studio keeps your chosen PPI target unchanged rather than guessing a new one.','المشاهدة القريبة أقل تسامحا مع الضبابية والضغط وفقدان التفاصيل الدقيقة. يحتفظ الاستوديو بهدف PPI الذي اخترته بدلا من تخمين هدف جديد.')
      : viewing === 'distance'
        ? tx('Longer viewing distance may change what a provider considers acceptable, but this Studio does not lower the target automatically.','قد تغيّر مسافة المشاهدة الأطول ما يعتبره المزود مقبولا، لكن الاستوديو لا يخفض الهدف تلقائيا.')
        : tx('Viewing context is recorded for handoff but does not silently change the PPI target.','يُسجل سياق المشاهدة للتسليم لكنه لا يغير هدف PPI بصمت.');
    const typeNote = jobType === 'document-text'
      ? tx(' Text and line work can be less tolerant of raster softness than a photograph, so keep vector content vector when the workflow allows it.',' قد تكون النصوص والخطوط أقل تحملا لنعومة الراستر من الصورة، لذلك احتفظ بالمحتوى المتجهي كمتجهات عندما يسمح المسار بذلك.')
      : jobType === 'book-layout'
        ? tx(' For covers and layouts, verify page boxes, spine/trim geometry and provider templates in addition to raster PPI.',' للأغلفة والتخطيطات، تحقق من صناديق الصفحة وهندسة الكعب والقص وقوالب المزود بالإضافة إلى PPI للراستر.')
        : '';

    return { level, badge, summary, actions: actions.slice(0, 4), context: context + typeNote };
  }

  function updatePreview(calc) {
    const { sourceAspect, targetAspect, pwi, phi, focusX, focusY, fitMode: mode, safe, pwmm, phmm } = calc;
    const trim = el.ratioStage.querySelector('.trim-box');
    const safeBox = trim.querySelector('.safe-box');
    trim.style.aspectRatio = `${pwi}/${phi}`;
    trim.classList.toggle('interactive', mode === 'fill');
    el.focusXOut.value = `${Math.round(focusX)}%`; el.focusYOut.value = `${Math.round(focusY)}%`;

    const horizontalInset = clamp(safe / Math.max(0.0001, pwmm) * 100, 0, 49.5);
    const verticalInset = clamp(safe / Math.max(0.0001, phmm) * 100, 0, 49.5);
    safeBox.style.left = `${horizontalInset}%`; safeBox.style.right = `${horizontalInset}%`;
    safeBox.style.top = `${verticalInset}%`; safeBox.style.bottom = `${verticalInset}%`;
    safeBox.classList.toggle('collapsed', horizontalInset >= 49 || verticalInset >= 49);

    if (mode === 'fill') {
      if (sourceAspect > targetAspect) {
        const over = sourceAspect / targetAspect;
        el.imageBox.style.width = `${over * 100}%`; el.imageBox.style.height = '100%';
        el.imageBox.style.left = `${-(over - 1) * focusX}%`; el.imageBox.style.top = '0';
      } else {
        const over = targetAspect / sourceAspect;
        el.imageBox.style.width = '100%'; el.imageBox.style.height = `${over * 100}%`;
        el.imageBox.style.left = '0'; el.imageBox.style.top = `${-(over - 1) * focusY}%`;
      }
    } else if (sourceAspect > targetAspect) {
      const h = targetAspect / sourceAspect * 100;
      el.imageBox.style.width = '100%'; el.imageBox.style.height = `${h}%`; el.imageBox.style.left = '0'; el.imageBox.style.top = `${(100 - h) / 2}%`;
    } else {
      const w = sourceAspect / targetAspect * 100;
      el.imageBox.style.height = '100%'; el.imageBox.style.width = `${w}%`; el.imageBox.style.top = '0'; el.imageBox.style.left = `${(100 - w) / 2}%`;
    }
  }

  function update() {
    const sw = Math.max(1, Math.round(n(el.sourceW, 1))), sh = Math.max(1, Math.round(n(el.sourceH, 1)));
    const pw = Math.max(0.01, n(el.printW, 0.01)), ph = Math.max(0.01, n(el.printH, 0.01)), u = el.unit.value;
    const target = Math.max(1, n(el.ppi, 300)), bleed = Math.max(0, n(el.bleed, 0)), safe = Math.max(0, n(el.safe, 0));
    const focusX = clamp(n(el.focusX, 50), 0, 100), focusY = clamp(n(el.focusY, 50), 0, 100);
    const pwi = toIn(pw, u), phi = toIn(ph, u), pwmm = toMm(pw, u), phmm = toMm(ph, u);
    const crop = cropInfo(sw, sh, pwi, phi);
    const place = placementFor(sw, sh, pwi, phi, fitMode);
    const usedW = Math.round(place.cw), usedH = Math.round(place.ch);
    const xPpi = place.cw / place.imageWIn, yPpi = place.ch / place.imageHIn;
    const effective = Math.min(xPpi, yPpi);
    const ratioMismatch = Math.abs(place.sourceAspect - place.targetAspect) > 1e-8;

    let label = tx('Meets target','يحقق الهدف'), cls = '', note = tx('at or above the selected numerical target','عند أو فوق الهدف الرقمي المحدد');
    if (effective < target * 0.8) { label = tx('Limited','محدود'); cls = 'limited'; note = tx('below 80% of the selected target','أقل من 80% من الهدف المحدد'); }
    else if (effective < target * 0.999) { label = tx('Close to target','قريب من الهدف'); cls = 'close'; note = tx('within 20% of the selected target','ضمن 20% من الهدف المحدد'); }
    el.verdict.className = `verdict ${cls}`;
    el.verdictLabel.textContent = label;
    el.effectivePpi.textContent = `${fmt(effective, 0)} PPI`;
    el.verdictNote.textContent = fitMode === 'fill' ? (isAr()?`بعد قص الملء المحدد · ${note}`:`after the selected fill crop · ${note}`) : (isAr()?`عند مقاس الصورة بعد الملاءمة · ${note}`:`at the fitted image size · ${note}`);

    const sr = ratioLabel(sw, sh), tr = ratioLabel(Math.round(pwmm * 100), Math.round(phmm * 100));
    el.ratioTitle.textContent = isAr()?`المصدر ${sr} ← الطباعة ${tr}`:`${sr} source → ${tr} print`;
    el.cropLabel.textContent = fitMode === 'fill'
      ? (crop.crop < 0.0005 ? tx('Ratio match','تطابق النسبة') : (isAr()?`تم قص ${fmt(crop.crop*100,1)}%`:`${fmt(crop.crop * 100, 1)}% cropped`))
      : (ratioMismatch ? tx('Full image kept · borders/space required','تم الاحتفاظ بالصورة كاملة · يلزم إطار أو مساحة') : tx('Ratio match','تطابق النسبة'));
    el.compositionNote.textContent = fitMode === 'fill'
      ? (crop.crop < 0.0005 ? tx('The source and target ratios match, so no fill crop is needed.','نسبتا المصدر والهدف متطابقتان، لذلك لا يلزم قص ملء.') : (isAr()?`قص الملء يزيل بكسلات المصدر قبل حساب PPI الفعلي. موضع التركيز ${fmt(focusX,0)}% أفقيا / ${fmt(focusY,0)}% رأسيا.`:`A fill crop removes source pixels before effective PPI is calculated. Crop focus is ${fmt(focusX, 0)}% horizontal / ${fmt(focusY, 0)}% vertical.`))
      : (ratioMismatch ? tx('Fit keeps the full source image. Empty space or a border is required because the ratios differ.','الملاءمة تحتفظ بصورة المصدر كاملة. يلزم فراغ أو إطار لأن النسب مختلفة.') : tx('Fit keeps the complete source and the ratios match.','الملاءمة تحتفظ بالمصدر كاملا والنسب متطابقة.'));

    const reqW = Math.round(pwi * target), reqH = Math.round(phi * target);
    const reqImageW = Math.round(place.imageWIn * target), reqImageH = Math.round(place.imageHIn * target);
    const bleedWmm = pwmm + 2 * bleed, bleedHmm = phmm + 2 * bleed;
    const bleedWpx = Math.round(bleedWmm / 25.4 * target), bleedHpx = Math.round(bleedHmm / 25.4 * target);
    const safeWmm = Math.max(0, pwmm - 2 * safe), safeHmm = Math.max(0, phmm - 2 * safe);
    const surplus = Math.min(usedW / Math.max(1, reqImageW), usedH / Math.max(1, reqImageH));

    const calc = {
      sw, sh, pw, ph, u, pwi, phi, pwmm, phmm, target, bleed, safe, focusX, focusY, crop, ...place,
      usedW, usedH, effective, reqW, reqH, reqImageW, reqImageH, bleedWmm, bleedHmm, bleedWpx, bleedHpx, safeWmm, safeHmm, surplus,
      fitMode, sr, tr, label, viewing: el.viewing.value, jobType: el.jobType.value
    };
    lastCalc = calc;
    if (el.openPreflight) el.openPreflight.href = preflightUrl();
    updatePreview(calc);

    const decision = buildDecision(calc);
    el.decision.className = `decision-engine ${decision.level}`;
    el.decisionBadge.textContent = decision.badge;
    el.decisionSummary.textContent = decision.summary;
    el.decisionActions.replaceChildren(...decision.actions.map((text) => { const li = document.createElement('li'); li.textContent = text; return li; }));
    el.decisionContext.textContent = decision.context;

    const cards = [
      [tx('Usable source after placement','المصدر القابل للاستخدام بعد الوضع'), `${usedW.toLocaleString()} × ${usedH.toLocaleString()} px`, fitMode === 'fill' ? (isAr()?`تم الاحتفاظ بـ ${fmt(place.retained*100,1)}% من مساحة المصدر`:`${fmt(place.retained * 100, 1)}% of the source area retained`) : (isAr()?`تم الاحتفاظ بالمصدر كاملا ${fmt(sw*sh/1e6,1)} MP`:`Full ${fmt(sw * sh / 1e6, 1)} MP source retained`), true],
      [tx('Required source at target','المصدر المطلوب عند الهدف'), `${reqImageW.toLocaleString()} × ${reqImageH.toLocaleString()} px`, fitMode === 'fill' ? (isAr()?`${target} PPI عبر القص الكامل`:`${target} PPI across the full trim`) : (isAr()?`${target} PPI عبر صورة ملائمة ${fmt(place.imageWIn,2)} × ${fmt(place.imageHIn,2)} بوصة`:`${target} PPI across a ${fmt(place.imageWIn, 2)} × ${fmt(place.imageHIn, 2)} in fitted image`), true],
      [tx('Full trim raster at target','راستر القص الكامل عند الهدف'), `${reqW.toLocaleString()} × ${reqH.toLocaleString()} px`, isAr()?`${target} PPI عبر ${fmt(pwi,3)} × ${fmt(phi,3)} بوصة`:`${target} PPI across ${fmt(pwi, 3)} × ${fmt(phi, 3)} in`, false],
      [tx('Full bleed canvas','لوحة النزف الكاملة'), `${fmt(bleedWmm, 1)} × ${fmt(bleedHmm, 1)} mm`, isAr()?`${bleedWpx.toLocaleString()} × ${bleedHpx.toLocaleString()} بكسل عند ${target} PPI`:`${bleedWpx.toLocaleString()} × ${bleedHpx.toLocaleString()} px at ${target} PPI`, false],
      [tx('Protected safe area','منطقة الأمان المحمية'), `${fmt(safeWmm, 1)} × ${fmt(safeHmm, 1)} mm`, safeWmm > 0 && safeHmm > 0 ? `${fmt(fromMm(safeWmm, u), 2)} × ${fmt(fromMm(safeHmm, u), 2)} ${u}` : tx('Safe margin is larger than the trim','هامش الأمان أكبر من مقاس القص'), false],
      [tx('Source vs target','المصدر مقابل الهدف'), surplus >= 1 ? (isAr()?`هامش بكسلات ${fmt((surplus-1)*100,0)}%`:`${fmt((surplus - 1) * 100, 0)}% pixel headroom`) : (isAr()?`أقل من الهدف بنسبة ${fmt((1-surplus)*100,0)}%`:`${fmt((1 - surplus) * 100, 0)}% below target`), surplus >= 1 ? tx('No resampling required to hit the numerical target','لا يلزم إعادة أخذ عينات لتحقيق الهدف الرقمي') : tx('Upsampling would be required to reach the selected target','يلزم رفع العينات للوصول إلى الهدف المحدد'), false]
    ];
    el.primary.innerHTML = cards.map(([a, b, c, f]) => `<article class="result-card${f ? ' featured' : ''}"><small>${a}</small><strong>${b}</strong><span>${c}</span></article>`).join('');

    const ladderTargets = [...new Set([150, 240, 300, Math.round(target)])].sort((a, b) => a - b);
    el.ladder.innerHTML = ladderTargets.map((q) => {
      const wi = usedW / q, hi = usedH / q, ratio = effective / q;
      const status = ratio >= 1 ? tx('Meets','يحقق') : ratio >= 0.8 ? tx('Close','قريب') : tx('Short','ناقص');
      const action = q === Math.round(target) ? `<span class="current-target">${tx('Current','الحالي')}</span>` : `<button type="button" data-set-target="${q}">${tx('Use','استخدم')} ${q}</button>`;
      const jobText = ratio >= 1 ? (isAr()?`هامش ${fmt((ratio-1)*100,0)}%`:`${fmt((ratio - 1) * 100, 0)}% headroom`) : (isAr()?`الحد ≈ ${fmt(ratio*100,0)}% من المقاس الموضوع`:`max ≈ ${fmt(ratio * 100, 0)}% of placed size`);
      return `<tr><td><b>${q} PPI</b></td><td>${fmt(wi, 2)} × ${fmt(hi, 2)} in</td><td><span class="ladder-status ${status.toLowerCase()}">${status}</span> · ${jobText}</td><td>${action}</td></tr>`;
    }).join('');

    el.maxTable.innerHTML = [150, 240, 300].map((q) => {
      const wi = usedW / q, hi = usedH / q;
      return `<tr><td>${q} PPI</td><td>${fmt(wi, 2)} × ${fmt(hi, 2)}</td><td>${fmt(wi * 2.54, 1)} × ${fmt(hi * 2.54, 1)}</td></tr>`;
    }).join('');

    const currentArea = pwi * phi;
    const matches = standardSizes.map(([name, w, h, unit]) => ({ name, ...standardCandidate(sw, sh, w, h, unit, target, currentArea) }))
      .sort((a, b) => a.score - b.score).slice(0, 6);
    el.matches.innerHTML = matches.map((m, i) => {
      const cropText = fitMode === 'fill' ? (m.place.crop < 0.0005 ? tx('ratio match','تطابق النسبة') : (isAr()?`قص ${fmt(m.place.crop*100,1)}%`:`${fmt(m.place.crop * 100, 1)}% crop`)) : (Math.abs(m.place.sourceAspect - m.place.targetAspect) < 1e-8 ? tx('ratio match','تطابق النسبة') : tx('fit with border/space','ملاءمة مع إطار/مساحة'));
      const status = m.effective >= target ? tx('meets target','يحقق الهدف') : m.effective >= target * 0.8 ? tx('close to target','قريب من الهدف') : tx('below target','أقل من الهدف');
      return `<button type="button" class="match" data-match-w="${m.ow}" data-match-h="${m.oh}" data-match-unit="${m.unit}"><span class="match-rank">${i + 1}</span><b>${m.name}</b><span>${m.ow} × ${m.oh} ${m.unit}</span><span>${cropText} · ${fmt(m.effective, 0)} PPI · ${status}</span><em>${tx('Apply size →','طبّق المقاس ←')}</em></button>`;
    }).join('');

    const report = [
      'PRINT PREP LAB — PRINT JOB STUDIO',
      `Generated: ${new Date().toLocaleString()}`,
      '',
      'JOB CONTEXT',
      `Project: ${el.project.value.trim() || 'not supplied'}`,
      `Provider: ${el.provider.value.trim() || 'not supplied'}`,
      `Job type: ${jobTypeLabels[el.jobType.value] || 'Other'}`,
      `Viewing context: ${viewingLabels[el.viewing.value] || 'not supplied'}`,
      `Note: ${el.jobNote.value.trim() || 'not supplied'}`,
      '',
      'SOURCE',
      `File: ${fileName || 'not supplied (image is never stored in saved plans or shared links)'}`,
      `Pixels: ${sw} × ${sh} px (${fmt(sw * sh / 1e6, 1)} MP)`,
      `Source ratio: ${sr}`,
      '',
      'FINAL PRINT',
      `Trim: ${fmt(pw, 3)} × ${fmt(ph, 3)} ${u} (${fmt(pwmm, 1)} × ${fmt(phmm, 1)} mm)`,
      `Placement: ${fitMode === 'fill' ? 'Fill / crop to target ratio' : 'Fit / preserve full image'}`,
      `Estimated crop: ${fitMode === 'fill' ? fmt(crop.crop * 100, 1) + '%' : '0% by design'}`,
      `Crop focus: ${fitMode === 'fill' ? `${fmt(focusX, 0)}% horizontal / ${fmt(focusY, 0)}% vertical` : 'not used in Fit mode'}`,
      `Usable source: ${usedW} × ${usedH} px`,
      `Placed image footprint: ${fmt(place.imageWIn, 3)} × ${fmt(place.imageHIn, 3)} in`,
      '',
      'RESOLUTION',
      `Target: ${target} PPI`,
      `Effective PPI: ${fmt(effective, 1)} PPI`,
      `Verdict: ${label}`,
      `Decision: ${decision.badge} — ${decision.summary}`,
      `Source pixels required at target: ${reqImageW} × ${reqImageH} px`,
      `Full trim raster at target: ${reqW} × ${reqH} px`,
      '',
      'PRODUCTION',
      `Bleed per edge: ${fmt(bleed, 1)} mm`,
      `Full bleed canvas: ${fmt(bleedWmm, 1)} × ${fmt(bleedHmm, 1)} mm`,
      `Full bleed pixels at target: ${bleedWpx} × ${bleedHpx} px`,
      `Safe margin per edge: ${fmt(safe, 1)} mm`,
      `Protected safe area: ${fmt(safeWmm, 1)} × ${fmt(safeHmm, 1)} mm`,
      '',
      'NEXT ACTIONS',
      ...decision.actions.map((a) => `- ${a}`),
      '',
      'HANDOFF NOTES',
      '- Confirm trim, bleed, safe area, color profile and file format with the exact print provider.',
      '- A numerical PPI result does not certify focus, compression, paper, printer or viewing conditions.',
      '- Shared settings links contain dimensions and calculation settings only; they do not contain the image or job-identifying text.',
      '- For critical work, reopen the exported file and inspect a physical or provider-approved proof.',
      '',
      'Methodology: https://printpreplab.pages.dev/methodology'
    ].join('\n');
    el.report.textContent = localizeReport(report);
  }


  function localizeReport(text) {
    if (!isAr()) return text;
    const pairs = [
      ['Generated:','تم الإنشاء:'],['JOB CONTEXT','سياق المهمة'],['Project:','المشروع:'],['Provider:','المزود:'],['Job type:','نوع المهمة:'],['Viewing context:','سياق المشاهدة:'],['Note:','ملاحظة:'],['SOURCE','المصدر'],['File:','الملف:'],['Pixels:','البكسلات:'],['Source ratio:','نسبة المصدر:'],['FINAL PRINT','الطباعة النهائية'],['Trim:','القص:'],['Placement:','الموضع:'],['Estimated crop:','القص المقدر:'],['Crop focus:','موضع القص:'],['Usable source:','المصدر القابل للاستخدام:'],['Placed image footprint:','مساحة الصورة الموضوعة:'],['RESOLUTION','الدقة'],['Target:','الهدف:'],['Effective PPI:','PPI الفعلي:'],['Verdict:','الحكم:'],['Decision:','القرار:'],['Source pixels required at target:','بكسلات المصدر المطلوبة عند الهدف:'],['Full trim raster at target:','راستر القص الكامل عند الهدف:'],['PRODUCTION','الإنتاج'],['Bleed per edge:','النزف لكل حافة:'],['Full bleed canvas:','لوحة النزف الكاملة:'],['Full bleed pixels at target:','بكسلات النزف الكامل عند الهدف:'],['Safe margin per edge:','هامش الأمان لكل حافة:'],['Protected safe area:','منطقة الأمان المحمية:'],['NEXT ACTIONS','الخطوات التالية'],['HANDOFF NOTES','ملاحظات التسليم'],['not supplied','غير مدخل'],['Fill / crop to target ratio','ملء / قص إلى نسبة الهدف'],['Fit / preserve full image','ملاءمة / الاحتفاظ بالصورة كاملة'],['0% by design','0% حسب التصميم'],['not used in Fit mode','غير مستخدم في وضع الملاءمة'],['Methodology:','المنهجية:']
    ];
    let out=text; pairs.forEach(([en,ar])=>{out=out.split(en).join(ar)});
    out=out.replace('- Confirm trim, bleed, safe area, color profile and file format with the exact print provider.','- أكد القص والنزف ومنطقة الأمان وملف اللون وصيغة الملف مع مزود الطباعة الفعلي.')
      .replace('- A numerical PPI result does not certify focus, compression, paper, printer or viewing conditions.','- نتيجة PPI الرقمية لا تضمن التركيز أو الضغط أو الورق أو الطابعة أو ظروف المشاهدة.')
      .replace('- Shared settings links contain dimensions and calculation settings only; they do not contain the image or job-identifying text.','- روابط الإعدادات المشتركة تحتوي الأبعاد وإعدادات الحساب فقط ولا تحتوي الصورة أو نصا يحدد المهمة.')
      .replace('- For critical work, reopen the exported file and inspect a physical or provider-approved proof.','- للأعمال الحساسة، أعد فتح الملف المصدر وافحص إثباتا ماديا أو معتمدا من المزود.');
    return out;
  }

  function focusFromPointer(event) {
    if (fitMode !== 'fill') return;
    const trim = el.ratioStage.querySelector('.trim-box');
    const rect = trim.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    el.focusX.value = clamp((event.clientX - rect.left) / rect.width * 100, 0, 100);
    el.focusY.value = clamp((event.clientY - rect.top) / rect.height * 100, 0, 100);
    update();
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      const area = document.createElement('textarea');
      area.value = text; area.setAttribute('readonly', ''); area.style.position = 'fixed'; area.style.opacity = '0';
      document.body.appendChild(area); area.select();
      const ok = document.execCommand('copy'); area.remove();
      return ok;
    }
  }

  function getPlans() {
    try {
      const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
      return Array.isArray(value) ? value : [];
    } catch { return []; }
  }

  function writePlans(plans) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(plans)); return true; }
    catch { return false; }
  }

  function refreshSavedPlans(selected = '') {
    const plans = getPlans();
    el.savedPlans.replaceChildren();
    const first = document.createElement('option'); first.value = ''; first.textContent = plans.length ? (isAr()?`الخطط المحفوظة (${plans.length})…`:`Saved plans (${plans.length})…`) : tx('No saved plans yet','لا توجد خطط محفوظة بعد');
    el.savedPlans.appendChild(first);
    plans.sort((a, b) => (b.updated || 0) - (a.updated || 0)).forEach((plan) => {
      const option = document.createElement('option'); option.value = plan.id; option.textContent = plan.name;
      if (plan.id === selected) option.selected = true;
      el.savedPlans.appendChild(option);
    });
  }

  function saveCurrentPlan() {
    const plans = getPlans();
    const name = (el.planName.value.trim() || el.project.value.trim() || `Print plan ${new Date().toLocaleDateString()}`).slice(0, 60);
    const now = Date.now();
    const existingIndex = plans.findIndex((p) => p.name.toLowerCase() === name.toLowerCase());
    const payload = { id: existingIndex >= 0 ? plans[existingIndex].id : (crypto.randomUUID?.() || `plan-${now}`), name, updated: now, state: collectState(true) };
    if (existingIndex >= 0) plans[existingIndex] = payload; else plans.push(payload);
    const trimmed = plans.sort((a, b) => b.updated - a.updated).slice(0, 20);
    if (!writePlans(trimmed)) { setStatus(el.planStatus, tx('Browser storage is unavailable, so the plan could not be saved.','تخزين المتصفح غير متاح، لذلك تعذر حفظ الخطة.'), 'error'); return; }
    el.planName.value = name; refreshSavedPlans(payload.id);
    setStatus(el.planStatus, `Saved “${name}” locally. Image data was not saved.`, 'success');
  }

  function loadSelectedPlan() {
    const id = el.savedPlans.value;
    const plan = getPlans().find((p) => p.id === id);
    if (!plan) { setStatus(el.planStatus, tx('Choose a saved plan first.','اختر خطة محفوظة أولا.'), 'error'); return; }
    clearImagePreview();
    applyState(plan.state, true);
    el.planName.value = plan.name;
    setStatus(el.planStatus, `Loaded “${plan.name}”. Re-select the image if you want the visual preview.`, 'success');
  }

  function deleteSelectedPlan() {
    const id = el.savedPlans.value;
    if (!id) { setStatus(el.planStatus, tx('Choose a saved plan first.','اختر خطة محفوظة أولا.'), 'error'); return; }
    const plans = getPlans();
    const plan = plans.find((p) => p.id === id);
    if (!plan) return;
    if (!writePlans(plans.filter((p) => p.id !== id))) { setStatus(el.planStatus, tx('Browser storage is unavailable, so the plan could not be deleted.','تخزين المتصفح غير متاح، لذلك تعذر حذف الخطة.'), 'error'); return; }
    refreshSavedPlans();
    setStatus(el.planStatus, `Deleted “${plan.name}” from this browser.`, 'success');
  }

  function technicalShareUrl() {
    const s = collectState(false);
    const params = new URLSearchParams({
      v: '1', sw: String(s.sw), sh: String(s.sh), pw: String(s.pw), ph: String(s.ph), u: s.unit, fit: s.fit,
      ppi: String(s.ppi), b: String(s.bleed), safe: String(s.safe), fx: String(Math.round(s.focusX)), fy: String(Math.round(s.focusY)), jt: s.jobType, vw: s.viewing, sp: activeSpec?.id || ''
    });
    const url = new URL(location.href); url.hash = params.toString();
    return url.toString();
  }

  function loadHashState() {
    if (!location.hash || location.hash.length < 2) return false;
    const p = new URLSearchParams(location.hash.slice(1));
    if (!p.has('sw') || !p.has('sh')) return false;
    const state = {
      sw: p.get('sw'), sh: p.get('sh'), pw: p.get('pw'), ph: p.get('ph'), unit: p.get('u'), fit: p.get('fit'), ppi: p.get('ppi'),
      bleed: p.get('b'), safe: p.get('safe'), focusX: p.get('fx'), focusY: p.get('fy'), jobType: p.get('jt'), viewing: p.get('vw')
    };
    applyState(state, false);
    const hashSpec = p.get('sp');
    if (hashSpec && specApi?.get(hashSpec)) applySpecProfile(specApi.get(hashSpec));
    setStatus(el.planStatus, tx('Loaded shared technical settings. No image or job-identifying text was included in the link.','تم تحميل الإعدادات التقنية المشتركة. لا يحتوي الرابط على صورة أو نص يحدد المهمة.'), 'success');
    return true;
  }

  function downloadTextReport() {
    const text = el.report.textContent;
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const base = (el.project.value.trim() || 'print-job').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 45) || 'print-job';
    a.href = url; a.download = `${base}-print-prep-report.txt`; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
    setStatus(el.planStatus, tx('Downloaded the current handoff report as a text file.','تم تنزيل تقرير التسليم الحالي كملف نصي.'), 'success');
  }

  function resetStudio() {
    clearImagePreview();
    applyState(defaults, true);
    el.planName.value = '';
    if (location.hash) history.replaceState(null, '', `${location.pathname}${location.search}`);
    setStatus(el.planStatus, tx('Studio reset to the default planning example. Saved plans were not deleted.','تمت إعادة الاستوديو إلى مثال التخطيط الافتراضي. لم تُحذف الخطط المحفوظة.'), 'success');
  }

  el.file.addEventListener('change', (e) => readImage(e.target.files?.[0]));
  el.clearImage.addEventListener('click', clearImagePreview);
  ['dragenter', 'dragover'].forEach((t) => el.drop.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.add('dragging'); }));
  ['dragleave', 'drop'].forEach((t) => el.drop.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.remove('dragging'); }));
  el.drop.addEventListener('drop', (e) => readImage(e.dataTransfer.files?.[0]));
  document.querySelectorAll('[data-preset]').forEach((btn) => btn.addEventListener('click', () => {
    const [w, h, u] = presets[btn.dataset.preset]; el.printW.value = w; el.printH.value = h; el.unit.value = u; update();
  }));
  currentPpiButtons().forEach((btn) => btn.addEventListener('click', () => { el.ppi.value = btn.dataset.ppi; syncPpiButtons(); update(); }));
  currentFitButtons().forEach((btn) => btn.addEventListener('click', () => { setFitMode(btn.dataset.fit); update(); }));
  el.swap.addEventListener('click', () => { const w = el.printW.value; el.printW.value = el.printH.value; el.printH.value = w; update(); });
  el.centerFocus.addEventListener('click', () => { el.focusX.value = 50; el.focusY.value = 50; update(); });
  el.form.addEventListener('input', (e) => { if (e.target === el.ppi) syncPpiButtons(); update(); });
  document.addEventListener('change', (e) => { if (e.target.matches('[data-lang]')) setTimeout(() => { populateSpecProfiles(); update(); }, 0); });

  const trim = el.ratioStage.querySelector('.trim-box');
  let draggingFocus = false;
  trim.addEventListener('pointerdown', (e) => { if (fitMode !== 'fill') return; draggingFocus = true; trim.setPointerCapture?.(e.pointerId); focusFromPointer(e); });
  trim.addEventListener('pointermove', (e) => { if (draggingFocus) focusFromPointer(e); });
  trim.addEventListener('pointerup', () => { draggingFocus = false; });
  trim.addEventListener('pointercancel', () => { draggingFocus = false; });

  el.ladder.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-set-target]'); if (!btn) return;
    el.ppi.value = btn.dataset.setTarget; syncPpiButtons(); update();
  });
  el.matches.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-match-w]'); if (!btn) return;
    el.printW.value = btn.dataset.matchW; el.printH.value = btn.dataset.matchH; el.unit.value = btn.dataset.matchUnit; update();
    document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  el.copy.addEventListener('click', async () => {
    const ok = await copyText(el.report.textContent);
    el.copyStatus.textContent = ok ? tx('Report copied to the clipboard.','تم نسخ التقرير إلى الحافظة.') : tx('Clipboard access was blocked. Select the report text and copy it manually.','تم حظر الوصول إلى الحافظة. حدد نص التقرير وانسخه يدويا.');
  });
  el.print.addEventListener('click', () => window.print());
  el.savePlan.addEventListener('click', saveCurrentPlan);
  el.loadPlan.addEventListener('click', loadSelectedPlan);
  el.deletePlan.addEventListener('click', deleteSelectedPlan);
  el.copyPlanLink.addEventListener('click', async () => {
    const ok = await copyText(technicalShareUrl());
    setStatus(el.planStatus, ok ? tx('Copied a settings-only link. It contains no image, filename, project/provider text or job note.','تم نسخ رابط للإعدادات فقط. لا يتضمن صورة أو اسم ملف أو نص المشروع/المزود أو ملاحظة المهمة.') : tx('Clipboard access was blocked; use the browser address after generating the settings link manually.','تم حظر الوصول إلى الحافظة؛ استخدم عنوان المتصفح بعد إنشاء رابط الإعدادات يدويا.'), ok ? 'success' : 'error');
  });
  el.downloadReport.addEventListener('click', downloadTextReport);
  el.resetStudio.addEventListener('click', resetStudio);
  if (el.specProfile) el.specProfile.addEventListener('change', () => applySpecProfile(specApi?.get(el.specProfile.value) || null));
  if (el.clearProfile) el.clearProfile.addEventListener('click', () => applySpecProfile(null));

  populateSpecProfiles();
  const transferredSpec = specApi?.getActive(true);
  if (transferredSpec) applySpecProfile(transferredSpec, true);
  refreshSavedPlans();
  setFitMode(defaults.fit);
  syncPpiButtons();
  update();
  try {
    const qp = new URL(location.href).searchParams;
    const qJob = qp.get('job'), qProvider = qp.get('provider');
    if (qJob) el.project.value = qJob;
    if (qProvider) el.provider.value = qProvider;
    if (qJob || qProvider) update();
  } catch {}
  loadHashState();
})();
