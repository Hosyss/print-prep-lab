(() => {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const isAr = () => document.documentElement.lang === 'ar';
  const tx = (en, ar) => isAr() ? ar : en;
  const el = {
    form: $('batch-form'), files: $('batch-files'), drop: $('batch-drop'), fileNote: $('batch-file-note'), clear: $('clear-batch'),
    w: $('batch-w'), h: $('batch-h'), unit: $('batch-unit'), ppi: $('batch-ppi'), specProfile: $('batch-spec-profile'), specNote: $('batch-spec-note'), sort: $('batch-sort'),
    rows: $('batch-rows'), tableWrap: $('batch-table-wrap'), empty: $('batch-empty'), status: $('batch-status'), insight: $('batch-insight'),
    sumTotal: $('sum-total'), sumReady: $('sum-ready'), sumClose: $('sum-close'), sumLimited: $('sum-limited'), heroTotal: $('hero-total'),
    copy: $('copy-batch'), csv: $('export-csv'),
    common: $('batch-common'), commonTitle: $('common-title'), commonText: $('common-text'), commonApply: $('apply-common-size')
  };

  const presets = {
    '4x6': [4, 6, 'in'], '5x7': [5, 7, 'in'], '8x10': [8, 10, 'in'], a4: [210, 297, 'mm'], letter: [8.5, 11, 'in'],
    '11x14': [11, 14, 'in'], '16x20': [16, 20, 'in']
  };

  const standardSizes = [
    { id: '4x6', label: '4×6', w: 4, h: 6, unit: 'in' },
    { id: '5x7', label: '5×7', w: 5, h: 7, unit: 'in' },
    { id: '8x10', label: '8×10', w: 8, h: 10, unit: 'in' },
    { id: 'letter', label: 'Letter', w: 8.5, h: 11, unit: 'in' },
    { id: 'a4', label: 'A4', w: 210, h: 297, unit: 'mm' },
    { id: '11x14', label: '11×14', w: 11, h: 14, unit: 'in' },
    { id: '12x18', label: '12×18', w: 12, h: 18, unit: 'in' },
    { id: 'a3', label: 'A3', w: 297, h: 420, unit: 'mm' },
    { id: '16x20', label: '16×20', w: 16, h: 20, unit: 'in' },
    { id: '18x24', label: '18×24', w: 18, h: 24, unit: 'in' },
    { id: '20x30', label: '20×30', w: 20, h: 30, unit: 'in' },
    { id: 'a2', label: 'A2', w: 420, h: 594, unit: 'mm' }
  ].map((size) => ({ ...size, area: toInRaw(size.w, size.unit) * toInRaw(size.h, size.unit) }));

  let placementMode = 'fill';
  let orientationMode = 'auto';
  let filterMode = 'all';
  let items = [];
  let currentCommonSize = null;

  function toInRaw(v, u) { return u === 'in' ? v : u === 'cm' ? v / 2.54 : v / 25.4; }
  const n = (input, fallback = 0) => {
    const v = Number(input?.value);
    return Number.isFinite(v) ? v : fallback;
  };
  const fmt = (v, d = 2) => Number(v.toFixed(d)).toLocaleString('en-US', { maximumFractionDigits: d });
  const toIn = (v, u) => toInRaw(v, u);
  const esc = (v) => String(v).replace(/[&<>'"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[ch]));
  const statusLabel = (status) => status === 'ready' ? tx('Meets','يحقق') : status === 'close' ? tx('Close','قريب') : tx('Limited','محدود');
  const statusRank = { limited: 0, close: 1, ready: 2 };

  function cropInfo(sw, sh, pw, ph) {
    const sr = sw / sh, tr = pw / ph;
    if (Math.abs(sr - tr) < 1e-10) return { retained: 1, crop: 0, cw: sw, ch: sh };
    if (sr > tr) {
      const cw = sh * tr;
      return { retained: cw / sw, crop: 1 - cw / sw, cw, ch: sh };
    }
    const ch = sw / tr;
    return { retained: ch / sh, crop: 1 - ch / sh, cw: sw, ch };
  }

  function evaluatePlacement(sw, sh, wi, hi) {
    const sourceAspect = sw / sh, targetAspect = wi / hi;
    if (placementMode === 'fill') {
      const c = cropInfo(sw, sh, wi, hi);
      const effective = Math.min(c.cw / wi, c.ch / hi);
      return { ...c, effective, coverage: 1, imageWIn: wi, imageHIn: hi, wi, hi };
    }
    let imageWIn = wi, imageHIn = hi;
    if (sourceAspect > targetAspect) imageHIn = wi / sourceAspect;
    else imageWIn = hi * sourceAspect;
    const effective = Math.min(sw / imageWIn, sh / imageHIn);
    return { retained: 1, crop: 0, cw: sw, ch: sh, effective, coverage: (imageWIn * imageHIn) / (wi * hi), imageWIn, imageHIn, wi, hi };
  }

  function evaluateAt(item, rawW, rawH, unit, target) {
    const w = Math.max(0.01, Number(rawW) || 0.01), h = Math.max(0.01, Number(rawH) || 0.01);
    const wi = toIn(w, unit), hi = toIn(h, unit);
    const candidates = [{ ...evaluatePlacement(item.w, item.h, wi, hi), printW: w, printH: h, unit }];
    if (orientationMode === 'auto' && Math.abs(wi - hi) > 1e-10) {
      candidates.push({ ...evaluatePlacement(item.w, item.h, hi, wi), printW: h, printH: w, unit });
    }
    candidates.sort((a, b) => placementMode === 'fill'
      ? (a.crop - b.crop) || (b.effective - a.effective)
      : (b.coverage - a.coverage) || (b.effective - a.effective));
    const best = candidates[0];
    const ratio = best.effective / target;
    const status = ratio >= 1 ? 'ready' : ratio >= 0.8 ? 'close' : 'limited';
    const maxW = best.cw / target, maxH = best.ch / target;
    return {
      ...best, target, status, ratio, maxW, maxH,
      orientation: best.wi >= best.hi ? tx('Landscape','أفقي') : tx('Portrait','رأسي'),
      cropText: placementMode === 'fill'
        ? (best.crop < 0.0005 ? tx('Ratio match','تطابق النسبة') : (isAr()?`تم قص ${fmt(best.crop*100,1)}%`:`${fmt(best.crop * 100, 1)}% cropped`))
        : (Math.abs(item.w / item.h - best.wi / best.hi) < 1e-8 ? tx('Ratio match','تطابق النسبة') : (isAr()?`تغطية الورق ${fmt(best.coverage*100,1)}%`:`${fmt(best.coverage * 100, 1)}% paper coverage`))
    };
  }

  function evaluate(item) {
    return evaluateAt(item, Math.max(0.01, n(el.w, 8)), Math.max(0.01, n(el.h, 10)), el.unit.value, Math.max(1, n(el.ppi, 300)));
  }

  function getResults() { return items.map((item) => ({ item, result: evaluate(item) })); }

  function sortResults(results) {
    const mode = el.sort.value;
    return results.sort((a, b) => {
      if (mode === 'ppi-desc') return b.result.effective - a.result.effective;
      if (mode === 'ppi-asc') return a.result.effective - b.result.effective;
      if (mode === 'crop') return a.result.crop - b.result.crop || b.result.effective - a.result.effective;
      if (mode === 'safe-size') return (b.result.maxW * b.result.maxH) - (a.result.maxW * a.result.maxH);
      if (mode === 'name') return a.item.name.localeCompare(b.item.name, undefined, { sensitivity: 'base' });
      return statusRank[a.result.status] - statusRank[b.result.status] || a.result.effective - b.result.effective;
    });
  }

  function studioHref(item, result) {
    const p = new URLSearchParams({
      v: '1', sw: String(item.w), sh: String(item.h), pw: String(result.printW), ph: String(result.printH), u: result.unit,
      fit: placementMode, ppi: String(result.target), b: String(activeSpec?.bleed ?? 3), safe: String(activeSpec?.safe ?? 5), fx: '50', fy: '50', jt: activeSpec?.jobType || 'photo-art', vw: 'normal', sp: activeSpec?.id || ''
    });
    return `/studio#${p.toString()}`;
  }

  function evaluateStandards(item, target) {
    return standardSizes.map((size) => ({ size, result: evaluateAt(item, size.w, size.h, size.unit, target) }));
  }

  function recommendationsFor(item, result) {
    const standards = evaluateStandards(item, result.target);
    const ready = standards.filter((x) => x.result.status === 'ready').sort((a, b) => b.size.area - a.size.area || a.result.crop - b.result.crop);
    const close = standards.filter((x) => x.result.status === 'close').sort((a, b) => b.result.ratio - a.result.ratio || b.size.area - a.size.area);
    const limited = standards.filter((x) => x.result.status === 'limited').sort((a, b) => b.result.ratio - a.result.ratio || a.size.area - b.size.area);
    const bestReady = ready[0] || null;
    const suggestions = [];
    const pushUnique = (entry) => { if (entry && !suggestions.some((x) => x.size.id === entry.size.id)) suggestions.push(entry); };
    pushUnique(bestReady);
    pushUnique(ready.find((x) => x.size.id !== bestReady?.size.id));
    pushUnique(close[0]);
    pushUnique(close[1]);
    pushUnique(limited[0]);
    return { bestReady, suggestions: suggestions.slice(0, 3), standards };
  }

  function commonSizeRecommendation() {
    if (!items.length) return null;
    const target = Math.max(1, n(el.ppi, 300));
    const candidates = standardSizes.map((size) => {
      const evaluated = items.map((item) => evaluateAt(item, size.w, size.h, size.unit, target));
      const counts = evaluated.reduce((acc, result) => { acc[result.status] += 1; return acc; }, { ready: 0, close: 0, limited: 0 });
      const minRatio = Math.min(...evaluated.map((result) => result.ratio));
      const avgRatio = evaluated.reduce((sum, result) => sum + result.ratio, 0) / evaluated.length;
      const avgCrop = evaluated.reduce((sum, result) => sum + result.crop, 0) / evaluated.length;
      return { size, evaluated, counts, minRatio, avgRatio, avgCrop };
    });
    const allReady = candidates.filter((x) => x.counts.ready === items.length).sort((a, b) => b.size.area - a.size.area || a.avgCrop - b.avgCrop);
    if (allReady.length) return { ...allReady[0], kind: 'all-ready' };
    const noLimited = candidates.filter((x) => x.counts.limited === 0).sort((a, b) => b.size.area - a.size.area || b.minRatio - a.minRatio);
    if (noLimited.length) return { ...noLimited[0], kind: 'no-limited' };
    candidates.sort((a, b) => b.minRatio - a.minRatio || b.counts.ready - a.counts.ready || b.counts.close - a.counts.close || b.size.area - a.size.area);
    return { ...candidates[0], kind: 'best-compromise' };
  }

  function sizeLabelWithOrientation(entry) {
    const { size, result } = entry;
    const base = size.label;
    return result.orientation === tx('Landscape','أفقي') ? (isAr()?`${base} أفقي`:`${base} landscape`) : (isAr()?`${base} رأسي`:`${base} portrait`);
  }

  const specApi = window.PPL_SPEC_PROFILES;
  let activeSpec = null;
  function populateSpecProfiles() {
    if (!el.specProfile || !specApi) return;
    el.specProfile.innerHTML = `<option value="">${tx('Manual target','هدف يدوي')}</option>` + specApi.all().map((p) => `<option value="${esc(p.id)}">${esc((p.custom ? 'Custom · ' : '') + (p.name || ''))}</option>`).join('');
  }
  function applySpecProfile(profile, fromTransfer = false) {
    activeSpec = profile || null;
    if (!profile) {
      if (el.specProfile) el.specProfile.value = '';
      if (el.specNote) el.specNote.textContent = tx('A profile can set the shared PPI target for this batch. Bleed, safe area, color and export notes carry into Studio when you open an individual result.','يمكن للملف تحديد هدف PPI المشترك لهذه المجموعة. تنتقل ملاحظات النزف ومنطقة الأمان واللون والتصدير إلى الاستوديو عند فتح نتيجة منفردة.');
      render();
      return;
    }
    if (el.specProfile) el.specProfile.value = profile.id || '';
    el.ppi.value = Math.max(1, Number(profile.ppi) || 300);
    document.querySelectorAll('[data-batch-ppi]').forEach((b) => b.classList.toggle('active', Number(b.dataset.batchPpi) === Number(el.ppi.value)));
    if (el.specNote) el.specNote.textContent = isAr()?`${profile.name}: ${profile.ppi} PPI · نزف ${profile.bleed} مم · أمان ${profile.safe} مم. ترث الملفات المفتوحة في الاستوديو الملف كاملا.`:`${profile.name}: ${profile.ppi} PPI · ${profile.bleed} mm bleed · ${profile.safe} mm safe. Individual files opened in Studio inherit the full profile.`;
    render();
    if (fromTransfer) setStatus(isAr()?`تم تطبيق ملف المواصفات «${profile.name}». تحقّق منه مقابل مستند المزود الحالي.`:`Applied specification profile “${profile.name}”. Verify it against the current provider document.`, 'success');
  }
  function setStatus(message, kind = '') { el.status.textContent = message; el.status.dataset.kind = kind; }

  function applySize(size) {
    el.w.value = size.w; el.h.value = size.h; el.unit.value = size.unit;
    render();
    setStatus(isAr()?`تم تغيير هدف المجموعة إلى ${size.label}. أُعيد حساب كل الصور المحملة محليا.`:`Batch target changed to ${size.label}. Every loaded image was recalculated locally.`, 'success');
  }

  function renderCommonOptimizer() {
    currentCommonSize = commonSizeRecommendation();
    if (!currentCommonSize) { el.common.hidden = true; return; }
    el.common.hidden = false;
    const c = currentCommonSize;
    const target = Math.max(1, n(el.ppi, 300));
    if (c.kind === 'all-ready') {
      el.commonTitle.textContent = isAr()?`${c.size.label} هو أكبر مقاس مدرج تجتازه كل الصور`:`${c.size.label} is the largest listed size every image clears`;
      el.commonText.textContent = isAr()?`${c.counts.ready}/${items.length} صورة تحقق ${target} PPI عند هذا المقاس القياسي باستخدام قواعد الموضع والاتجاه الحالية.`:`${c.counts.ready}/${items.length} images meet ${target} PPI at this standard size using the current ${placementMode} and ${orientationMode} orientation rules.`;
    } else if (c.kind === 'no-limited') {
      el.commonTitle.textContent = isAr()?`${c.size.label} يبقي المجموعة كلها خارج المنطقة المحدودة`:`${c.size.label} keeps the whole batch out of the limited zone`;
      el.commonText.textContent = isAr()?`${c.counts.ready} تحقق الهدف و${c.counts.close} قريبة عند ${target} PPI. لا يوجد مقاس مدرج أكبر يبقي كل الصور عند أو فوق 80% من الهدف.`:`${c.counts.ready} meet and ${c.counts.close} are close at ${target} PPI. No listed larger size keeps every image at or above 80% of the selected target.`;
    } else {
      el.commonTitle.textContent = isAr()?`لا يوجد مقاس قياسي مدرج يحقق ${target} PPI للمجموعة كلها`:`No listed standard size clears ${target} PPI for the whole batch`;
      el.commonText.textContent = isAr()?`${c.size.label} هو أفضل حل وسط مدرج: ${c.counts.ready} تحقق و${c.counts.close} قريبة و${c.counts.limited} محدودة. فكّر في هدف PPI أقل معتمد من المزود أو طباعة مخصصة أصغر أو ملفات مصدر مختلفة.`:`${c.size.label} is the strongest listed compromise: ${c.counts.ready} meet, ${c.counts.close} close and ${c.counts.limited} limited. Consider a lower provider-approved PPI target, a smaller custom print, or different source files.`;
    }
    el.commonApply.textContent = isAr()?`افحص المجموعة كلها عند ${c.size.label}`:`Check whole batch at ${c.size.label}`;
  }

  function resultCard(item, result) {
    const rec = recommendationsFor(item, result);
    const safeLabel = `${fmt(result.maxW, 2)} × ${fmt(result.maxH, 2)} in`;
    const best = rec.bestReady;
    const recommendationText = best
      ? `${sizeLabelWithOrientation(best)} · ${fmt(best.result.effective, 0)} PPI${placementMode === 'fill' && best.result.crop > 0.0005 ? ` · ${fmt(best.result.crop * 100, 1)}% crop` : ''}`
      : isAr()?`لا يوجد مقاس قياسي مدرج يصل إلى ${result.target} PPI`:`No listed standard size reaches ${result.target} PPI`;
    const alternativeHtml = rec.suggestions.length
      ? rec.suggestions.map(({ size, result: alt }) => `<a class="size-option ${alt.status}" href="${studioHref(item, alt)}"><b>${esc(size.label)}</b><span>${fmt(alt.effective, 0)} PPI · ${statusLabel(alt.status)}</span></a>`).join('')
      : `<span class="no-size-option">${tx('No standard-size alternatives calculated.','لم يتم حساب بدائل قياسية.')}</span>`;
    const bestAction = best ? `<a class="result-action primary" href="${studioHref(item, best.result)}">${isAr()?`افتح ${esc(best.size.label)} في الاستوديو ←`:`Open ${esc(best.size.label)} in Studio →`}</a>` : '';

    return `<article class="batch-result-card ${result.status}">
      <div class="result-identity">
        <img class="batch-thumb" src="${esc(item.url)}" alt="">
        <div class="result-file"><b title="${esc(item.name)}">${esc(item.name)}</b><span>${item.w.toLocaleString()} × ${item.h.toLocaleString()} px · ${fmt(item.w * item.h / 1e6, 1)} MP · ${fmt(item.size / 1024 / 1024, 1)} MB</span></div>
        <span class="status-pill ${result.status}">${statusLabel(result.status)}</span>
      </div>
      <div class="result-metrics">
        <div><small>${tx('Effective PPI','PPI الفعلي')}</small><strong>${fmt(result.effective, 0)}</strong><span>${isAr()?`${fmt(result.ratio*100,0)}% من ${result.target}`:`${fmt(result.ratio * 100, 0)}% of ${result.target}`}</span></div>
        <div><small>${tx('Current placement','الموضع الحالي')}</small><strong>${result.orientation}</strong><span>${fmt(result.printW, 2)} × ${fmt(result.printH, 2)} ${esc(result.unit)} · ${placementMode}</span></div>
        <div><small>${tx('Crop / fit','القص / الملاءمة')}</small><strong>${esc(result.cropText)}</strong><span>${placementMode === 'fill' ? (isAr()?`تم الاحتفاظ بـ ${fmt(result.retained*100,1)}% من المصدر`:`${fmt(result.retained * 100, 1)}% source retained`) : (isAr()?`تغطية الورق ${fmt(result.coverage*100,1)}%`:`${fmt(result.coverage * 100, 1)}% paper coverage`)}</span></div>
        <div class="safe-metric"><small>${placementMode === 'fill' ? tx('Max same-ratio print','أقصى طباعة بنفس النسبة') : tx('Max image footprint','أقصى مساحة للصورة')}</small><strong>${safeLabel}</strong><span>${isAr()?'عند':'at'} ${result.target} PPI</span></div>
      </div>
      <div class="result-recommendation">
        <div><small>${tx('Standard-size recommendation','توصية المقاس القياسي')}</small><h4>${esc(recommendationText)}</h4><p>${best ? tx('Largest listed standard size that numerically reaches the selected target for this file.','أكبر مقاس قياسي مدرج يصل رقميا إلى الهدف المحدد لهذا الملف.') : isAr()?`المساحة الآمنة المخصصة أعلاه هي الحد الأكثر فائدة عند ${result.target} PPI. قد يسمح هدف أقل معتمد من المزود بطباعة أكبر.`:`The custom safe footprint above is the more useful limit at ${result.target} PPI. A provider-approved lower target may allow a larger print.`}</p></div>
        <div class="result-actions"><a class="result-action" href="${studioHref(item, result)}">${tx('Open current target in Studio','افتح الهدف الحالي في الاستوديو')}</a>${bestAction}</div>
      </div>
      <div class="size-options" aria-label="Alternative standard sizes"><span class="option-label">${tx('Alternative checks','فحوص بديلة')}</span>${alternativeHtml}</div>
    </article>`;
  }

  function render() {
    const all = getResults();
    const totals = all.reduce((acc, x) => { acc[x.result.status] += 1; return acc; }, { ready: 0, close: 0, limited: 0 });
    el.sumTotal.textContent = all.length; el.sumReady.textContent = totals.ready; el.sumClose.textContent = totals.close; el.sumLimited.textContent = totals.limited; el.heroTotal.textContent = all.length;

    const insightTitle = el.insight.querySelector('h3');
    const insightText = el.insight.querySelector('p');
    if (!all.length) {
      insightTitle.textContent = tx('No images loaded','لا توجد صور محملة');
      insightText.textContent = tx('Add images to see which files are ready, which are close and which need a smaller print or revised target.','أضف صورا لمعرفة الملفات الجاهزة والقريبة والتي تحتاج إلى طباعة أصغر أو هدف معدل.');
    } else if (!totals.limited && !totals.close) {
      insightTitle.textContent = isAr()?`كل الصور (${all.length}) تحقق الهدف الرقمي`:`All ${all.length} images meet the numerical target`;
      insightText.textContent = tx('The pixel math clears the selected PPI target for every file. Still inspect focus, compression and the provider specification before production.','حسابات البكسل تحقق هدف PPI المحدد لكل ملف. افحص مع ذلك التركيز والضغط ومواصفات المزود قبل الإنتاج.');
    } else if (totals.limited) {
      const weakest = all.slice().sort((a, b) => a.result.effective - b.result.effective)[0];
      insightTitle.textContent = isAr()?`${totals.limited} صورة تحتاج إلى مراجعة`:`${totals.limited} ${totals.limited === 1 ? 'image needs' : 'images need'} attention`;
      insightText.textContent = isAr()?`${weakest.item.name} هي الأضعف حاليا عند ${fmt(weakest.result.effective,0)} PPI. استخدم توصية المقاس الآمن أدناه أو افتحها في الاستوديو قبل التفكير في إعادة أخذ العينات.`:`${weakest.item.name} is currently the weakest at ${fmt(weakest.result.effective, 0)} PPI. Use its safe-size recommendation below or open it in the Studio before considering resampling.`;
    } else {
      insightTitle.textContent = isAr()?`${totals.close} صورة قريبة من الهدف`:`${totals.close} ${totals.close === 1 ? 'image is' : 'images are'} close to target`;
      insightText.textContent = tx('No file is severely short, but the close group does not fully reach the selected target. Compare the recommended standard sizes before export.','لا يوجد ملف يعاني نقصا حادا، لكن المجموعة القريبة لا تصل بالكامل إلى الهدف المحدد. قارن المقاسات القياسية الموصى بها قبل التصدير.');
    }

    renderCommonOptimizer();

    const filtered = sortResults(all.filter((x) => filterMode === 'all' || x.result.status === filterMode));
    el.empty.hidden = all.length > 0;
    el.tableWrap.hidden = all.length === 0;
    el.rows.innerHTML = filtered.map(({ item, result }) => resultCard(item, result)).join('');

    el.fileNote.textContent = all.length ? (isAr()?`تم تحميل ${all.length} صورة · قُرئت الأبعاد محليا · دون رفع`:`${all.length} image${all.length === 1 ? '' : 's'} loaded · dimensions read locally · no upload`) : tx('No images loaded yet.','لم يتم تحميل صور بعد.');
    if (all.length && !filtered.length) setStatus(isAr()?`لا توجد صور تطابق المرشح «${filterMode}».`:`No images match the “${filterMode}” filter.`, '');
    else if (all.length) setStatus(isAr()?`عرض ${filtered.length} من ${all.length} صورة.`:`Showing ${filtered.length} of ${all.length} images.`, '');
    else setStatus('', '');
  }

  function readFile(file) {
    return new Promise((resolve) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => resolve({ id: crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`, name: file.name, type: file.type, size: file.size, w: img.naturalWidth, h: img.naturalHeight, url });
      img.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
      img.src = url;
    });
  }

  async function addFiles(fileList) {
    const incoming = [...(fileList || [])].filter((file) => !file.type || file.type.startsWith('image/'));
    if (!incoming.length) { setStatus(tx('No readable image files were selected.','لم يتم اختيار ملفات صور قابلة للقراءة.'), 'error'); return; }
    const room = Math.max(0, 40 - items.length);
    if (!room) { setStatus(tx('The current batch already contains the 40-image limit. Clear it before adding another set.','تحتوي المجموعة الحالية بالفعل على الحد الأقصى وهو 40 صورة. امسحها قبل إضافة مجموعة أخرى.'), 'error'); return; }
    const chosen = incoming.slice(0, room);
    setStatus(isAr()?`جار قراءة ${chosen.length} صورة محليا…`:`Reading ${chosen.length} image${chosen.length === 1 ? '' : 's'} locally…`, '');
    const loaded = (await Promise.all(chosen.map(readFile))).filter(Boolean).filter((x) => x.w && x.h);
    items.push(...loaded);
    render();
    const skipped = incoming.length - chosen.length + (chosen.length - loaded.length);
    setStatus(isAr()?`تمت إضافة ${loaded.length} صورة.${skipped?` تم تخطي ${skipped} بسبب حد 40 صورة أو ملف غير قابل للقراءة.`:''}`:`${loaded.length} image${loaded.length === 1 ? '' : 's'} added.${skipped ? ` ${skipped} skipped because of the 40-image limit or an unreadable file.` : ''}`, loaded.length ? 'success' : 'error');
    el.files.value = '';
  }

  function clearBatch() {
    items.forEach((item) => URL.revokeObjectURL(item.url));
    items = [];
    el.files.value = '';
    render();
    setStatus(tx('Batch cleared. Temporary local thumbnails were released.','تم مسح المجموعة وتحرير الصور المصغرة المحلية المؤقتة.'), 'success');
  }

  function buildTextSummary() {
    const results = sortResults(getResults());
    const counts = results.reduce((acc, x) => { acc[x.result.status] += 1; return acc; }, { ready: 0, close: 0, limited: 0 });
    const target = Math.max(1, n(el.ppi, 300));
    const common = commonSizeRecommendation();
    const lines = [
      'PRINT PREP LAB — BATCH PRINT CHECKER',
      `Generated: ${new Date().toLocaleString()}`,
      `Target: ${el.w.value} × ${el.h.value} ${el.unit.value} · ${target} PPI · ${placementMode} · ${orientationMode} orientation`,
      `Summary: ${results.length} total · ${counts.ready} meet · ${counts.close} close · ${counts.limited} limited`,
      common ? `Common-size optimizer: ${common.size.label} · ${common.counts.ready} meet · ${common.counts.close} close · ${common.counts.limited} limited` : '',
      '',
      ...results.map(({ item, result }) => {
        const rec = recommendationsFor(item, result);
        return `${item.name} | ${item.w}×${item.h}px | ${result.orientation} | ${fmt(result.effective, 1)} PPI | ${result.cropText} | safe ${fmt(result.maxW, 2)}×${fmt(result.maxH, 2)} in @ ${result.target} PPI | best listed ${rec.bestReady?.size.label || 'none'} | ${result.status.toUpperCase()}`;
      }),
      '',
      'Numerical results do not certify focus, compression, color, paper or printer behavior. Confirm the exact provider specification.',
      'Methodology: https://printpreplab.pages.dev/methodology'
    ];
    return localizeSummary(lines.filter(Boolean).join('\n'));
  }


  function localizeSummary(text){
    if(!isAr()) return text;
    let out=text;
    const pairs=[['Generated:','تم الإنشاء:'],['Target:','الهدف:'],['Summary:','الملخص:'],['Common-size optimizer:','محسن المقاس المشترك:'],['Numerical results do not certify focus, compression, color, paper or printer behavior. Confirm the exact provider specification.','النتائج الرقمية لا تضمن التركيز أو الضغط أو اللون أو الورق أو سلوك الطابعة. أكد مواصفات المزود الدقيقة.'],['Methodology:','المنهجية:'],[' total',' إجمالي'],[' meet',' تحقق'],[' close',' قريب'],[' limited',' محدود'],[' landscape',' أفقي'],[' portrait',' رأسي'],['safe ','آمن '],['best listed ','أفضل مقاس مدرج ']];
    pairs.forEach(([en,ar])=>{out=out.split(en).join(ar)});return out;
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return true; }
    catch {
      const t = document.createElement('textarea'); t.value = text; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select();
      const ok = document.execCommand('copy'); t.remove(); return ok;
    }
  }

  function exportCsv() {
    const results = sortResults(getResults());
    if (!results.length) { setStatus(tx('Add images before exporting CSV.','أضف صورا قبل تصدير CSV.'), 'error'); return; }
    const q = (v) => `"${String(v).replace(/"/g, '""')}"`;
    const rows = [isAr()?['الملف','العرض بكسل','الارتفاع بكسل','ميجابكسل','عرض الهدف','ارتفاع الهدف','الوحدة','الاتجاه','الموضع','PPI الهدف','PPI الفعلي','نسبة القص','العرض الآمن عند الهدف بالبوصة','الارتفاع الآمن عند الهدف بالبوصة','أفضل مقاس آمن مدرج','الحالة']:['File','Width px','Height px','Megapixels','Target width','Target height','Unit','Orientation','Placement','Target PPI','Effective PPI','Crop percent','Safe width at target in','Safe height at target in','Best listed safe size','Status']];
    results.forEach(({ item, result }) => {
      const rec = recommendationsFor(item, result);
      rows.push([
        item.name, item.w, item.h, (item.w * item.h / 1e6).toFixed(2), result.printW, result.printH, result.unit, result.orientation, placementMode,
        result.target, result.effective.toFixed(1), (result.crop * 100).toFixed(1), result.maxW.toFixed(2), result.maxH.toFixed(2), rec.bestReady?.size.label || '', result.status
      ]);
    });
    const csv = rows.map((row) => row.map(q).join(',')).join('\r\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a');
    a.href = url; a.download = 'print-prep-batch-results.csv'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 0);
    setStatus(tx('CSV exported with dimensions, safe-size guidance and calculated results only; image files were not included.','تم تصدير CSV بالأبعاد وإرشادات المقاس الآمن والنتائج المحسوبة فقط؛ لم تُضمّن ملفات الصور.'), 'success');
  }

  el.files.addEventListener('change', (e) => addFiles(e.target.files));
  ['dragenter', 'dragover'].forEach((t) => el.drop.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.add('dragging'); }));
  ['dragleave', 'drop'].forEach((t) => el.drop.addEventListener(t, (e) => { e.preventDefault(); el.drop.classList.remove('dragging'); }));
  el.drop.addEventListener('drop', (e) => addFiles(e.dataTransfer.files));
  el.clear.addEventListener('click', clearBatch);

  document.querySelectorAll('[data-batch-preset]').forEach((btn) => btn.addEventListener('click', () => {
    const [w, h, u] = presets[btn.dataset.batchPreset]; el.w.value = w; el.h.value = h; el.unit.value = u; render();
  }));
  document.querySelectorAll('[data-batch-fit]').forEach((btn) => btn.addEventListener('click', () => {
    placementMode = btn.dataset.batchFit === 'fit' ? 'fit' : 'fill';
    document.querySelectorAll('[data-batch-fit]').forEach((x) => { const active = x.dataset.batchFit === placementMode; x.classList.toggle('active', active); x.setAttribute('aria-pressed', active ? 'true' : 'false'); });
    render();
  }));
  document.querySelectorAll('[data-orientation]').forEach((btn) => btn.addEventListener('click', () => {
    orientationMode = btn.dataset.orientation === 'fixed' ? 'fixed' : 'auto';
    document.querySelectorAll('[data-orientation]').forEach((x) => { const active = x.dataset.orientation === orientationMode; x.classList.toggle('active', active); x.setAttribute('aria-pressed', active ? 'true' : 'false'); });
    render();
  }));
  document.querySelectorAll('[data-batch-ppi]').forEach((btn) => btn.addEventListener('click', () => {
    el.ppi.value = btn.dataset.batchPpi;
    document.querySelectorAll('[data-batch-ppi]').forEach((x) => x.classList.toggle('active', Number(x.dataset.batchPpi) === n(el.ppi)));
    render();
  }));
  el.form.addEventListener('input', (e) => {
    if (e.target === el.ppi) document.querySelectorAll('[data-batch-ppi]').forEach((x) => x.classList.toggle('active', Number(x.dataset.batchPpi) === n(el.ppi)));
    render();
  });
  document.querySelectorAll('[data-filter]').forEach((btn) => btn.addEventListener('click', () => {
    filterMode = btn.dataset.filter;
    document.querySelectorAll('[data-filter]').forEach((x) => x.classList.toggle('active', x === btn));
    render();
  }));
  el.sort.addEventListener('change', render);
  el.commonApply.addEventListener('click', () => { if (currentCommonSize?.size) applySize(currentCommonSize.size); });
  el.copy.addEventListener('click', async () => {
    if (!items.length) { setStatus(tx('Add images before copying a batch summary.','أضف صورا قبل نسخ ملخص المجموعة.'), 'error'); return; }
    const ok = await copyText(buildTextSummary());
    setStatus(ok ? tx('Batch summary copied.','تم نسخ ملخص المجموعة.') : tx('Clipboard access was blocked.','تم حظر الوصول إلى الحافظة.'), ok ? 'success' : 'error');
  });
  el.csv.addEventListener('click', exportCsv);
  window.addEventListener('beforeunload', () => items.forEach((item) => URL.revokeObjectURL(item.url)));

  populateSpecProfiles();
  if (el.specProfile) el.specProfile.addEventListener('change', () => applySpecProfile(specApi?.get(el.specProfile.value) || null));
  const transferredSpec = specApi?.getActive(true);
  if (transferredSpec) applySpecProfile(transferredSpec, true);
  document.addEventListener('change',(e)=>{if(e.target.matches('[data-lang]'))setTimeout(()=>{populateSpecProfiles();render();},0)});
  render();
})();
