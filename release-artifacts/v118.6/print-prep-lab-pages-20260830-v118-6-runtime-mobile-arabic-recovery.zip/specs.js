(() => {
  'use strict';
  const api = window.PPL_SPEC_PROFILES;
  if (!api) return;
  const $ = (id) => document.getElementById(id);
  const grid = $('profile-grid'), category = $('category-filter'), search = $('profile-search'), status = $('custom-status');
  const fields = { name:$('custom-name'), ppi:$('custom-ppi'), bleed:$('custom-bleed'), safe:$('custom-safe'), job:$('custom-job'), color:$('custom-color'), format:$('custom-format'), proof:$('custom-proof'), note:$('custom-note') };
  let editId = '';
  const esc = (s='') => String(s).replace(/[&<>'"]/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const num = (v, fallback=0) => Number.isFinite(Number(v)) ? Number(v) : fallback;
  const slug = (s) => String(s).toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,48) || `profile-${Date.now()}`;

  function categories() {
    const values = [...new Set(api.all().map(p => p.category || 'Custom'))].sort();
    category.innerHTML = '<option value="all">All profiles</option>' + values.map(v => `<option value="${esc(v)}">${esc(v)}</option>`).join('');
  }
  function activate(profile, destination) {
    api.setActive(profile);
    location.href = destination;
  }
  function card(p) {
    const custom = !!p.custom;
    const checks = Array.isArray(p.checks) ? p.checks : [];
    return `<article class="profile-card ${custom?'custom-profile':''}" data-category="${esc(p.category||'Custom')}">
      <div class="profile-head"><small><span>${esc(p.category||'Custom')}</span>${custom?'<span class="custom-badge">CUSTOM</span>':'<span>PLANNING TEMPLATE</span>'}</small><h3>${esc(p.name)}</h3><p>${esc(p.note||'Reusable print specification profile.')}</p></div>
      <div class="spec-values"><div><small>Target</small><strong>${num(p.ppi,300)} PPI</strong></div><div><small>Bleed</small><strong>${num(p.bleed,0)} mm</strong></div><div><small>Safe</small><strong>${num(p.safe,0)} mm</strong></div></div>
      <div class="profile-details"><div class="detail-row"><small>Color workflow</small><span>${esc(p.color||'Use the provider specification')}</span></div><div class="detail-row"><small>Delivery format</small><span>${esc(p.format||'Use the provider specification')}</span></div><div class="detail-row"><small>Proofing</small><span>${esc(p.proof||'Reopen and inspect the exported file before production.')}</span></div>${checks.length?`<ul class="profile-checks">${checks.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}</div>
      <div class="profile-actions"><button type="button" class="primary-action" data-use-studio="${esc(p.id)}">Use in Studio</button><button type="button" data-use-batch="${esc(p.id)}">Use in Batch</button><button type="button" data-use-preflight="${esc(p.id)}">Use in Preflight</button>${custom?`<button type="button" data-edit="${esc(p.id)}">Edit</button><button type="button" class="danger-action" data-delete="${esc(p.id)}">Delete</button>`:''}</div>
    </article>`;
  }
  function render() {
    const q = search.value.trim().toLowerCase(), cat = category.value;
    const list = api.all().filter(p => (cat==='all'||(p.category||'Custom')===cat) && (!q || [p.name,p.category,p.note,p.color,p.format].join(' ').toLowerCase().includes(q)));
    grid.innerHTML = list.length ? list.map(card).join('') : '<div class="empty-profiles"><strong>No profiles match this filter.</strong><p>Clear the search or build a custom profile below.</p></div>';
  }
  function clearForm() {
    editId=''; fields.name.value=''; fields.ppi.value=300; fields.bleed.value=3; fields.safe.value=5; fields.job.value='photo-art'; fields.color.value=''; fields.format.value=''; fields.proof.value=''; fields.note.value=''; $('save-custom').textContent='Save custom profile'; status.textContent='';
  }
  function editProfile(id) {
    const p=api.get(id); if(!p||!p.custom)return;
    editId=id; fields.name.value=p.name||''; fields.ppi.value=p.ppi||300; fields.bleed.value=p.bleed??3; fields.safe.value=p.safe??5; fields.job.value=p.jobType||'photo-art'; fields.color.value=p.color||''; fields.format.value=p.format||''; fields.proof.value=p.proof||''; fields.note.value=p.note||''; $('save-custom').textContent='Update profile'; status.textContent=`Editing “${p.name}”.`; location.hash='custom';
  }
  function save() {
    const name=fields.name.value.trim(); if(!name){status.textContent='Add a profile name first.'; fields.name.focus(); return;}
    const list=api.readCustom(); const id=editId||`custom-${slug(name)}-${Date.now().toString(36)}`;
    const profile={id,name,category:'Custom',custom:true,ppi:Math.max(1,num(fields.ppi.value,300)),bleed:Math.max(0,num(fields.bleed.value,0)),safe:Math.max(0,num(fields.safe.value,0)),jobType:fields.job.value,color:fields.color.value.trim()||'Use the provider specification',format:fields.format.value.trim()||'Use the provider specification',proof:fields.proof.value.trim()||'Reopen and inspect the exported file before production.',note:fields.note.value.trim()||'Custom provider specification saved in this browser.',checks:[]};
    const idx=list.findIndex(x=>x.id===id); if(idx>=0)list[idx]=profile; else list.push(profile); api.writeCustom(list); categories(); render(); clearForm(); status.textContent=`Saved “${name}” in this browser.`;
  }
  grid.addEventListener('click',(e)=>{const b=e.target.closest('button'); if(!b)return; const id=b.dataset.useStudio||b.dataset.useBatch||b.dataset.usePreflight||b.dataset.edit||b.dataset.delete; if(!id)return; const p=api.get(id); if(b.dataset.useStudio)activate(p,'/studio?profile=applied'); else if(b.dataset.useBatch)activate(p,'/batch?profile=applied'); else if(b.dataset.usePreflight)activate(p,'/preflight?profile=applied'); else if(b.dataset.edit)editProfile(id); else if(b.dataset.delete){const next=api.readCustom().filter(x=>x.id!==id); api.writeCustom(next); categories(); render(); status.textContent='Custom profile deleted from this browser.';}});
  $('save-custom').addEventListener('click',save); $('clear-custom').addEventListener('click',clearForm); category.addEventListener('change',render); search.addEventListener('input',render);
  categories(); render();
})();
