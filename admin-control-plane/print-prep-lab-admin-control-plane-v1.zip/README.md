# Print Prep Lab — Separate Admin Control Plane

This is deliberately a **separate Cloudflare Worker**. It does not modify the public Print Prep Lab release and it must not share the public site's data bindings.

## Security model

1. **Cloudflare Access protects the entire Worker before Worker code runs.** Configure Access for **All traffic** and allow only the owner's exact email identity. Use an identity provider with MFA (or the strongest available account authentication), and use a short session duration.
2. The Worker then performs **defense-in-depth Access JWT validation** on every request: RS256 signature, `kid`, issuer, audience, expiry/not-before, and exact allowed-admin email.
3. The Worker is **fail-closed**. Missing Access configuration, D1 binding, admin email list, origin, or CSRF secret returns 503/403; there is no public fallback mode.
4. Every state-changing API request requires:
   - valid Cloudflare Access identity;
   - exact same `Origin` and same-site browser context;
   - a short-lived HMAC CSRF token tied to the Access session;
   - JSON content type;
   - body-size limits;
   - per-admin mutation rate limiting.
5. D1 queries are parameterized. Records use optimistic version checks to prevent silent concurrent overwrites.
6. Every update/delete/rollback is recorded in the audit log and prior values are retained in revision history.
7. Admin UI uses `textContent`/DOM construction for server data; user content is never inserted with `innerHTML`.
8. Admin responses are `no-store`, `noindex`, deny framing, disable powerful browser features, and use a strict CSP with no inline/eval/third-party script allowance.
9. The Admin panel intentionally cannot edit executable JavaScript or calculator formulas. Code/math changes stay in the tested release pipeline. This prevents a compromised admin session from becoming arbitrary-code execution on the public site.

## Required Cloudflare configuration before deployment

- Create a **dedicated D1** database named `printpreplab-admin`.
- Bind it as `ADMIN_DB`.
- Run `migrations/0001_admin.sql` against that D1 database.
- Set `ACCESS_TEAM_DOMAIN`, `ACCESS_AUD`, `ADMIN_EMAILS`, and `ADMIN_ORIGIN` as Worker variables.
- Set `ADMIN_CSRF_SECRET` as a Worker **secret**, at least 32 random bytes.
- Deploy the Worker.
- In Workers & Pages → `printpreplab-admin` → Access, protect **All traffic**. Permit only the owner's exact identity. Do not create a public bypass policy.
- Keep preview deployments protected too.

Cloudflare documents that Worker-level Access can protect all domains and preview URLs for one Worker, and that the Access application JWT must be validated rather than trusting identity headers alone.

## Publishing model

Records support `draft` and `published` states, but this package deliberately does **not** connect the public site to admin records yet. That integration should happen only after the admin itself is deployed, Access-protected, and independently tested. Until then the public site cannot be changed by this panel.
