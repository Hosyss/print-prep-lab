const MAX_BODY_BYTES = 64 * 1024;
const MAX_VALUE_BYTES = 50 * 1024;
const MUTATIONS_PER_MINUTE = 30;
const CSRF_TTL_SECONDS = 10 * 60;
const CLOCK_SKEW_SECONDS = 60;
const RECORD_TYPES = new Set(["content", "seo", "feature", "settings", "navigation"]);
const RECORD_STATES = new Set(["draft", "published"]);

const enc = new TextEncoder();
const dec = new TextDecoder();

function nowIso() { return new Date().toISOString(); }
function json(data, status = 200, extra = {}) {
  return secureResponse(new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...extra }
  }));
}
function text(body, status = 200, type = "text/plain; charset=utf-8") {
  return secureResponse(new Response(body, { status, headers: { "Content-Type": type } }));
}
function secureResponse(response) {
  const h = new Headers(response.headers);
  h.set("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0");
  h.set("Pragma", "no-cache");
  h.set("Expires", "0");
  h.set("Content-Security-Policy", "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; media-src 'none'; worker-src 'none'; manifest-src 'none'; upgrade-insecure-requests");
  h.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  h.set("X-Content-Type-Options", "nosniff");
  h.set("X-Frame-Options", "DENY");
  h.set("Referrer-Policy", "no-referrer");
  h.set("Permissions-Policy", "accelerometer=(), autoplay=(), camera=(), clipboard-read=(), clipboard-write=(self), display-capture=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), publickey-credentials-get=(self), screen-wake-lock=(), usb=()");
  h.set("Cross-Origin-Opener-Policy", "same-origin");
  h.set("Cross-Origin-Resource-Policy", "same-origin");
  h.set("Cross-Origin-Embedder-Policy", "require-corp");
  h.set("X-Robots-Tag", "noindex, nofollow, noarchive, nosnippet, noimageindex");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers: h });
}

function normalizeTeamDomain(value) {
  const v = String(value || "").trim().replace(/\/$/, "");
  if (!v) return "";
  return v.startsWith("https://") ? v : `https://${v}`;
}
function allowedAdmins(env) {
  return new Set(String(env.ADMIN_EMAILS || "").split(",").map(x => x.trim().toLowerCase()).filter(Boolean));
}
function configErrors(env) {
  const missing = [];
  for (const k of ["ACCESS_TEAM_DOMAIN", "ACCESS_AUD", "ADMIN_EMAILS", "ADMIN_ORIGIN", "ADMIN_CSRF_SECRET"]) if (!String(env[k] || "").trim()) missing.push(k);
  if (!env.ADMIN_DB || typeof env.ADMIN_DB.prepare !== "function") missing.push("ADMIN_DB");
  if (allowedAdmins(env).size === 0 && !missing.includes("ADMIN_EMAILS")) missing.push("ADMIN_EMAILS");
  return [...new Set(missing)];
}
function b64urlBytes(s) {
  s = String(s).replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const raw = atob(s); const out = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}
function b64urlEncode(bytes) {
  let raw = ""; for (const b of bytes) raw += String.fromCharCode(b);
  return btoa(raw).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function parseJwtPart(part) {
  return JSON.parse(dec.decode(b64urlBytes(part)));
}
async function getAccessKeys(env) {
  const domain = normalizeTeamDomain(env.ACCESS_TEAM_DOMAIN);
  const res = await fetch(`${domain}/cdn-cgi/access/certs`, { cf: { cacheTtl: 300, cacheEverything: true } });
  if (!res.ok) throw new Error("access_keys_unavailable");
  const data = await res.json();
  if (!Array.isArray(data.keys)) throw new Error("access_keys_invalid");
  return data.keys;
}
function audMatches(claim, expected) {
  return Array.isArray(claim) ? claim.includes(expected) : claim === expected;
}
async function verifyAccessJwt(token, env) {
  if (!token) throw new Error("missing_access_jwt");
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("invalid_access_jwt");
  const [h64, p64, s64] = parts;
  const header = parseJwtPart(h64); const payload = parseJwtPart(p64);
  if (header.alg !== "RS256" || !header.kid) throw new Error("invalid_access_alg");
  const keys = await getAccessKeys(env);
  const jwk = keys.find(k => k.kid === header.kid);
  if (!jwk) throw new Error("unknown_access_key");
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, b64urlBytes(s64), enc.encode(`${h64}.${p64}`));
  if (!ok) throw new Error("invalid_access_signature");
  const now = Math.floor(Date.now() / 1000);
  if (!Number.isFinite(payload.exp) || payload.exp < now - CLOCK_SKEW_SECONDS) throw new Error("expired_access_jwt");
  if (payload.nbf && payload.nbf > now + CLOCK_SKEW_SECONDS) throw new Error("access_jwt_not_yet_valid");
  if (!audMatches(payload.aud, String(env.ACCESS_AUD))) throw new Error("invalid_access_audience");
  const issuer = normalizeTeamDomain(env.ACCESS_TEAM_DOMAIN);
  if (String(payload.iss || "").replace(/\/$/, "") !== issuer) throw new Error("invalid_access_issuer");
  const email = String(payload.email || payload.common_name || "").trim().toLowerCase();
  if (!email || !allowedAdmins(env).has(email)) throw new Error("admin_not_allowed");
  return { email, sub: String(payload.sub || ""), jti: String(payload.jti || ""), exp: payload.exp };
}

async function hmacKey(secret) {
  return crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}
async function issueCsrf(identity, env) {
  const payload = { e: identity.email, s: identity.jti || identity.sub, exp: Math.floor(Date.now()/1000) + CSRF_TTL_SECONDS, n: crypto.randomUUID() };
  const body = b64urlEncode(enc.encode(JSON.stringify(payload)));
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", await hmacKey(env.ADMIN_CSRF_SECRET), enc.encode(body)));
  return `${body}.${b64urlEncode(sig)}`;
}
async function verifyCsrf(token, identity, env) {
  if (!token || !token.includes(".")) return false;
  const [body, sig] = token.split(".");
  try {
    const ok = await crypto.subtle.verify("HMAC", await hmacKey(env.ADMIN_CSRF_SECRET), b64urlBytes(sig), enc.encode(body));
    if (!ok) return false;
    const p = JSON.parse(dec.decode(b64urlBytes(body)));
    return p.e === identity.email && p.s === (identity.jti || identity.sub) && Number(p.exp) >= Math.floor(Date.now()/1000);
  } catch { return false; }
}
function sameOriginMutation(request, env) {
  const expected = String(env.ADMIN_ORIGIN || "").replace(/\/$/, "");
  const origin = String(request.headers.get("Origin") || "").replace(/\/$/, "");
  const fetchSite = request.headers.get("Sec-Fetch-Site");
  return Boolean(expected && origin === expected && (!fetchSite || fetchSite === "same-origin"));
}
function isMutation(method) { return ["POST", "PUT", "PATCH", "DELETE"].includes(method); }
async function readJsonBody(request) {
  const type = request.headers.get("Content-Type") || "";
  if (!type.toLowerCase().startsWith("application/json")) throw Object.assign(new Error("json_required"), { status: 415 });
  const len = Number(request.headers.get("Content-Length") || 0);
  if (len > MAX_BODY_BYTES) throw Object.assign(new Error("body_too_large"), { status: 413 });
  const raw = await request.text();
  if (enc.encode(raw).length > MAX_BODY_BYTES) throw Object.assign(new Error("body_too_large"), { status: 413 });
  try { return JSON.parse(raw || "{}"); } catch { throw Object.assign(new Error("invalid_json"), { status: 400 }); }
}
function validKey(v) { return /^[a-z0-9][a-z0-9._:-]{0,127}$/.test(String(v || "")); }
function validPath(v) { return typeof v === "string" && v.startsWith("/") && v.length <= 256 && !/[\u0000-\u001f]/.test(v); }
function cleanLabel(v) { return String(v || "").trim().slice(0, 160); }
function serializeValue(value) {
  const raw = JSON.stringify(value);
  if (raw === undefined) throw Object.assign(new Error("invalid_value"), { status: 400 });
  if (enc.encode(raw).length > MAX_VALUE_BYTES) throw Object.assign(new Error("value_too_large"), { status: 413 });
  return raw;
}
async function sha256Hex(raw) {
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(raw)));
  return [...digest].map(b => b.toString(16).padStart(2, "0")).join("");
}
async function audit(db, actor, action, target, status, requestId) {
  await db.prepare("INSERT INTO admin_audit(actor,action,target,status,request_id,created_at) VALUES(?,?,?,?,?,?)")
    .bind(actor, action, target, status, requestId, nowIso()).run();
}
async function enforceRateLimit(db, actor) {
  const bucket = Math.floor(Date.now() / 60000);
  await db.prepare("INSERT INTO admin_rate_events(actor,bucket,count) VALUES(?,?,1) ON CONFLICT(actor,bucket) DO UPDATE SET count=count+1")
    .bind(actor, bucket).run();
  const row = await db.prepare("SELECT count FROM admin_rate_events WHERE actor=? AND bucket=?").bind(actor, bucket).first();
  if (Number(row?.count || 0) > MUTATIONS_PER_MINUTE) throw Object.assign(new Error("rate_limited"), { status: 429 });
  if (Math.random() < 0.03) await db.prepare("DELETE FROM admin_rate_events WHERE bucket < ?").bind(bucket - 10).run();
}

async function listRecords(db, url) {
  const type = url.searchParams.get("type"); const state = url.searchParams.get("state");
  const clauses = []; const binds = [];
  if (type) { if (!RECORD_TYPES.has(type)) throw Object.assign(new Error("invalid_type"), { status: 400 }); clauses.push("type=?"); binds.push(type); }
  if (state) { if (!RECORD_STATES.has(state)) throw Object.assign(new Error("invalid_state"), { status: 400 }); clauses.push("state=?"); binds.push(state); }
  const sql = `SELECT key,type,path,label,value_json,state,version,updated_at,updated_by FROM admin_records ${clauses.length ? "WHERE "+clauses.join(" AND ") : ""} ORDER BY updated_at DESC LIMIT 200`;
  const q = db.prepare(sql); const res = await (binds.length ? q.bind(...binds) : q).all();
  return (res.results || []).map(r => ({ ...r, value: JSON.parse(r.value_json), value_json: undefined }));
}
async function getRecord(db, key) {
  const r = await db.prepare("SELECT key,type,path,label,value_json,state,version,updated_at,updated_by FROM admin_records WHERE key=?").bind(key).first();
  return r ? { ...r, value: JSON.parse(r.value_json), value_json: undefined } : null;
}
async function putRecord(db, actor, body) {
  const key = String(body.key || ""); const type = String(body.type || ""); const path = String(body.path || ""); const label = cleanLabel(body.label);
  const state = String(body.state || "draft"); const expectedVersion = body.expectedVersion == null ? null : Number(body.expectedVersion);
  if (!validKey(key)) throw Object.assign(new Error("invalid_key"), { status: 400 });
  if (!RECORD_TYPES.has(type)) throw Object.assign(new Error("invalid_type"), { status: 400 });
  if (!validPath(path)) throw Object.assign(new Error("invalid_path"), { status: 400 });
  if (!label) throw Object.assign(new Error("label_required"), { status: 400 });
  if (!RECORD_STATES.has(state)) throw Object.assign(new Error("invalid_state"), { status: 400 });
  const valueJson = serializeValue(body.value); const existing = await getRecord(db, key); const at = nowIso();
  if (existing) {
    if (!Number.isInteger(expectedVersion) || expectedVersion !== Number(existing.version)) throw Object.assign(new Error("version_conflict"), { status: 409 });
    const prevRaw = JSON.stringify(existing.value);
    await db.prepare("INSERT INTO admin_revisions(record_key,record_version,value_json,state,actor,action,created_at,sha256) VALUES(?,?,?,?,?,?,?,?)")
      .bind(key, existing.version, prevRaw, existing.state, actor, "update", at, await sha256Hex(prevRaw)).run();
    const result = await db.prepare("UPDATE admin_records SET type=?,path=?,label=?,value_json=?,state=?,version=version+1,updated_at=?,updated_by=? WHERE key=? AND version=?")
      .bind(type, path, label, valueJson, state, at, actor, key, expectedVersion).run();
    if (Number(result.meta?.changes || 0) !== 1) throw Object.assign(new Error("version_conflict"), { status: 409 });
  } else {
    if (expectedVersion !== null && expectedVersion !== 0) throw Object.assign(new Error("version_conflict"), { status: 409 });
    const result = await db.prepare("INSERT OR IGNORE INTO admin_records(key,type,path,label,value_json,state,version,updated_at,updated_by) VALUES(?,?,?,?,?,?,1,?,?)")
      .bind(key, type, path, label, valueJson, state, at, actor).run();
    if (Number(result.meta?.changes || 0) !== 1) throw Object.assign(new Error("version_conflict"), { status: 409 });
  }
  return getRecord(db, key);
}
async function deleteRecord(db, actor, body) {
  const key = String(body.key || ""); const expectedVersion = Number(body.expectedVersion);
  if (!validKey(key) || !Number.isInteger(expectedVersion)) throw Object.assign(new Error("invalid_request"), { status: 400 });
  const existing = await getRecord(db, key); if (!existing) throw Object.assign(new Error("not_found"), { status: 404 });
  if (Number(existing.version) !== expectedVersion) throw Object.assign(new Error("version_conflict"), { status: 409 });
  const raw = JSON.stringify(existing.value); const at = nowIso();
  await db.prepare("INSERT INTO admin_revisions(record_key,record_version,value_json,state,actor,action,created_at,sha256) VALUES(?,?,?,?,?,?,?,?)")
    .bind(key, existing.version, raw, existing.state, actor, "delete", at, await sha256Hex(raw)).run();
  const result = await db.prepare("DELETE FROM admin_records WHERE key=? AND version=?").bind(key, expectedVersion).run();
  if (Number(result.meta?.changes || 0) !== 1) throw Object.assign(new Error("version_conflict"), { status: 409 });
  return { deleted: true, key };
}
async function rollbackRecord(db, actor, body) {
  const key = String(body.key || ""); const revisionId = Number(body.revisionId); const expectedVersion = Number(body.expectedVersion);
  if (!validKey(key) || !Number.isInteger(revisionId) || !Number.isInteger(expectedVersion)) throw Object.assign(new Error("invalid_request"), { status: 400 });
  const current = await getRecord(db, key); if (!current) throw Object.assign(new Error("not_found"), { status: 404 });
  if (Number(current.version) !== expectedVersion) throw Object.assign(new Error("version_conflict"), { status: 409 });
  const rev = await db.prepare("SELECT id,record_key,value_json,state FROM admin_revisions WHERE id=? AND record_key=?").bind(revisionId, key).first();
  if (!rev) throw Object.assign(new Error("revision_not_found"), { status: 404 });
  const curRaw = JSON.stringify(current.value); const at = nowIso();
  await db.prepare("INSERT INTO admin_revisions(record_key,record_version,value_json,state,actor,action,created_at,sha256) VALUES(?,?,?,?,?,?,?,?)")
    .bind(key, current.version, curRaw, current.state, actor, "rollback", at, await sha256Hex(curRaw)).run();
  const result = await db.prepare("UPDATE admin_records SET value_json=?,state=?,version=version+1,updated_at=?,updated_by=? WHERE key=? AND version=?")
    .bind(rev.value_json, rev.state, at, actor, key, expectedVersion).run();
  if (Number(result.meta?.changes || 0) !== 1) throw Object.assign(new Error("version_conflict"), { status: 409 });
  return getRecord(db, key);
}
async function listRevisions(db, key) {
  if (!validKey(key)) throw Object.assign(new Error("invalid_key"), { status: 400 });
  const r = await db.prepare("SELECT id,record_key,record_version,state,actor,action,created_at,sha256 FROM admin_revisions WHERE record_key=? ORDER BY id DESC LIMIT 100").bind(key).all();
  return r.results || [];
}
async function listAudit(db) {
  const r = await db.prepare("SELECT id,actor,action,target,status,request_id,created_at FROM admin_audit ORDER BY id DESC LIMIT 200").all();
  return r.results || [];
}
async function exportSnapshot(db, actor, env) {
  const records = await listRecords(db, new URL("https://local/api/records"));
  const payload = { schema: "printpreplab-admin-snapshot", version: 1, generatedAt: nowIso(), generatedBy: actor, records };
  const raw = JSON.stringify(payload);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", await hmacKey(env.ADMIN_CSRF_SECRET), enc.encode(raw)));
  return { ...payload, signature: b64urlEncode(sig), signatureAlgorithm: "HMAC-SHA256" };
}

const ADMIN_HTML = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Print Prep Lab Admin</title><link rel="stylesheet" href="/admin.css"></head><body><header><div><span>PRINT PREP LAB</span><h1>Secure Admin Control Plane</h1><p>Content and configuration only. Executable calculator code cannot be edited here.</p></div><a class="ghost" href="/cdn-cgi/access/logout">Sign out</a></header><main><section class="status"><strong id="identity">Authenticating…</strong><span id="status">No changes loaded.</span></section><section class="grid"><form id="record-form" autocomplete="off"><h2>Edit record</h2><label>Key<input id="key" required maxlength="128" pattern="[a-z0-9][a-z0-9._:-]{0,127}"></label><div class="twocol"><label>Type<select id="type"><option>content</option><option>seo</option><option>feature</option><option>settings</option><option>navigation</option></select></label><label>State<select id="state"><option>draft</option><option>published</option></select></label></div><label>Path<input id="path" required value="/" maxlength="256"></label><label>Label<input id="label" required maxlength="160"></label><label>JSON value<textarea id="value" required spellcheck="false">{}</textarea></label><input type="hidden" id="version" value="0"><div class="actions"><button type="submit">Save</button><button type="button" id="new" class="secondary">New</button><button type="button" id="delete" class="danger">Delete</button></div></form><section><div class="row"><h2>Records</h2><button id="refresh" class="secondary">Refresh</button></div><div id="records" class="records" aria-live="polite"></div></section></section><section><div class="row"><h2>Audit log</h2><button id="export" class="secondary">Export signed snapshot</button></div><div id="audit" class="audit"></div></section></main><script src="/admin.js" defer></script></body></html>`;
const ADMIN_CSS = `:root{font-family:Inter,ui-sans-serif,system-ui,sans-serif;color:#10233d;background:#f4f7fb}*{box-sizing:border-box}body{margin:0}header{display:flex;justify-content:space-between;gap:24px;align-items:center;background:#071a33;color:#fff;padding:22px clamp(18px,4vw,56px)}header span{font-size:12px;letter-spacing:.15em;color:#9fc5ff}h1{margin:4px 0 2px;font-size:clamp(22px,4vw,34px)}header p{margin:0;color:#c6d5e9}.ghost,.secondary,button{border:1px solid #b8c6d9;border-radius:10px;padding:10px 14px;background:#fff;color:#10233d;font-weight:700;text-decoration:none;cursor:pointer}.ghost{background:transparent;color:#fff;border-color:#6f85a3}main{max-width:1180px;margin:auto;padding:24px}.status,.grid>*,main>section{background:#fff;border:1px solid #dce4ef;border-radius:16px;padding:18px;margin-bottom:18px}.status{display:flex;justify-content:space-between;gap:18px}.grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:18px}.grid>*{margin:0}label{display:grid;gap:6px;font-weight:700;margin:12px 0}input,select,textarea{width:100%;border:1px solid #aebed2;border-radius:9px;padding:10px 12px;font:inherit;background:#fff}textarea{min-height:220px;font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.twocol{display:grid;grid-template-columns:1fr 1fr;gap:12px}.actions,.row{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}.actions{justify-content:flex-start}button{background:#0b63ce;color:#fff;border-color:#0b63ce}.secondary{background:#fff;color:#10233d}.danger{background:#a32020;border-color:#a32020}.record,.audit-row{border:1px solid #e1e7f0;border-radius:12px;padding:12px;margin:10px 0}.record button{width:100%;text-align:left;background:#fff;color:#10233d;border:0;padding:0}.meta{display:flex;gap:8px;flex-wrap:wrap;color:#60728b;font-size:12px}.badge{background:#eef4ff;border-radius:999px;padding:3px 8px}.empty{color:#60728b;padding:18px 0}@media(max-width:760px){.grid{grid-template-columns:1fr}.status{display:grid}.twocol{grid-template-columns:1fr}header{align-items:flex-start}}`;
const ADMIN_JS = `(()=>{'use strict';let csrf='';let records=[];const $=id=>document.getElementById(id);const setStatus=t=>$('status').textContent=t;async function api(path,opts={}){const o={credentials:'same-origin',...opts,headers:{Accept:'application/json',...(opts.headers||{})}};if(o.method&&o.method!=='GET'){o.headers['Content-Type']='application/json';o.headers['X-PPL-CSRF']=csrf}const r=await fetch(path,o);const d=await r.json().catch(()=>({error:'invalid_response'}));if(!r.ok)throw new Error(d.error||('HTTP '+r.status));return d}function el(tag,text,cls){const x=document.createElement(tag);if(text!=null)x.textContent=String(text);if(cls)x.className=cls;return x}function reset(){ $('record-form').reset();$('type').value='content';$('state').value='draft';$('path').value='/';$('value').value='{}';$('version').value='0';$('key').disabled=false;setStatus('New draft record.')}function edit(r){$('key').value=r.key;$('key').disabled=true;$('type').value=r.type;$('state').value=r.state;$('path').value=r.path;$('label').value=r.label;$('value').value=JSON.stringify(r.value,null,2);$('version').value=String(r.version);setStatus('Editing '+r.key+' v'+r.version);window.scrollTo({top:0,behavior:'smooth'})}function renderRecords(){const box=$('records');box.replaceChildren();if(!records.length){box.append(el('div','No admin records yet.','empty'));return}for(const r of records){const card=el('div',null,'record');const b=el('button');const strong=el('strong',r.label);const k=el('div',r.key);const meta=el('div',null,'meta');for(const t of [r.type,r.state,r.path,'v'+r.version])meta.append(el('span',t,'badge'));b.append(strong,k,meta);b.addEventListener('click',()=>edit(r));card.append(b);box.append(card)}}async function load(){const [me,rs,al,ct]=await Promise.all([api('/api/me'),api('/api/records'),api('/api/audit'),api('/api/csrf')]);csrf=ct.token;records=rs.records;$('identity').textContent=me.email;renderRecords();const box=$('audit');box.replaceChildren();for(const a of al.audit.slice(0,50)){const row=el('div',null,'audit-row');row.append(el('strong',a.action+' · '+a.status),el('div',a.target),el('div',a.created_at+' · '+a.actor,'meta'));box.append(row)}setStatus('Secure admin data loaded.')} $('record-form').addEventListener('submit',async e=>{e.preventDefault();try{const value=JSON.parse($('value').value);const body={key:$('key').value.trim(),type:$('type').value,state:$('state').value,path:$('path').value.trim(),label:$('label').value.trim(),value,expectedVersion:Number($('version').value)};const d=await api('/api/record',{method:'PUT',body:JSON.stringify(body)});setStatus('Saved '+d.record.key+' v'+d.record.version);await load();edit(d.record)}catch(err){setStatus('Save blocked: '+err.message)}});$('new').onclick=reset;$('refresh').onclick=()=>load().catch(e=>setStatus('Refresh failed: '+e.message));$('delete').onclick=async()=>{const key=$('key').value.trim();const version=Number($('version').value);if(!key||!version||!confirm('Delete this admin record? A revision is retained for audit.'))return;try{await api('/api/record',{method:'DELETE',body:JSON.stringify({key,expectedVersion:version})});reset();await load()}catch(e){setStatus('Delete blocked: '+e.message)}};$('export').onclick=async()=>{try{const d=await api('/api/export',{method:'POST',body:'{}'});const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='printpreplab-admin-snapshot.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500);setStatus('Signed snapshot exported.')}catch(e){setStatus('Export blocked: '+e.message)}};load().catch(e=>setStatus('Admin blocked: '+e.message));})();`;

async function handleApi(request, env, identity, url) {
  const db = env.ADMIN_DB; const method = request.method; const requestId = request.headers.get("cf-ray") || crypto.randomUUID();
  if (isMutation(method)) {
    if (!sameOriginMutation(request, env)) return json({ error: "cross_site_request_blocked" }, 403);
    if (!await verifyCsrf(request.headers.get("X-PPL-CSRF"), identity, env)) return json({ error: "csrf_invalid" }, 403);
    try { await enforceRateLimit(db, identity.email); } catch (e) { await audit(db, identity.email, "rate_limit", url.pathname, "blocked", requestId); throw e; }
  }
  if (method === "GET" && url.pathname === "/api/me") return json({ email: identity.email });
  if (method === "GET" && url.pathname === "/api/csrf") return json({ token: await issueCsrf(identity, env), expiresIn: CSRF_TTL_SECONDS });
  if (method === "GET" && url.pathname === "/api/records") return json({ records: await listRecords(db, url) });
  if (method === "GET" && url.pathname === "/api/record") { const key=url.searchParams.get("key")||""; const r=await getRecord(db,key); return r?json({record:r}):json({error:"not_found"},404); }
  if (method === "GET" && url.pathname === "/api/revisions") return json({ revisions: await listRevisions(db, url.searchParams.get("key") || "") });
  if (method === "GET" && url.pathname === "/api/audit") return json({ audit: await listAudit(db) });
  if (method === "PUT" && url.pathname === "/api/record") {
    const body=await readJsonBody(request); try { const record=await putRecord(db,identity.email,body); await audit(db,identity.email,"record_upsert",record.key,"ok",requestId); return json({record}); } catch(e){ await audit(db,identity.email,"record_upsert",String(body.key||""),"blocked",requestId); throw e; }
  }
  if (method === "DELETE" && url.pathname === "/api/record") {
    const body=await readJsonBody(request); try { const out=await deleteRecord(db,identity.email,body); await audit(db,identity.email,"record_delete",out.key,"ok",requestId); return json(out); } catch(e){ await audit(db,identity.email,"record_delete",String(body.key||""),"blocked",requestId); throw e; }
  }
  if (method === "POST" && url.pathname === "/api/rollback") {
    const body=await readJsonBody(request); try { const record=await rollbackRecord(db,identity.email,body); await audit(db,identity.email,"record_rollback",record.key,"ok",requestId); return json({record}); } catch(e){ await audit(db,identity.email,"record_rollback",String(body.key||""),"blocked",requestId); throw e; }
  }
  if (method === "POST" && url.pathname === "/api/export") { await readJsonBody(request); const snapshot=await exportSnapshot(db,identity.email,env); await audit(db,identity.email,"snapshot_export","*","ok",requestId); return json(snapshot); }
  return json({ error: "not_found" }, 404);
}

export default {
  async fetch(request, env) {
    try {
      const missing = configErrors(env);
      if (missing.length) return json({ error: "admin_not_configured", missing }, 503);
      const method = request.method.toUpperCase();
      if (!["GET","HEAD","POST","PUT","DELETE"].includes(method)) return json({ error: "method_not_allowed" }, 405, { Allow: "GET, HEAD, POST, PUT, DELETE" });
      const identity = await verifyAccessJwt(request.headers.get("Cf-Access-Jwt-Assertion"), env);
      const url = new URL(request.url);
      if (url.pathname.startsWith("/api/")) return await handleApi(request, env, identity, url);
      if (method !== "GET" && method !== "HEAD") return json({ error: "method_not_allowed" }, 405);
      if (url.pathname === "/" || url.pathname === "/admin") return text(method === "HEAD" ? "" : ADMIN_HTML, 200, "text/html; charset=utf-8");
      if (url.pathname === "/admin.css") return text(method === "HEAD" ? "" : ADMIN_CSS, 200, "text/css; charset=utf-8");
      if (url.pathname === "/admin.js") return text(method === "HEAD" ? "" : ADMIN_JS, 200, "application/javascript; charset=utf-8");
      if (url.pathname === "/robots.txt") return text("User-agent: *\nDisallow: /\n", 200);
      return text("Not found", 404);
    } catch (e) {
      const status = Number(e?.status || 0) || (String(e?.message || "").startsWith("admin_") || String(e?.message || "").includes("access_") ? 403 : 500);
      return json({ error: status >= 500 ? "internal_error" : String(e?.message || "forbidden") }, status);
    }
  }
};

export const __test = { normalizeTeamDomain, allowedAdmins, configErrors, validKey, validPath, cleanLabel, serializeValue, audMatches, secureResponse, sameOriginMutation };
