PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS admin_records (
  key TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  path TEXT NOT NULL,
  label TEXT NOT NULL,
  value_json TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'draft' CHECK (state IN ('draft','published')),
  version INTEGER NOT NULL DEFAULT 1,
  updated_at TEXT NOT NULL,
  updated_by TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_admin_records_type ON admin_records(type);
CREATE INDEX IF NOT EXISTS idx_admin_records_path ON admin_records(path);
CREATE INDEX IF NOT EXISTS idx_admin_records_state ON admin_records(state);

CREATE TABLE IF NOT EXISTS admin_revisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  record_key TEXT NOT NULL,
  record_version INTEGER NOT NULL,
  value_json TEXT NOT NULL,
  state TEXT NOT NULL,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  created_at TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  FOREIGN KEY(record_key) REFERENCES admin_records(key) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_admin_revisions_record ON admin_revisions(record_key, id DESC);

CREATE TABLE IF NOT EXISTS admin_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT NOT NULL,
  status TEXT NOT NULL,
  request_id TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_admin_audit_created ON admin_audit(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_admin_audit_actor ON admin_audit(actor, created_at DESC);

CREATE TABLE IF NOT EXISTS admin_rate_events (
  actor TEXT NOT NULL,
  bucket INTEGER NOT NULL,
  count INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(actor, bucket)
);
